# Technical Report — Iteration I (v2 — Hardened)
## Acoustic Softening & Effective Shear Modulus Reduction in Polymineralic Silicates
**Project:** Acoustic Sculpture, Nonlinear Mesoscopic Elasticity (NME) & Substrate Dynamics  
**Document ID:** `AS-NME-REP-01-V2` (Supersedes [`Task_01_Acoustic_Softening_NME_Report.md`](../../Task_01_Acoustic_Softening_NME_Report.md))  
**Audit Reference:** [`BAND_V_VIBRATIONAL.md`](BAND_V_VIBRATIONAL.md) · [`CHANGELOG.md`](../../hardening_SPH01/CHANGELOG.md)  
**Subject:** Formal Coupling of Ultrasonic Strain Amplitude ($\varepsilon_{\text{ac}}$), Effective Shear Modulus ($G_{\text{eff}}$), Griffith Energy Invariance, and Internal-Friction Holding Power

---

### Page 1: Executive Scope & Nonlinear Mesoscopic Constitutive Law

#### 1.1 Physical Architecture of Polymineralic Silicate Matrices (`SOURCE`)
Polymineralic igneous rocks—specifically tholeiitic basalt ($\rho_b \approx 2,850\text{ kg/m}^3$) and coarse-grained granite ($\rho_g \approx 2,650\text{ kg/m}^3$)—belong to the class of **Nonlinear Mesoscopic Elastic (NME)** solids (Guyer, McCall & Boitnott, *PRL* 74, 3491, 1995; TenCate & Shankland, *GRL* 23, 3019, 1996). Structurally, these materials comprise a two-phase mechanical hierarchy:
1. **The Hard Elastic Skeleton:** High-modulus crystalline mineral grains (plagioclase feldspar, clinopyroxene, quartz, olivine) exhibiting linear elastic behavior up to strains of $\varepsilon \sim 2.5 \times 10^{-4}$.
2. **The Soft Mesoscopic Bond Network:** A compliant, sub-micron percolation network of intergranular contacts, grain-boundary asperities, micro-fissures, and intracrystalline dislocation tangles occupying $<1\%$ of total rock volume but governing macroscopic nonlinear elasticity.

When excited by a high-intensity ultrasonic field of strain amplitude $\varepsilon_{\text{ac}}$ and angular frequency $\omega$, the effective dynamic shear modulus $G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)$ undergoes reversible and semi-irreversible softening ("fast dynamics" and "slow dynamics") within the perturbative domain $\varepsilon_{\text{ac}} \lesssim 2.5 \times 10^{-4}$ ($Q^{-1} \lesssim 0.27$).

---

#### 1.2 Preisach–Mayergoyz (PM) Space & 1D Shear Constitutive Formulation (`DERIVATION`)
Following the Guyer–Johnson–McCall formulation, each compliant intergranular contact is modeled as a **Hysteretic Mesoscopic Elastic Unit (HMEU)** characterized by an equilibrium closing stress $\sigma_c$ and opening stress $\sigma_o$. Under an applied shear strain $\gamma(t) = \gamma_0 + \varepsilon_{\text{ac}} \cos(\omega t)$, the macroscopic shear stress $\tau(\gamma, \dot{\gamma})$ expands as:

$$\tau(\gamma, \dot{\gamma}) = G_0 \left[ \gamma + \beta_G \gamma^2 + \delta_G \gamma^3 - \alpha_G \left( \varepsilon_{\text{ac}} \gamma + \frac{1}{2}\left(\gamma^2 - \varepsilon_{\text{ac}}^2\right)\operatorname{sgn}(\dot{\gamma}) \right) \right]$$

| Parameter | Symbol | Typical Range (Basalt/Granite) | Physical Meaning |
| :--- | :---: | :---: | :--- |
| Unperturbed Shear Modulus | $G_0$ | $25\text{–}35\text{ GPa}$ ($30.0\text{ GPa}$ nominal) | Linear elastic shear stiffness of intact mineral skeleton |
| Quadratic Nonlinearity | $\beta_G$ | $10^2\text{–}10^3$ | Third-order Landau–Murnaghan anharmonic coefficient |
| Cubic Nonlinearity | $\delta_G$ | $-10^5\text{ to }-10^7$ ($-4.0 \times 10^6$ nominal) | Fourth-order elastic coefficient ($\delta_G < 0$ drives cubic softening) |
| Hysteretic NME Parameter | $\alpha_G$ | $10^2\text{–}10^4$ ($2.5 \times 10^3$ nominal) | Density of HMEUs in Preisach–Mayergoyz $(\sigma_c, \sigma_o)$ space |
| Activation Threshold Strain | $\varepsilon_{\text{th}}$ | $10^{-7}\text{–}10^{-6}$ ($1.0 \times 10^{-6}$ nominal) | Critical strain onset for intergranular micro-slip |

---

#### 1.3 Cycle-Averaged Fast-Dynamics Secant Modulus ($G_{\text{backbone}}$)
Projecting $\tau(t)$ onto the fundamental Fourier component $\cos(\omega t)$ over one acoustic period $T_{\text{ac}} = 2\pi/\omega$ yields the strain-conditioned NME backbone modulus factor $\mathcal{S}(\varepsilon_{\text{ac}})$:

$$\mathcal{S}(\varepsilon_{\text{ac}}) \equiv \frac{G_{\text{backbone}}(\varepsilon_{\text{ac}})}{G_0} = 1 - \alpha_G \left(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}\right) H(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) + \frac{3}{4} \delta_G \varepsilon_{\text{ac}}^2$$

where $H(\cdot)$ is the Heaviside step function and $\delta_G = -|\delta_G| < 0$. Note that this polynomial expansion is valid only for $\varepsilon_{\text{ac}} \lesssim 2.8 \times 10^{-4}$ (where $\mathcal{S}(\varepsilon_{\text{ac}}) > 0$ and $Q^{-1}(\varepsilon_{\text{ac}}) < 0.3$).

---

### Page 2: Dislocation Unpinning & Acoustoplastic Flow (Blaha Effect)

#### 2.1 Granato–Lücke Dislocation Breakaway Defect ($\Phi_{\text{GL}}$)
Within individual silicate mineral grains, dislocations are pinned by weak impurity point defects at average spacing $L_c$ and by strong network nodes at spacing $L_N \gg L_c$. Under oscillatory ultrasonic shear stress $\tau_{\text{ac}} = G_{\text{eff}}\varepsilon_{\text{ac}}$, bowed dislocation segments break away from weak pinning points once $\varepsilon_{\text{ac}}$ surpasses the critical breakaway strain $\varepsilon_{\text{cr}} = F_m / (b G_0 L_c)$, introducing the amplitude-dependent modulus defect:

$$\Phi_{\text{GL}}(\varepsilon_{\text{ac}}) = -\frac{\Delta G_{\text{GL}}}{G_0} = \frac{\Omega \Lambda L_N^2}{\pi^2} \left(\frac{\varepsilon_{\text{cr}}}{\varepsilon_{\text{ac}}}\right) \exp\!\left(-\frac{\varepsilon_{\text{cr}}}{\varepsilon_{\text{ac}}}\right)$$

---

#### 2.2 Thermally Activated Acoustoplasticity (Blaha–Langenecker Formulation)
When an ultrasonic shear stress $\tau_{\text{ac}} \cos(\omega t)$ is superimposed onto a quasi-static shear stress $\tau_0$ at $T = 300\text{ K}$, the rate of thermally activated dislocation glide and grain-boundary sliding across an energy barrier $U_0$ with activation volume $V^*$ follows the cycle-averaged Eyring–Arrhenius equation (Blaha & Langenecker, *Naturwissenschaften* 42, 556, 1955 [`CIT-022`]):

$$\langle \dot{\gamma}_p \rangle = \dot{\gamma}_0 \exp\!\left(-\frac{U_0 - V^* \tau_0}{k_B T}\right) I_0\!\left(\frac{V^* G_{\text{eff}} \varepsilon_{\text{ac}}}{k_B T}\right)$$

In the high-intensity ultrasonic limit ($V^* G_{\text{eff}} \varepsilon_{\text{ac}} \gg k_B T$), substituting $I_0(z) \simeq e^z / \sqrt{2\pi z}$ yields the effective reduction in macroscopic shear yield stress:

$$\Delta \tau_y(\varepsilon_{\text{ac}}) = G_{\text{eff}}(\varepsilon_{\text{ac}}) \varepsilon_{\text{ac}} - \frac{k_B T}{2 V^*} \ln\!\left(\frac{2\pi V^* G_{\text{eff}}(\varepsilon_{\text{ac}}) \varepsilon_{\text{ac}}}{k_B T}\right)$$

---

### Page 3: Reconciled Backbone Benchmark, Griffith Invariance & Holding Dissipation

#### 3.1 Master Equation for Complex Effective Shear Modulus $G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)$
Separating the quasi-static/off-resonant strain-softened NME backbone $\mathcal{S}(\varepsilon_{\text{ac}})$ from the frequency-dependent Lorentzian metamaterial dispersion factor $\mathcal{D}(\varepsilon_{\text{ac}}, \omega)$:

$$G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega) = G_0 \, \mathcal{S}(\varepsilon_{\text{ac}}) \times \mathcal{D}(\varepsilon_{\text{ac}}, \omega), \qquad \Gamma(\varepsilon_{\text{ac}}) = \omega Q^{-1}(\varepsilon_{\text{ac}}) = \omega \left[ Q_0^{-1} + \frac{4 \alpha_G}{3\pi} (\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) H(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) \right]$$

#### 3.2 Griffith–Irwin Tensile Stress Threshold vs. Fracture Energy Release Invariance (`DERIVATION`)
For brittle intergranular microcracks of half-length $a$ and specific surface energy $\gamma_s$, the critical tensile stress required to initiate unstable crack propagation scales with $\sqrt{G_{\text{backbone}}(\varepsilon_{\text{ac}})}$:

$$\sigma_t^{\text{eff}}(\varepsilon_{\text{ac}}) = \sqrt{\frac{4 G_{\text{backbone}}(\varepsilon_{\text{ac}}) \gamma_s}{\pi (1 - \nu_{\text{eff}}) a}} = \sigma_{t,0} \sqrt{\mathcal{S}(\varepsilon_{\text{ac}})}$$

> [!IMPORTANT]
> **Griffith Fracture Energy Invariance (`Task V2`):** Because $(\sigma_t^{\text{eff}})^2 \propto G_{\text{backbone}}$, the critical Griffith strain-energy release rate per unit new crack area created is **invariant** under elastic modulus softening:
> $$G_c = \frac{(\sigma_t^{\text{eff}})^2 \pi a (1 - \nu_{\text{eff}})}{2 G_{\text{backbone}}(\varepsilon_{\text{ac}})} = 2\gamma_s$$
> Acoustic softening lowers the **peak stress threshold** $\sigma_t^{\text{eff}}$ that a cavitation pulse must exceed to initiate intergranular cleavage, but does not reduce the fundamental thermodynamic bond-breaking work $2\gamma_s$ per unit area.

#### 3.3 Reconciled Backbone Parametric Benchmark Table (Tholeiitic Basalt, `COMMAND` — Fixes `C2`, `M6`)
Using baseline basalt parameters $G_0 = 30.0\text{ GPa}$, $\sigma_{t,0} = 15.0\text{ MPa}$, $\alpha_G = 2.5 \times 10^3$, $\varepsilon_{\text{th}} = 1.0 \times 10^{-6}$, $\delta_G = -4.0 \times 10^6$, $f_{\text{drive}} = 21.5\text{ kHz}$, and linear water-hammer pressure $P_{\text{wh}} = 3.25\text{ GPa}$ *(reconciled with [`Task_03:120`](../../Task_03_Numerical_Simulation_Spec_Report.md#L120) and [`sim_cavity_acoustics.py`](../../sim_cavity_acoustics.py); the unsourced constant $\operatorname{Re}[\mathcal{D}] = 0.450$ from v1 is removed)*:

| Ultrasonic Strain $\varepsilon_{\text{ac}}$ | Exact Backbone Factor $\mathcal{S}(\varepsilon_{\text{ac}})$ | Backbone Shear Modulus $G_{\text{backbone}}$ ($\text{GPa}$) | Backbone Tensile Threshold $\sigma_t^{\text{eff}}$ ($\text{MPa}$) | Overpressure Ratio $P_{\text{wh}} / \sigma_t^{\text{eff}}$ | Internal Friction $Q^{-1}(\varepsilon_{\text{ac}})$ | Volumetric Holding Dissipation $\dot{q}_{\text{hold}}$ ($\text{MW/m}^3$) | Active Volume Sustained at $25\text{ kW}$ ($\text{L}$) |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| $0$ (Unperturbed) | $1.0000$ | $30.000$ | $15.000$ | $216.7\times$ | $0.0004$ | $0.0000$ | $\infty$ |
| $1.0 \times 10^{-5}$ | $0.9772$ | $29.316$ | $14.828$ | $219.2\times$ | $0.0106$ | $0.0022$ | $11,627.9\text{ L}$ |
| $5.0 \times 10^{-5}$ | $0.8700$ | $26.100$ | $13.991$ | $232.3\times$ | $0.0531$ | $0.2687$ | $93.02\text{ L}$ |
| **$1.5 \times 10^{-4}$ (Nominal)** | **$0.5600$** | **$16.800$** | **$11.225$** | **$289.5\times$** | **$0.1592$** | **$7.2562$** | **$3.445\text{ L}$** |
| $2.5 \times 10^{-4}$ | $0.1900$ | $5.700$ | $6.538$ | $497.1\times$ | $0.2653$ | $33.5937$ | $0.744\text{ L}$ |
| *$1.0 \times 10^{-3}$ (Invalid `C1`)* | *$-4.4975$* | *$-134.925$* | *Undefined* | *—* | *$1.0610 > 1$* | *$2,150.0$* | *$0.0116\text{ L}$ ($11.6\text{ cm}^3$)* |
