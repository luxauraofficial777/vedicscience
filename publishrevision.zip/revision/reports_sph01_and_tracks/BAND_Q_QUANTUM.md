# BAND Q — QUANTUM & FUNDAMENTAL CONSTANTS AUDIT REPORT
**Document ID:** `SPH01-BAND-Q-01`  
**Directive Reference:** [`WORK_OFFLOAD_DIRECTIVE_SPH01.md`](../../WORK_OFFLOAD_DIRECTIVE_SPH01.md) (§4, Band Q: Tasks `Q1`–`Q5`)  
**Reproducible Script & Metrics:** [`scripts/phase2_band_computations.py`](../../hardening_SPH01/scripts/phase2_band_computations.py) $\to$ [`outputs/phase2_band_metrics.json`](../../hardening_SPH01/outputs/phase2_band_metrics.json)  
**Primary Citations Registry:** [`citations.jsonl`](citations.jsonl)

---

## Executive Summary of Band Q Findings

1. **Task Q1 (Quantum vs. Classical Regime Audit):** At $T = 300\text{ K}$ ($k_B T = 25.852\text{ meV}$), all acoustic and ultrasonic frequencies invoked in the corpus ($34.4\text{ Hz}$ to $300\text{ kHz}$) have single-quantum energies $hf \in [1.42 \times 10^{-13}, 1.24 \times 10^{-9}]\text{ eV}$ and thermal Bose–Einstein occupations $n_{\text{th}} \in [2.08 \times 10^7, 1.82 \times 10^{11}] \gg 1$. Consequently, room-temperature ultrasonic irradiation injects a **classical high-amplitude coherent wave** (a macroscopic Glauber displacement state $|\beta_{q_0}\rangle$ with $|\beta_{q_0}|^2 \gg n_{\text{th}}$), **not** a quantum-degenerate Bose–Einstein or Fröhlich condensate (`INCONSISTENT` terminology in [`02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html`](../../02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html#L114)). True quantum occupation ($n_{\text{th}} < 1$) at $300\text{ K}$ occurs only in the **terahertz optical-phonon band** ($f > 6.25\text{ THz}$, $\tilde{\nu} > 208.5\text{ cm}^{-1}$, such as the $464\text{ cm}^{-1}$ and $1000\text{ cm}^{-1}$ silicate modes).
2. **Task Q2 (Reconciliation of [`Standard_Dislocation_Tunneling_Reference.md`](../../Standard_Dislocation_Tunneling_Reference.md) vs. [`verify_quantum_resonance.py`](../../verify_quantum_resonance.py)):** Four formula-vs-table discrepancies in v1 of the reference document were identified and resolved in [`Standard_Dislocation_Tunneling_Reference_v2.md`](Standard_Dislocation_Tunneling_Reference_v2.md):
   - **Washboard potential expansion:** Expanding $V(u) = \frac{b\sigma_P a_p}{2\pi}[1 - \cos(2\pi u / a_p)] - b\sigma u$ around the metastable minimum $u_{\min} = \frac{a_p}{2\pi}\arcsin(1-\epsilon)$ in shifted coordinate $\tilde{u} = u - u_{\min}$ eliminates the linear term and yields $\Delta V(\tilde{u}) = b\sigma_P \left[\frac{\pi\sqrt{2\epsilon}}{a_p}\tilde{u}^2 - \frac{2\pi^2}{3a_p^2}\tilde{u}^3\right]$ with barrier height $\Delta V_{\max} = \frac{2\sqrt{2}}{3\pi} b\sigma_P a_p \epsilon^{3/2}$, turning point $\tilde{u}_{\text{turn}} \propto \epsilon^{1/2}$, bounce time $\Delta \tau \propto \epsilon^{-1/4}$, kink-pair width $\Delta x \propto \epsilon^{-1/4}$, and $(1+1)\text{D}$ Euclidean bounce action $S_B(\epsilon) \sim \Delta x\,\Delta \tau\,\Delta V_{\max} \propto \epsilon^{-1/4}\epsilon^{-1/4}\epsilon^{3/2} = \epsilon^{5/4}$.
   - **Action prefactor $C_{\text{PP}}$:** The table value $S_0/\hbar = 196.59$ uses the Petukhov–Pokrovskii (1973) numerical prefactor $C_{\text{PP}} = 18.96$, whereas the v1 prose equation wrote $\frac{24}{5\pi}(2\pi)^{1/4} = 2.4190$ (which gives $S_0/\hbar = 25.08$, a $7.84\times$ mismatch).
   - **Traversal time $\tau_0$:** The table value $\tau_0 = 0.5324\text{ ps}$ uses $\tau_0 = \sqrt{m_d a_p / (b\sigma_P)}$, whereas v1 prose included an extraneous $1/\sqrt{2\pi}$ factor ($0.2124\text{ ps}$).
   - **Lindblad Table 2 ($Q_{\text{eff}}$ and $\tau_{\text{coh}}$):** Table 2 values (`735.3` and `4.681 ms` at `300 K`) come from the script's linear formula $Q_{\text{eff}}(T) = Q_0 / (1 + 0.008 T)$ and **energy** ring-down time $\tau_E = Q_{\text{eff}}/\omega_{\text{ac}}$, whereas the v1 prose wrote a $T^3$ law and amplitude decay time $2 Q_{\text{eff}}/\omega_{\text{ac}}$ (`9.362 ms`).
3. **Task Q3 (Typing & Manifold Repair of $\Xi_{23D}$):** As written in [`02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html`](../../02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html#L131) and [`03_Lux_Aura_Infrastructure.html`](../../03_Lux_Aura_Infrastructure.html#L96), $\det(J_{23}^{(k)})$ is undefined for a $23\times 32$ Jacobian matrix, and $\oint_{C^s}(\Omega \wedge \Theta)$ integrates a 3-form over a 1D curve. We provide the exact Riemannian/differential-geometric repair using the **Gramian volume factor** $\sqrt{\det(J_{23}^{(k)} (J_{23}^{(k)})^T)}$ and a 3-cycle boundary $\partial \Sigma_4$, while formally classifying the Liminal Seal narrative construct as `ALLEGORY`.
4. **Task Q4 & Q5 (Origin of Mass & Fundamental Constant Bounds):** In the Standard Model, $\mathbf{99.04\%}$ of the proton's rest mass ($938.272\text{ MeV}/c^2$) arises from **QCD gluon field energy and relativistic quark kinetic energy** ($m_p \sim \Lambda_{\text{QCD}}$; Dürr et al., *Science* 322, 1224, 2008 [`CIT-013`]), while only $\mathbf{0.96\%}$ ($8.99\text{ MeV}/c^2$) comes from the Higgs Yukawa rest mass of the three valence quarks ($uud$). However, because QCD confinement energy gravitates identically to rest mass, the Weak Equivalence Principle holds to $\eta = (-1.5 \pm 2.3 \pm 1.5)\times 10^{-15}$ (MICROSCOPE 2022 [`CIT-001`]), and naive constant-frequency orbital replacement ($v^2/r = \omega_{\text{eff}}^2 r \implies T = 2\pi/\omega_{\text{eff}} = \text{const}$) is falsified by Kepler's Third Law ($T^2 \propto a^3$).

---

## Task Q1 — Quantum vs. Classical Regime Classification Across the Corpus

Every corpus claim invoking "quantum," "phonon," "zero-point field (ZPF)," "tunneling," or "condensation" is audited below against the Bose–Einstein thermal occupation number at ambient rock temperature ($T = 300\text{ K}$, $k_B T = 0.025852\text{ eV}$) and cryogenic reference temperature ($T = 10\text{ K}$, $k_B T = 8.617 \times 10^{-4}\text{ eV}$):

$$n_{\text{th}}(f, T) = \frac{1}{\exp\!\left(\frac{h f}{k_B T}\right) - 1}$$

### Table Q1.1 — Thermal Occupation & Regime Audit (`COMMAND` — [`outputs/phase2_band_metrics.json`](../../hardening_SPH01/outputs/phase2_band_metrics.json))

| Corpus Mode / Phenomenon | Source Citation | $f\ (\text{Hz})$ | $E = hf\ (\text{eV})$ | $hf / k_B T\ (300\text{ K})$ | $n_{\text{th}}\ (300\text{ K})$ | $n_{\text{th}}\ (10\text{ K})$ | Physical Regime at $300\text{ K}$ | Verdict & Required Retagging |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | :--- | :--- |
| Barabar chamber fundamental | [`Task_03:49`](../../Task_03_Numerical_Simulation_Spec_Report.md#L49) | $34.4$ | $1.423 \times 10^{-13}$ | $5.50 \times 10^{-12}$ | $1.82 \times 10^{11}$ | $6.06 \times 10^{9}$ | Classical standing wave | `CONSISTENT` (modeled via classical Helmholtz/FDTD) |
| Sanctuary harmonic | [`02_Physical...:110`](../../02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html#L110) | $110.0$ | $4.549 \times 10^{-13}$ | $1.76 \times 10^{-11}$ | $5.68 \times 10^{10}$ | $1.89 \times 10^{9}$ | Classical acoustic mode | `CONSISTENT` as classical room acoustics |
| NME double-negative band | [`Master:87`](../../Consolidated_Master_Report_AS_NME.md#L87) | $2.15 \times 10^{4}$ | $8.892 \times 10^{-11}$ | $3.44 \times 10^{-9}$ | $2.91 \times 10^{8}$ | $9.69 \times 10^{6}$ | Classical elastic wave | `INCONSISTENT` where labeled "phonon condensation" in [`02_Physical...:114`](../../02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html#L114); retag as **classical Glauber displacement wave** |
| Ultrasonic transducer horn | [`SDT:65`](../../Standard_Dislocation_Tunneling_Reference.md#L65) | $2.50 \times 10^{4}$ | $1.034 \times 10^{-10}$ | $4.00 \times 10^{-9}$ | $2.50 \times 10^{8}$ | $8.33 \times 10^{6}$ | Classical elastic wave | `CONSISTENT` in [`SDT:85`](../../Standard_Dislocation_Tunneling_Reference.md#L85) (explicitly notes $n_{\text{th}} = 2.50 \times 10^8 \gg 1$) |
| Parametric carrier | [`Task_04:70`](../../Task_04_Astra_Data_Hardening_Protocol_Report.md#L70) | $4.00 \times 10^{4}$ | $1.654 \times 10^{-10}$ | $6.40 \times 10^{-9}$ | $1.56 \times 10^{8}$ | $5.21 \times 10^{6}$ | Classical nonlinear acoustics | `CONSISTENT` as classical Westervelt/Berktay wave |
| Acoustic emission (AE) band | [`02_Physical...:91`](../../02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html#L91) | $3.00 \times 10^{5}$ | $1.241 \times 10^{-9}$ | $4.80 \times 10^{-8}$ | $2.08 \times 10^{7}$ | $6.95 \times 10^{5}$ | Classical elastic wave | `CONSISTENT` (Gutenberg–Richter micro-cracking) |
| Dislocation pinning mode | [`SDT:39`](../../Standard_Dislocation_Tunneling_Reference.md#L39) | $1.00 \times 10^{10}$ | $4.136 \times 10^{-5}$ | $1.60 \times 10^{-3}$ | $6.25 \times 10^{2}$ | $20.34$ | Cryogenic crossover ($T_c \lesssim 1\text{ K}$) | `CONSISTENT` in [`SDT:13`](../../Standard_Dislocation_Tunneling_Reference.md#L13) (explicitly restricted to $T \lesssim 1\text{–}10\text{ K}$ and $\sigma \to \sigma_P$) |
| $\alpha$-Quartz $\text{Si–O–Si}$ bend ($464\text{ cm}^{-1}$) | [`SMR:17`](../../Standard_Mineral_Spectroscopy_Acoustics_Reference.md#L17) | $1.391 \times 10^{13}$ | $0.05753$ | $2.225$ | $0.1211$ | $1.02 \times 10^{-29}$ | **Quantum vibrational mode** ($n_{\text{th}} < 1$) | `CONSISTENT` (`SOURCE` — RRUFF R040031 [`CIT-009`]) |
| Silicate $\text{Si–O}$ stretch ($1000\text{ cm}^{-1}$) | [`SMR:16`](../../Standard_Mineral_Spectroscopy_Acoustics_Reference.md#L16) | $2.998 \times 10^{13}$ | $0.12399$ | $4.796$ | $0.00833$ | $3.26 \times 10^{-63}$ | **Quantum vibrational mode** ($n_{\text{th}} \ll 1$) | `CONSISTENT` (`SOURCE` — RRUFF [`CIT-009`]) |

---

## Task Q2 — Audit & Repair of `Standard_Dislocation_Tunneling_Reference.md`

### 1. Exact Washboard Expansion & $\epsilon^{5/4}$ Scaling Proof (`DERIVATION`)

In [`Standard_Dislocation_Tunneling_Reference.md`](../../Standard_Dislocation_Tunneling_Reference.md#L21), the Peierls–Nabarro washboard potential per unit dislocation length is:

$$V(u) = \frac{b \sigma_P a_p}{2\pi}\left[1 - \cos\!\left(\frac{2\pi u}{a_p}\right)\right] - b \sigma u$$

However, v1 Eq. (L21) wrote $\approx b\sigma_P \left[\epsilon u - \frac{\pi}{3a_p} u^3\right]$, which has a linear term in $u$ and does not vanish quadratically at the metastable minimum $u_{\min}$. To make the $\epsilon^{5/4}$ scaling transparent and algebraically exact:
- Set $V'(u) = b\sigma_P \sin(2\pi u / a_p) - b\sigma = 0$. Near the Peierls threshold $\sigma / \sigma_P = 1 - \epsilon$ ($\epsilon \to 0^+$), the metastable minimum $u_{\min}$ and saddle maximum $u_{\max}$ approach the inflection point $u_* = a_p / 4$:
  $$u_{\min} = \frac{a_p}{4} - \frac{a_p}{2\pi}\sqrt{2\epsilon} + \mathcal{O}(\epsilon^{3/2})$$
- Expanding $V(u)$ in the shifted displacement $\tilde{u} \equiv u - u_{\min}$ around $u_{\min}$ gives:
  $$\Delta V(\tilde{u}) \equiv V(u_{\min} + \tilde{u}) - V(u_{\min}) = b \sigma_P \left[ \frac{\pi \sqrt{2\epsilon}}{a_p} \tilde{u}^2 - \frac{2\pi^2}{3 a_p^2} \tilde{u}^3 + \mathcal{O}(\tilde{u}^4) \right]$$
- From this exact cubic-plus-quadratic normal form:
  1. **Barrier height:** At the saddle $\tilde{u}_{\max} = \frac{\sqrt{2\epsilon}}{\pi} a_p$, the barrier height per unit length scales as:
     $$\Delta V_{\max} = \frac{2\sqrt{2}}{3\pi} b \sigma_P a_p \, \epsilon^{3/2} \propto \epsilon^{3/2}$$
  2. **Tunneling exit point:** $\Delta V(\tilde{u}_{\text{turn}}) = 0$ at $\tilde{u}_{\text{turn}} = \frac{3\sqrt{2\epsilon}}{2\pi} a_p \propto \epsilon^{1/2}$.
  3. **Small-oscillation curvature & imaginary-time bounce duration ($\Delta \tau$):**
     $$V''(u_{\min}) = \frac{2\pi \sqrt{2\epsilon}}{a_p} b \sigma_P \propto \epsilon^{1/2} \implies \omega_0(\epsilon) = \sqrt{\frac{V''(u_{\min})}{m_d}} \propto \epsilon^{1/4} \implies \Delta \tau \sim \omega_0^{-1} \propto \epsilon^{-1/4}$$
  4. **Critical kink-pair nucleation width ($\Delta x$):** Balancing elastic line-tension energy $\frac{1}{2}\kappa_d (\partial_x \tilde{u})^2 \sim \kappa_d (\tilde{u}_{\text{turn}}/\Delta x)^2$ against the barrier density $\Delta V_{\max} \propto \epsilon^{3/2}$ gives:
     $$\Delta x \sim \sqrt{\frac{\kappa_d}{V''(u_{\min})}} = \sqrt{\frac{\kappa_d a_p}{2\pi\sqrt{2}\, b \sigma_P}}\,\epsilon^{-1/4} \propto \epsilon^{-1/4}$$
  5. **Euclidean $(1+1)\text{D}$ instanton bounce action ($S_B$):**
     $$S_B(\epsilon) = \iint d\tau\,dx \left[\frac{1}{2}m_d(\partial_\tau \tilde{u})^2 + \frac{1}{2}\kappa_d(\partial_x \tilde{u})^2 + \Delta V(\tilde{u})\right] \sim \Delta x \cdot \Delta \tau \cdot \Delta V_{\max} \propto \epsilon^{-1/4} \cdot \epsilon^{-1/4} \cdot \epsilon^{3/2} = \epsilon^{5/4}$$

### 2. Resolution of Formula vs. Script Discrepancies in `Standard_Dislocation_Tunneling_Reference`

| Item | v1 Prose Formula ([`Standard_Dislocation_Tunneling_Reference.md`](../../Standard_Dislocation_Tunneling_Reference.md)) | Script Formula ([`verify_quantum_resonance.py`](../../verify_quantum_resonance.py)) | v1 Value vs. Script Value | Resolution in [`Standard_Dislocation_Tunneling_Reference_v2.md`](Standard_Dislocation_Tunneling_Reference_v2.md) |
| :--- | :--- | :--- | :--- | :--- |
| **$S_0/\hbar$ prefactor** | $\frac{24}{5\pi}(2\pi)^{1/4} \approx 2.4190$ | $C_{\text{PP}} = 18.96$ (Petukhov & Pokrovskii 1973 numerical instanton constant [`CIT-006`]) | $25.08$ vs. **$196.59$** ($7.84\times$ mismatch) | Prose equation updated to use $C_{\text{PP}} = 18.96$, matching `196.59` in Table 1 and script |
| **$\tau_0$ traversal scale** | $\sqrt{\frac{m_d a_p}{2\pi b \sigma_P}}$ | $\sqrt{\frac{m_d a_p}{b \sigma_P}}$ | $0.2124\text{ ps}$ vs. **$0.5324\text{ ps}$** ($\sqrt{2\pi}$ mismatch) | Removed extraneous $2\pi$ in prose radical to match `0.5324 ps` in Table 1 and script |
| **$Q_{\text{eff}}(T)$ law** | $Q_0 / [1 + \alpha_{\text{anh}}(T/T_0)^3]$ | $Q_0 / (1 + 0.008\,T)$ | Cubic $T^3$ vs. linear $0.008\,T$ | Prose equation updated to $Q_{\text{eff}}(T) = Q_0 / (1 + \alpha_T T)$ with $\alpha_T = 0.008\text{ K}^{-1}$ |
| **Ring-down time $\tau_{\text{coh}}$** | $2 Q_{\text{eff}}(T) / \omega_{\text{ac}}$ (amplitude ring-down) | $Q_{\text{eff}}(T) / \omega_{\text{ac}}$ (energy ring-down) | $9.362\text{ ms}$ vs. **$4.681\text{ ms}$** at $300\text{ K}$ | Table 2 reports **both** energy decay $\tau_E = Q_{\text{eff}}/\omega_{\text{ac}}$ (`4.681 ms`) and amplitude decay $\tau_A = 2 Q_{\text{eff}}/\omega_{\text{ac}}$ (`9.362 ms`) |

---

## Task Q3 — Differential-Geometric Repair & Classification of $\Xi_{23D}$ (`C4`)

In [`02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html`](../../02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html#L131) and [`03_Lux_Aura_Infrastructure.html`](../../03_Lux_Aura_Infrastructure.html#L96), the "Validated Sub-Mapping Protocol Equation" is written as:

$$\Xi_{23D} \equiv \sum_{k=1}^{n} \lambda_k \left(\det(J_{23}^{(k)})\right)^{1/2} + \oint_{C^s} (\Omega \wedge \Theta)$$

### Mathematical Audit (`INCONSISTENT` as written)
1. **Non-square Jacobian:** A smooth submersion $\pi_k: \mathcal{M}^{32} \to \mathcal{N}^{23}$ has a $23 \times 32$ Jacobian matrix $J_{23}^{(k)} = d\pi_k$. The determinant $\det(A)$ is defined only for square matrices.
2. **Degree mismatch in exterior integral:** If $\Omega$ is a symplectic curvature 2-form ($\deg \Omega = 2$) and $\Theta$ is a connection 1-form ($\deg \Theta = 1$), their exterior wedge product $\Omega \wedge \Theta$ is a **3-form** ($\deg(\Omega \wedge \Theta) = 3$). Integrating a 3-form over a 1-dimensional contour $C^s$ is undefined in exterior calculus.
3. **Dimensional homogeneity:** Summing a dimensionless or volume-weighted scalar with a Chern–Simons-type action integral requires explicit normalization constants.

### Well-Typed Riemannian & Differential-Geometric Formulation (`DERIVATION`)
If one wishes to write a well-typed mathematical expression for the normal-jacobian volume factor of a submersion $\pi_k: (\mathcal{M}^{32}, g_{32}) \to (\mathcal{N}^{23}, g_{23})$ coupled to a 3-form Chern–Simons / helicity invariant over a closed 3-manifold $\Sigma_3 = \partial \mathcal{B}_4$, the standard Riemannian construction replaces $\det(J)$ with the **Gramian determinant** $\det\!\left(J_{23}^{(k)} (J_{23}^{(k)})^T\right)$ (which is a symmetric positive-definite $23 \times 23$ matrix whenever $\operatorname{rank}(J_{23}^{(k)}) = 23$):

$$\Xi_{23D}^{\text{well-typed}} = \sum_{k=1}^{n} \tilde{\lambda}_k \sqrt{\det\!\left(J_{23}^{(k)} \left(J_{23}^{(k)}\right)^T\right)} + \frac{1}{\Phi_0} \oint_{\Sigma_3} (\Omega \wedge \Theta)$$

where $J_{23}^{(k)} (J_{23}^{(k)})^T \in \mathbb{R}^{23 \times 23}$, $\Sigma_3$ is a closed 3-cycle ($\dim \Sigma_3 = 3 = \deg(\Omega \wedge \Theta)$), and $\Phi_0$ is the characteristic action-flux normalization.

> **Mandate Classification (`ALLEGORY`):** Even when written in well-typed Gramian form, the surrounding narrative in Articles 02–04 ("32D Star Map", "23D Data Manifold", "77.7% Sovereign Control", "Crimson & Gold Data Streams at $0.99c$") is symbolic/mythological world-building and governance art, not an empirical physical theory. Per Rule `R1` and [`README.md`](../README.md) §3, $\Xi_{23D}$, $\hat{\Lambda}_{\text{sl}}$, $\Psi_g$, and $P_{\text{bs}}$ are formally classified as **`ALLEGORY`**.

---

## Task Q4 — Origin of Mass in the Standard Model vs. Corpus Axiom `A1`

[`THEOREM_DOCKET.md`](../../THEOREM_DOCKET.md#L12) states Axiom `A1`: *"There is no primitive parameter 'mass.' Inertial response and gravitational coupling emerge from the mode spectrum of an underlying substrate oscillating at characteristic frequencies; G and m are derived quantities."*

### 1. Where the Owner's Intuition Touches Real Frontier Physics (`SOURCE`)
In the Standard Model of particle physics, macroscopic baryonic mass is indeed **not** a primitive constant:
- **Electroweak Higgs Mechanism (~0.96% of nucleon mass):** Elementary fermions acquire rest mass $m_f = \frac{y_f v}{\sqrt{2}}$ from Yukawa coupling $y_f$ to the Higgs vacuum expectation value $v \approx 246.22\text{ GeV}$ (ATLAS & CMS Collaborations, *Phys. Lett. B* 716, 1–61, 2012 [`CIT-011`, `CIT-012`]). For a proton ($uud$, $m_p = 938.272\text{ MeV}/c^2$), the sum of the current-quark Higgs masses at $\mu = 2\text{ GeV}$ is $2 m_u + m_d \approx 2(2.16) + 4.67 = 8.99\text{ MeV}/c^2$, or **$\mathbf{0.96\%}$** of the proton's mass ([`outputs/phase2_band_metrics.json`](../../hardening_SPH01/outputs/phase2_band_metrics.json)).
- **QCD Confinement & Gluon Field Energy (~99.04% of nucleon mass):** As proven *ab initio* via lattice quantum chromodynamics by Dürr et al. (*Science* 322, 1224, 2008 [`CIT-013`]), **$\mathbf{99.04\%}$** of the mass of protons and neutrons—and therefore $\sim 99\%$ of the visible mass of rocks, planets, and human bodies—is **confined quantum chromodynamic field energy and relativistic quark kinetic energy** ($m_p c^2 \sim \hbar c / r_p \sim \Lambda_{\text{QCD}}$) generated by dimensional transmutation of the massless gluon field. In a very real, peer-reviewed sense, $\sim 99\%$ of ordinary mass is confined relativistic field/mode energy ($E = mc^2$).

### 2. Why This Does NOT Allow Acoustic Gravity Cancellation (`DERIVATION` + `SOURCE`)
1. **Energy Scale Separation ($10^{19}\times$ gap):** The QCD confinement scale that generates nucleon mass is $\Lambda_{\text{QCD}} \sim 200\text{ MeV}$ ($f_{\text{QCD}} \sim 5 \times 10^{22}\text{ Hz}$). A $21.5\text{ kHz}$ ultrasonic wave has phonon energy $hf = 8.89 \times 10^{-11}\text{ eV}$—nineteen orders of magnitude below the strong-interaction confinement scale. Acoustic phonons shift interatomic lattice positions without perturbing nucleon mass.
2. **Equivalence Principle Bound (MICROSCOPE 2022):** Under General Relativity, all forms of stress-energy $T_{\mu\nu}$ (whether Higgs rest mass, QCD gluon binding energy, or electrostatic binding energy) gravitate identically. The MICROSCOPE space mission tested titanium vs. platinum in free fall and bounded any Eötvös violation to:
   $$\eta(\text{Ti, Pt}) = (-1.5 \pm 2.3_{\text{stat}} \pm 1.5_{\text{syst}}) \times 10^{-15} \quad (\text{Touboul et al., PRL 129, 121102, 2022 } [\text{CIT-001}])$$
3. **Closed-Cavity Momentum Conservation No-Go ([`THEOREM_DOCKET.md`](../../THEOREM_DOCKET.md#L43)):** Inside a closed resonant cavity of volume $V = 37.5\text{ m}^3$, an internal standing acoustic wave ($P_{\text{rad}} = 11.97\text{ kPa}$, wall force $838\text{ kN}$) exchanges momentum symmetrically between the enclosed fluid/rock and the cavity walls. The center-of-mass weight transmitted to the exterior planetary foundation remains identically $M_{\text{tot}} g$.

---

## Task Q5 — Experimental Bounds on Variation of Fundamental Constants & Lunar Cadence (`SOURCE` + `COMMAND`)

### Table Q5.1 — Published Experimental Bounds vs. Corpus Claims

| Fundamental Parameter / Hypothesis | Corpus Claim / Axiom | Best Published Experimental Bound | Primary Reference (`citations.jsonl`) | Audit Verdict |
| :--- | :--- | :--- | :--- | :--- |
| **Weak Equivalence Principle ($\eta = \Delta a / a$)** | Axiom `A1`: composition-dependent frequency gravity | $\eta = (-1.5 \pm 2.3 \pm 1.5) \times 10^{-15}$ (Ti vs. Pt in orbit); $\Delta(m_g/m_i) = (-3 \pm 5)\times 10^{-14}$ (Earth vs. Moon LLR) | Touboul et al., *PRL* 129, 121102 (2022) [`CIT-001`]; Hofmann & Müller, *CQG* 35, 035015 (2018) [`CIT-002`] | `CONSTRAINED` to $< 1.5 \times 10^{-15}$ |
| **Gravitational Constant Drift ($\dot{G}/G$)** | Axiom `A4`: engineered constants drifting over time | $\dot{G}/G = (7.1 \pm 7.6) \times 10^{-14}\text{ yr}^{-1}$ (Lunar Laser Ranging, 1970–2017) | Hofmann & Müller, *CQG* 35, 035015 (2018) [`CIT-002`] *(fixes discrepancy noted in [`IDEAS_RESEARCH_BRIEF.md:108`](../../IDEAS_RESEARCH_BRIEF.md#L108))* | `CONSTRAINED` to $< 10^{-13}\text{ yr}^{-1}$ |
| **Fine-Structure Constant Drift ($\dot{\alpha}/\alpha$)** | [`IDEAS-01` §1](../../IDEAS_RESEARCH_BRIEF.md#L28): environment-dependent EM coupling | $\dot{\alpha}/\alpha = (-1.0 \pm 1.1) \times 10^{-18}\text{ yr}^{-1}$ ($\text{Yb}^+$ E3/E2 optical atomic clock ratio) | Lange et al., *PRL* 126, 011102 (2021) [`CIT-003`] | `CONSTRAINED` locally to $< 10^{-18}\text{ yr}^{-1}$ |
| **Proton-to-Electron Mass Ratio Drift ($\dot{\mu}/\mu$)** | [`IDEAS-01` §1](../../IDEAS_RESEARCH_BRIEF.md#L28): mass ratio stability | $\dot{\mu}/\mu = (-8 \pm 36) \times 10^{-18}\text{ yr}^{-1}$ ($\text{Yb}^+$ vs. $\text{Cs}$ atomic clocks) | Lange et al., *PRL* 126, 011102 (2021) [`CIT-003`] | `CONSTRAINED` locally to $< 4 \times 10^{-17}\text{ yr}^{-1}$ |
| **Cosmological Spatial Dipole ($\Delta \alpha / \alpha$)** | [`IDEAS-01` §1](../../IDEAS_RESEARCH_BRIEF.md#L30): spatial compiler variation | $\Delta \alpha / \alpha = (1.02 \pm 0.21) \times 10^{-5}$ across quasar sightlines (4.2$\sigma$ claimed; disputed by VLT/ESPRESSO nulls) | Webb et al., *PRL* 107, 191101 (2011) [`CIT-004`] | `CONTESTED` at cosmological scales |
| **Chameleon Screened Scalar Fifth Force** | [`IDEAS-01` §1](../../IDEAS_RESEARCH_BRIEF.md#L29): density-dependent screening | Excludes $\Lambda_c \sim 2.4\text{ meV}$ for $M < 10^{15}\text{ GeV}$ in UHV Cs atom interferometry; strong-screening window remains open | Hamilton et al., *Science* 349, 849 (2015) [`CIT-005`] | `CONSTRAINED` (narrow UHV window open) |
| **Antimatter Gravitational Acceleration ($\bar{g}/g$)** | Standard Model CPT + Equivalence Principle | $a_{\bar{\text{H}}} = (0.75 \pm 0.13_{\text{stat}} \pm 0.16_{\text{syst}} \pm 0.23_{\text{sim}})\,g$ (antihydrogen falls downward) | ALPHA Collaboration (Anderson et al.), *Nature* 621, 716 (2023) [`CIT-014`] | `CONSISTENT` with standard GR |
| **Lunar Synodic Residual Anomaly ($\delta g / g$ at $29.53\text{ d}$)** | Axiom `A4` / `E4`: lunar calendar cadence in gravimetry | $\delta g_{\text{syn}} = 0.120 \pm 0.173\text{ nm/s}^2$ ($\text{SNR} = 0.69$, 95% UL $0.459\text{ nm/s}^2 \implies \delta g / g < 4.7 \times 10^{-11}$) | Boy et al. (2017) [`CIT-010`]; [`e4_lunar_residual_search.py`](../../e4_lunar_residual_search.py) (`COMMAND`) | **NULL** (`CONSISTENT` with standard tide models) |
