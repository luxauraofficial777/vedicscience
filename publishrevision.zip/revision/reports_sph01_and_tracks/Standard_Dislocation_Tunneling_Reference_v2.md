# Condensed-Matter Reference (v2 — Hardened): Dislocation Kink-Pair Tunneling & Phonon Decoherence
**Document ID:** `SDT-REF-01-V2` (Supersedes [`Standard_Dislocation_Tunneling_Reference.md`](../../Standard_Dislocation_Tunneling_Reference.md))  
**Verification Script & Data:** [`verify_quantum_resonance.py`](../../verify_quantum_resonance.py) $\to$ [`quantum_dislocation_tunneling_data.json`](../../quantum_dislocation_tunneling_data.json) (`COMMAND`)  
**Scope Note:** In keeping with our focus on established, peer-reviewed condensed-matter physics and materials science, this reference covers the standard models of **Petukhov–Pokrovskii (1973)** dislocation kink-pair quantum tunneling, **Caldeira–Leggett (1981)** dissipative phonon drag, **Büttiker–Landauer (1982)** oscillating-barrier traversal, and **Glauber coherent phonon** thermal decoherence in crystalline solids. It does not model speculative spacetime metric operators ($\hat{\Lambda}_{\text{sl}}$) or temporal drift ($\Delta T_{\text{drift}}$), as mechanical strain and acoustic phonons in standard physics operate strictly within the crystal lattice and do not alter spacetime metrics or gravity.

---

## 1. Petukhov–Pokrovskii Euclidean Bounce Formulation (near $\sigma \to \sigma_P$)

In a crystalline lattice with Peierls period $a_p$ and Burgers vector $b$, a dislocation line of effective mass per unit length $m_d = \rho b^2 / (4\pi)$ and line tension $\kappa_d = G b^2 / (4\pi)$ moves across the periodic Peierls washboard potential:

$$V(u) = \frac{b \sigma_P a_p}{2\pi}\left[1 - \cos\!\left(\frac{2\pi u}{a_p}\right)\right] - b \sigma u$$

When an applied shear stress $\sigma$ approaches the Peierls stress $\sigma_P$, the dimensionless stress deficit is defined as:

$$\epsilon = 1 - \frac{\sigma}{\sigma_P} \ll 1$$

Setting $V'(u) = 0$ locates the metastable minimum $u_{\min} = \frac{a_p}{2\pi}\arcsin(1-\epsilon) = \frac{a_p}{4} - \frac{a_p}{2\pi}\sqrt{2\epsilon} + \mathcal{O}(\epsilon^{3/2})$. Expanding $V(u)$ around $u_{\min}$ in the shifted coordinate $\tilde{u} \equiv u - u_{\min}$ eliminates the linear term and yields the exact normal-form cubic metastability potential per unit length (`DERIVATION`):

$$\Delta V(\tilde{u}) \equiv V(u_{\min} + \tilde{u}) - V(u_{\min}) = b \sigma_P \left[ \frac{\pi \sqrt{2\epsilon}}{a_p} \tilde{u}^2 - \frac{2\pi^2}{3 a_p^2} \tilde{u}^3 + \mathcal{O}(\tilde{u}^4) \right]$$

At the saddle point $\tilde{u}_{\max} = \frac{\sqrt{2\epsilon}}{\pi} a_p$, the barrier height per unit length is $\Delta V_{\max} = \frac{2\sqrt{2}}{3\pi} b \sigma_P a_p \, \epsilon^{3/2} \propto \epsilon^{3/2}$, and the zero-potential exit point is $\tilde{u}_{\text{turn}} = \frac{3\sqrt{2\epsilon}}{2\pi} a_p \propto \epsilon^{1/2}$.

### Euclidean Action & Critical Kink-Pair Scaling
In the Euclidean path-integral formulation ($t \to -i\tau$), the dislocation line configuration $\tilde{u}(x, \tau)$ minimizes the $(1+1)\text{D}$ Euclidean bounce action $S_B$:

$$S_B(\epsilon) = \int_{-\hbar / 2k_B T}^{\hbar / 2k_B T} d\tau \int_{-\infty}^{\infty} dx \left[ \frac{1}{2} m_d \left(\frac{\partial \tilde{u}}{\partial \tau}\right)^2 + \frac{1}{2} \kappa_d \left(\frac{\partial \tilde{u}}{\partial x}\right)^2 + \Delta V(\tilde{u}) \right]$$

Because the small-oscillation curvature at $u_{\min}$ is $V''(u_{\min}) = \frac{2\pi\sqrt{2\epsilon}}{a_p} b \sigma_P \propto \epsilon^{1/2}$:
1. The characteristic imaginary-time bounce duration scales as $\Delta \tau \sim \sqrt{m_d / V''(u_{\min})} \propto \epsilon^{-1/4}$.
2. The critical kink-pair nucleation width along the dislocation line scales as $\Delta x \sim \sqrt{\kappa_d / V''(u_{\min})} \propto \epsilon^{-1/4}$.
3. The $(1+1)\text{D}$ Euclidean bounce action therefore scales as $S_B(\epsilon) \sim \Delta x \cdot \Delta \tau \cdot \Delta V_{\max} \propto \epsilon^{-1/4} \cdot \epsilon^{-1/4} \cdot \epsilon^{3/2} = \epsilon^{5/4}$ (Petukhov & Pokrovskii, *Sov. Phys. JETP* 36, 336, 1973 [`CIT-006`]):

$$\frac{S_B(\epsilon)}{\hbar} = \frac{S_0}{\hbar} \, \epsilon^{5/4}, \qquad S_0 = C_{\text{PP}} \, a_p^2 \sqrt{\kappa_d m_d} \left(\frac{b \sigma_P a_p}{\kappa_d}\right)^{1/4}, \qquad C_{\text{PP}} = 18.96$$

The zero-point quantum tunneling rate is then:

$$\Gamma_{\text{tun}}(\epsilon) = \nu_0 \exp\!\left( -\frac{S_B(\epsilon)}{\hbar} \right)$$

---

## 2. Büttiker–Landauer Acoustic Modulation & Caldeira–Leggett Dissipation

### Oscillating Stress Field ($\sigma(t) = \sigma_0 + \sigma_{\text{ac}}\cos(\omega_{\text{ac}} t)$)
When an oscillating stress field modulates the barrier height, the characteristic imaginary-time traversal ("bounce") duration across the barrier is (reconciled with [`verify_quantum_resonance.py`](../../verify_quantum_resonance.py#L59)):

$$\tau_{\text{BL}}(\epsilon) = \tau_0 \, \epsilon^{-1/4}, \qquad \tau_0 = \sqrt{\frac{m_d a_p}{b \sigma_P}}$$

For the benchmark silicate/oxide crystal parameters ($\tau_0 = 0.5324\text{ ps}$) and ultrasonic frequencies ($f_{\text{ac}} = 20\text{–}100\text{ kHz}$), the adiabaticity parameter satisfies:

$$\gamma_{\text{BL}} = \omega_{\text{ac}} \tau_{\text{BL}}(\epsilon) \sim 10^{-7} \ll 1$$

Because the ultrasonic period ($\sim 10\text{–}50\ \mu\text{s}$) is seven orders of magnitude longer than the barrier traversal time ($\sim 0.5\text{–}2\text{ ps}$), the dislocation experiences a kHz acoustic wave in the **quasi-static (adiabatic) limit**: the instantaneous stress at the peak of the acoustic cycle reduces the effective stress deficit to $\epsilon_{\text{eff}} = 1 - (\sigma_0 + \sigma_{\text{ac}})/\sigma_P$. Only in the **gigahertz phonon regime** ($f_{\text{ac}} \sim 10\text{ GHz}$, evaluated in [`verify_quantum_resonance.py`](../../verify_quantum_resonance.py#L66)) does $\omega_{\text{ac}} \tau_{\text{BL}} \sim 0.04\text{–}0.13$ produce a non-trivial Büttiker–Landauer multiphonon sideband contribution.

### Caldeira–Leggett Phonon-Drag Suppression
Coupling between the moving dislocation core and the thermal bath of lattice phonons introduces a viscous drag coefficient $\eta$ (in $\text{Pa}\cdot\text{s}$). In the Caldeira–Leggett (1981) nonlocal action formulation, Ohmic dissipation adds a positive correction $\Delta S_{\text{CL}}$ to the Euclidean bounce action:

$$\Delta S_{\text{CL}}(\epsilon, \eta) = \frac{1}{4\pi} \eta \int dx \int d\tau \int d\tau' \, \frac{\big(\tilde{u}(x,\tau) - \tilde{u}(x,\tau')\big)^2}{(\tau - \tau')^2} \simeq \eta \, u_{\text{crit}}^2(\epsilon) \, L_{\text{kink}}(\epsilon) \propto \eta \, a_p^3 \sqrt{\frac{\kappa_d}{b \sigma_P a_p}} \, \epsilon^{3/4}$$

At room temperature ($\eta_{\text{high}} = 5 \times 10^{-4}\text{ Pa}\cdot\text{s}$), $\Delta S_{\text{CL}}/\hbar \gg 1$, which completely suppresses macroscopic quantum tunneling and ensures that room-temperature acoustic softening (the Blaha effect) is governed by classical thermal activation and stress superposition rather than quantum tunneling. Quantum kink-pair tunneling is physically observable only at cryogenic temperatures ($T \lesssim 1\text{–}10\text{ K}$) when $\epsilon \to 0$.

---

## 3. Coherent Glauber Phonon States & Thermal Decoherence

An ultrasonic transducer driving a macroscopic crystal mode $q_0$ creates a classical coherent Glauber displacement state $|\beta_{q_0}\rangle$ with mean phonon occupation $N_{q_0} = |\beta_{q_0}|^2 = E_{\text{mode}}/(\hbar\omega_{q_0}) \gg n_{\text{th}} \gg 1$.

In standard open-quantum-system dynamics (Lindblad master equation), anharmonic phonon scattering (Akhiezer damping in the $\omega \tau_{\text{th}} \ll 1$ regime) couples the driven mode to the thermal bath at temperature $T$. Reconciled with [`verify_quantum_resonance.py`](../../verify_quantum_resonance.py#L130), the effective quality factor $Q_{\text{eff}}(T)$, **energy** ring-down time $\tau_E(T)$, **amplitude** ring-down time $\tau_A(T)$, and thermal bath occupation $n_{\text{th}}(T)$ are governed by:

$$Q_{\text{eff}}(T) = \frac{Q_0}{1 + \alpha_T T} \quad (\alpha_T = 0.008\text{ K}^{-1}), \qquad \tau_E(T) = \frac{Q_{\text{eff}}(T)}{\omega_{q_0}}, \qquad \tau_A(T) = \frac{2 Q_{\text{eff}}(T)}{\omega_{q_0}}, \qquad n_{\text{th}}(T) = \frac{1}{\exp(\hbar\omega_{q_0}/k_B T) - 1}$$

While the macroscopic classical strain energy decays over milliseconds ($\tau_E = 1/\gamma_{q_0} = 4.681\text{ ms}$ at $300\text{ K}$), any non-classical quantum superposition decays at the thermal decoherence rate $\Gamma_{\text{dec}} \approx \gamma_{q_0}(2 n_{\text{th}} + 1) \sim 1.07 \times 10^{11}\text{ s}^{-1}$ ($\tau_{\text{dec}} \sim 9.4\text{ ps}$), confirming that $25\text{ kHz}$ ultrasonic waves at $300\text{ K}$ behave strictly as classical elastic waves.

---

## 4. Verified Numerical Data (`verify_quantum_resonance.py` / `quantum_dislocation_tunneling_data.json`)

**Material Parameters Used:**
- Burgers vector $b = 2.50\text{ \AA}$, Peierls period $a_p = 2.50\text{ \AA}$
- Shear modulus $G = 30.0\text{ GPa}$, density $\rho = 2,850\text{ kg/m}^3$, shear wave speed $c_s = 3,244.4\text{ m/s}$
- Effective mass per unit length $m_d = \rho b^2 / (4\pi) = 1.4175 \times 10^{-17}\text{ kg/m}$, line tension $\kappa_d = G b^2 / (4\pi) = 1.4921 \times 10^{-10}\text{ N}$
- Peierls stress $\sigma_P = 50.0\text{ MPa}$, attempt frequency $\nu_0 = 10^{12}\text{ Hz}$, GHz phonon assist $f_{\text{ac}} = 10.0\text{ GHz}$ ($\sigma_{\text{ac}}/\sigma_P = 0.02$)
- Characteristic action scale $S_0/\hbar = \mathbf{196.59}$ (for $C_{\text{PP}} = 18.96$), traversal time scale $\tau_0 = \mathbf{0.5324\text{ ps}}$

### Table 1: Euclidean Bounce Action & Damping Suppression vs. Stress Deficit $\epsilon$ (Exact Script Match)

| Stress Deficit $\epsilon = 1 - \sigma/\sigma_P$ | $S_B(\epsilon)/\hbar$ (Undamped) | $\tau_{\text{BL}}(\epsilon)$ (ps) | $\Delta S_{\text{CL}}/\hbar$ ($\eta_{\text{low}} = 10^{-5}\text{ Pa}\cdot\text{s}$) | $\Delta S_{\text{CL}}/\hbar$ ($\eta_{\text{high}} = 5\times 10^{-4}\text{ Pa}\cdot\text{s}$) | $S_{\text{eff,assisted}}/\hbar$ (Low Damping + $10\text{ GHz}$) | $\log_{10}(\Gamma/\nu_0)$ (Undamped) | $\log_{10}(\Gamma/\nu_0)$ (Assisted, Low Damping) | $\log_{10}(\Gamma/\nu_0)$ (Room-$T$ High Damping) |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **0.500** | 82.656 | 0.6332 | 6.088 | 304.377 | 88.742 | -35.90 | -38.54 | -168.09 |
| **0.350** | 52.923 | 0.6922 | 4.659 | 232.935 | 57.579 | -22.98 | -25.01 | -124.15 |
| **0.250** | 34.752 | 0.7530 | 3.620 | 180.984 | 38.368 | -15.09 | -16.66 | -93.69 |
| **0.150** | 18.352 | 0.8556 | 2.468 | 123.382 | 20.812 | -7.97 | -9.04 | -61.55 |
| **0.100** | 11.055 | 0.9468 | 1.821 | 91.030 | 12.864 | -4.80 | -5.59 | -44.33 |
| **0.050** | 4.648 | 1.1260 | 1.083 | 54.127 | 5.702 | -2.02 | -2.48 | -25.53 |
| **0.025** | 1.954 | 1.3390 | 0.644 | 32.184 | 2.531 | -0.85 | -1.10 | -14.83 |
| **0.010** | 0.622 | 1.6837 | 0.324 | 16.188 | 0.733 | -0.27 | -0.32 | -7.30 |
| **0.005** | 0.261 | 2.0023 | 0.193 | 9.625 | 0.000 | -0.11 | 0.00 | -4.29 |

### Table 2: Acoustic Phonon Quality Factor, Ring-Down Times & Thermal Occupation ($f = 25\text{ kHz}$, $Q_0 = 2,500$)

| Temperature $T$ (K) | Effective Quality Factor $Q_{\text{eff}}(T) = \frac{2500}{1 + 0.008 T}$ | Energy Decay Rate $\gamma_{\text{decay}}\ (\text{s}^{-1})$ | Energy Ring-Down Time $\tau_E = \frac{Q_{\text{eff}}}{\omega}$ (ms) | Amplitude Ring-Down Time $\tau_A = \frac{2 Q_{\text{eff}}}{\omega}$ (ms) | Thermal Phonon Occupation $n_{\text{th}}(T)$ |
| :--- | ---: | ---: | ---: | ---: | :--- |
| **4 K** | 2,422.5 | 64.84 | 15.422 | 30.844 | $3.334 \times 10^6$ |
| **20 K** | 2,155.2 | 72.88 | 13.720 | 27.441 | $1.667 \times 10^7$ |
| **77 K** | 1,547.0 | 101.54 | 9.849 | 19.697 | $6.418 \times 10^7$ |
| **150 K** | 1,136.4 | 138.23 | 7.234 | 14.469 | $1.250 \times 10^8$ |
| **300 K** | 735.3 | 213.63 | 4.681 | 9.362 | $2.500 \times 10^8$ |
