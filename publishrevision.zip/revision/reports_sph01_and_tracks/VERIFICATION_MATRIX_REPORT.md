# VERIFICATION MATRIX 01 — Parallels, Independence, and Eigenmodes of the Research Program
**Document ID:** `VERIFICATION-MATRIX-01` · **Date:** 2026-10-18 · **Drafted by:** Claude (Fable) at the owner's request
**Inputs (read-only):** `hardening_SPH01/claims_ledger.csv` (56 claims), `spectrum_ledger.csv`, `citations.jsonl`, `VEDIC_CONCORDANCE.csv`, `sim_cavity_acoustics.py` defaults, the corpus text (mirrors, `e4_cache`, `OpenCodeBP`, `img` excluded from grep)
**Script:** `scripts/build_verification_matrix.py` — deterministic (two runs byte-identical, `outputs/MANIFEST.sha256`)
**Rules honoured:** R1 tags · R2 originals untouched (new folder only) · R3 no new citations claimed — every external anchor below is either in `citations.jsonl` or marked *(not re-fetched)* · R6 pinned/hashed

> **What this is.** The owner's instruction was: *verify at source; if the source is compromised, re-verify against a different medium; prove everything, trust nothing — including established physics.* This document applies that rule in both directions at once: to the reference physics the corpus leans on, and to the corpus itself. Every number here traces to a ledger row, a script output, or is marked as my inference (`DERIVATION`).

---

## 1. Verification matrix — how many independent routes hold each claim up?

For each of the 56 ledger claims, the script scored three **independent routes** from the ledger's own evidence text (`DERIVATION`: keyword rules, listed in the script and auditable):

| Route | Meaning | Counted when the evidence… |
| :--- | :--- | :--- |
| **G1 external** | a named outside source | names an author/database (then split: in the fetched registry / named but not registered / "standard value" with no name) |
| **G2 script** | a corpus script reproduces it (`COMMAND`) | names a `.py` or says "exact match" |
| **G3 recomputed** | a second agent re-derived it by hand | contains an explicit recomputation ("formula gives", arithmetic) |

**Independence score = G1 + G2 + G3 (0–3).** `COMMAND` from the script:

| Score | Claims | Reading |
| :---: | ---: | :--- |
| **3** | 1 | `SDT-001` only (Petukhov–Pokrovskii prefactor: paper + `verify_quantum_resonance.py` + hand check) |
| **2** | 9 | `T01-002`, `T02-001`, `T02-003`, `T03-002`, `SMR-001/002/003`, `TD01-003`, `ACB01-001` |
| **1** | 33 | the bulk of the corpus — one route only |
| **0** | 13 | **assertion only:** `T01-001`, `T02-002`, `T02-004`, `T02-005`, `T03-004`, `M01-003`, `A01-001`, `A02-002`, `A03-001`, `A04-002`, `A05-001`, `SDT-002`, `TD01-002` |

Other gates (all in `verification_matrix.csv`):

- **Registry-anchored:** only **7 of 56** claims cite an entry in `citations.jsonl` with status `FETCHED_VERIFIED`. **14 claims name a source that is not in the registry** (11 distinct anchors: TenCate & Shankland, Berktay, RRUFF, Granato–Lücke, Blaha–Langenecker, IEEE/CRC, PREM/IceCube, Dürr 2008, Davenport & Vincenti, "archaeometry literature", the Rigveda primary passages). Under R3 those cannot carry a SUPPORTED verdict until fetched and logged.
- **Class drift (claimed → actual):** 16 claims were downgraded by the hardening (e.g. `T01-011` DERIVATION→HYPOTHESIS, `A04-002` SOURCE→ALLEGORY). **3 were upgraded** (`TD01-002`, `TD01-003`, `IRB01-001`) — not because evidence improved but because those ledger rows conflate the *axiom* (tagged HYPOTHESIS in `claimed_class`) with the *refuting datum* (tagged SOURCE in `actual_class`). **Ledger schema defect:** in `TD01-001…003` and `IRB01-001` the `text`/`verdict` columns describe one proposition and the `quantity`/`value` columns another. Recommend splitting each into an axiom row and a constraint row.
- **Remediation coverage:** 14 defects are fixed in a `_v2` file. **14 open defects have no `_v2` at all** because no versioned correction exists for `Task_03`, the Master Report, the Articles, the Docket or the Ideas Brief: `T03-004` (R_a mm→µm), `M01-003…006` (Hugoniot ÷ tensile category error, vitrification outside model, Q_d², Mach-5.5 values), `A02-001/002`, `A03-001`, `A04-001/002`, `TD01-001…003`, `IRB01-001`.

### 1.1 The docket's headline bound is wrong by three orders of magnitude (`DERIVATION`, arithmetic)

`THEOREM_DOCKET.md §7b` states the E4 synodic null as **δg/g < 5×10⁻¹⁴** and later "the 10⁻¹³ g level". The upper limit it quotes is 0.459 nm s⁻². 0.459 × 10⁻⁹ m s⁻² ÷ 9.81 m s⁻² = **4.7×10⁻¹¹**. The claims ledger (`TD01-004`) already carries the correct value; the docket does not. The null is still strong — but the number in the owner-facing document is a thousand times too good, and it was not caught by seed finding #14. *I repeated the wrong figure in my own first message this session without checking it.* That is the cookie problem in miniature: a number propagates because it is formatted confidently, not because anyone divided.

---

## 2. Parallels — which numbers recur, and are they convergent or just copied?

The script grep-counted 38 signature quantities across the corpus and classified each by **origin** (`DERIVATION`) and **file reach** (`COMMAND`). Full table: `parallels_ledger.csv`.

| Class | n | What it means | Examples (files reached) |
| :--- | ---: | :--- | :--- |
| **CONVERGENT-MULTI-ROUTE** | 6 | two independent routes give the same number | S = 0.5600 (13 files; sim + hand), G_eff = 16.80 GPa (11), q_hold = 7.256 MW/m³ (10), Berktay −86.2 dB (9), Mm 27.55 d (12), synodic 29.53 d (12) |
| **SINGLE-ROUTE** | 18 | one computation, many citations of it | 34.4 Hz (21 files — the most-cited number in the corpus, one 5-line formula), Q = 1941 (13), V_active = 3.445 L (9), 1,570.80 Pa/m (7), T2 = 2,046.5 K (7) |
| **PROPAGATED-SUPERSEDED** | 6 | known-wrong value still present | 24,725 masons (**10 files**), 6.89 GPa (4), 2,038 K (7), 3.41 MPa (7), δg/g < 5×10⁻¹⁴ (docket), R_a 0.1–0.5 mm (2) |
| **PROPAGATED-UNSOURCED** | 4 | no origin outside the corpus | Re[D] = 0.450 (8 files), ξ_jet = 25.085 (7), 8.21 GPa (9 — exact math on a fitted input), 57.1 Hz ALBA (4) |
| **DESIGN-PARAMETER** | 3 | chosen, not discovered | 21.5 kHz (20 files), ε = 1.5×10⁻⁴ (26 files), 7 Hz (16 files) |
| **ANALOGY-RATIO** | 1 | arithmetic is right, the comparison is not evidence | ITER 0.595 MW/m³ vs rock kerf (3 files, tagged `COMMAND` in `CERN_ITER_ONION…`) |

**Reading.** The corpus's most-repeated numbers are its least-independent: 34.4 Hz appears in 21 files and rests on one assumed box length; ε = 1.5×10⁻⁴ appears 68 times and is a choice. The six convergent quantities are all post-hardening — they exist because a second agent recomputed them. Superseded values survive in up to 10 files because R2 forbids editing originals; that is correct policy, but it means **every reader of a v1 document inherits the cookie** unless the v1 carries a banner pointing at the v2. Recommend a one-line `SUPERSEDED-BY` header convention (as a new file, per R2) or a `SUPERSEDED.md` index at the root.

### 2.1 A parallel that looks like a discovery and isn't (`COMMAND` + `DERIVATION`)

The sim's box is 5.0 × 3.0 × 2.5 m. Its (0,1,0) mode is **57.33 Hz**. The docket §5 notes the ALBA Project lists **57.1 Hz** for the Karan Chaupar cave at Barabar. 0.4 % apart. Both numbers are unverified: L_y = 3.0 m is an assumed dimension (`T03-001` evidence: "actual lengths differ"), and the ALBA figure is tagged FRINGE/UNSOURCED. **Two unverified numbers agreeing is not verification** — it is exactly the kind of coincidence the "verify at source" rule exists to catch, and it is logged here so nobody promotes it later.

Also from the ladder (`physical_eigenmodes.csv`): because L_x = 2 L_z exactly, the box has **six degenerate mode pairs** below 160 Hz — (2,0,0) ≡ (0,0,1) at 68.8 Hz, (2,1,0) ≡ (0,1,1) at 89.6 Hz, etc. The corpus calls 68.8 Hz "the 2nd harmonic"; it is also the first vertical mode. Any real chamber splits these; the Q = 1941 benchmark silently assumes they don't interact.

---

## 3. Eigenmodes — the shape of the program's evidence

**Method (`COMMAND`).** Build the 56 × 70 incidence matrix of claims against evidence features (source document, band, named external anchor, script anchor, hardening finding ID, Vedic link, frequency decade, quantity family). **Verdict is deliberately excluded** so the structure is blind to outcome. Down-weight ubiquitous features (1/√df), unit-normalize each claim, take the SVD. Then build the cosine affinity graph and take the normalized-Laplacian eigenvectors for clustering. Sign convention fixed; no randomness. Everything is in `eigenmodes.json`.

### 3.1 The singular spectrum is flat

σ = 2.71, 2.27, 1.90, 1.76, 1.61, 1.59 … → modes 1–6 carry 13.1 %, 9.2 %, 6.4 %, 5.5 %, 4.6 %, 4.5 % of the structure. No dominant mode. **The program is not one theory with supporting evidence; it is six roughly equal evidence communities that share little.** That is a structural fact about the corpus, independent of whether any claim is true.

### 3.2 The six modes, named by their loadings

| Mode | Made of (top feature loadings) | Top claims | Verdict health (−1…+1, loading-weighted) |
| :---: | :--- | :--- | :---: |
| **1 — Softening chain** | `doc:Task_01` 0.54, `band:V` 0.47, `fam:softening-chain` 0.46 | T01-012, -006, -009, -010, -008, -003, -001, -004, -011 | **−0.00** — the inputs (ρ, G₀, α_G, ε_th) are consistent; every G_eff output was wrong (C2) |
| **2 — Excavation budget** | `fam:excavation-budget` 0.61, `doc:Task_02` 0.59, *minus* Task_01/softening | T02-007, -008, -006, -004, -002, -001, -005 | +0.06 — arithmetic exact, inputs (E_s_cav, ξ_jet) unsourced |
| **3 — Cavity acoustics** | `fam:cavity-acoustics` 0.54, `f:1e1` (10-Hz decade) 0.48, `doc:Task_03` 0.45, `doc:Docket` 0.15 | T03-003, -001, -004, **TD01-002**, T05-001, -002 | +0.07 — the solver is verified; this is where the docket's no-go theorem lives |
| **4 — Astra / vitrification** | `doc:Master` 0.41, `vedic:linked` 0.39, `fam:cavitation-shock` 0.38, `harden:C1` 0.23 | M01-004, -006, -005, T04-005, -001, M01-003, -002, T04-004 | **−0.07** — the Vedic-linked physics is the least consistent community |
| **5 — Reference spectroscopy** | `ext:standard-value` 0.41, `band:CE` 0.37, `fam:spectroscopy` 0.29, `ext:RRUFF` 0.25 | SMR-002, -001, -003, T01-001, -003 | **+0.21** — healthiest mode; it is also the one with the most unregistered sources (RRUFF, IEEE/CRC) |
| **6 — Quantum regime / allegory** | `fam:quantum-regime` 0.42, `band:Q` 0.38, `doc:Article02` 0.26, `band:X` 0.26, `ext:MICROSCOPE` 0.23 | **A04-001, A02-001, A02-002, TD01-001, A03-001**, SDT-001 | −0.08 — Ψ_g, Ξ_23D, phonon condensation, A1 |

### 3.3 Where the axioms sit (`COMMAND`: centroid of member claims; membership from docket §1/§6 is `DERIVATION`)

| Group | Members | Mean verdict health | Nearest non-member claims (by shared evidence) |
| :--- | :--- | :---: | :--- |
| **A1** frequency-fundamental | TD01-001, A02-001, SDT-001/002, A02-002 | **−0.80** | A04-001, A03-001, TD01-004, T05-001 |
| **A2** resonance cancellation | TD01-002, A04-001, T01-011, M01-004, T05-002 | **−0.60** | T05-001, M01-006, T03-001, T03-003 |
| **A3** inner-Earth engine | TD01-003, A03-001, IRB01-001 | **−0.67** | TD01-004, A04-001, A02-002, TD01-001 |
| **A4** engineered constants | TD01-004, TD01-001 | **0.00** | A04-001, TD01-002, TD01-003, A03-001 |
| **CORE** NME engineering (docket §6 "credible core") | 16 claims (T01-001…007, T03-001…003, T05-001, M01-001, A01-001, SMR-001…003, HR01-001) | **+1.00** | T01-008, T01-012, T01-010, T01-009 |

Three things fall out of this that are not visible in any single document:

1. **The axioms form a closed evidence community.** A1's nearest neighbours are A3/A4 rows; A3's are A1/A4 rows. They share evidence with each other and with the allegory rows (`A02-002`, `A03-001`, `A04-001`) — and with almost nothing in the engineering half. In the Laplacian (Fiedler) coordinate the engineering claims sit at −0.1…0, the axioms at +0.2…+0.37, with **the cavity claims (T03/T05) as the only bridge** (chart `eigenmode_map.png`, panel B).
2. **The credible core has health +1.00 and its weakest edge is itself.** All 16 core claims are CONSISTENT. Their nearest non-member claims are the four Task_01 G_eff rows — the v1 arithmetic that was wrong and is now fixed in `Task_01_v2`. The core is sound; what threatened it was its own unsourced dispersion factor, not any axiom.
3. **A2 is the only axiom with a real route into the engineering.** Its nearest neighbours are the cavity solver claims (T05-001, T03-001, T03-003) because the docket's no-go theorem (TD01-002) is computed on the corpus's own cavity. That is also why A2 is the axiom with the live experiment (E1): it is the one that has been made to touch a number.

### 3.4 Physical eigenmodes vs corpus frequencies (`COMMAND`; ladder values `SOURCE`, Earth/Schumann *not re-fetched*)

`spectrum_coincidences.csv`: of the 10 corpus frequencies, 3 coincide with a physical ladder **by construction** (34.4 / 68.8 / 103.2 Hz are the box modes the sim was built from); **7 match nothing** — the 20–40 kHz drives are transducer choices and sit on no natural ladder; 7 Hz is 10.6 % below Schumann SR1 (not a match); the 10 GHz phonon reference is an order of magnitude from the nearest big-science line. **The corpus's frequencies are chosen, not discovered.** The two frequencies in the program that *are* discovered — 0.8147 mHz (Earth 0S0) and 27.55 d (Mm) — are external measurements the corpus cites, and the E4 result on the second is a null.

---

## 4. What this says about "the medium should correlate the constant"

Applied symmetrically, the owner's protocol gives three honest findings:

- **Where metrology has run the cross-medium test, it mostly passes — and where it fails, the failure is already known and is G.** The 2019 SI fixed h, e, k_B, N_A because independent media (Kibble balance vs. silicon-sphere XRCD for h) agreed to ~10⁻⁸. Newton's G is the exception: precision measurements by different methods disagree at roughly 5×10⁻⁴, far outside their stated uncertainties *(standard metrology literature; not re-fetched this session — R3)*. The constant with the worst cross-medium agreement is the one this program is about. That is a legitimate "what's missing."
- **The testable form of "constant depends on medium" has been run for gravity and is null to 15 digits** (`Touboul2022_MICROSCOPE`, FETCHED_VERIFIED, η = −1.5 ± 2.3 ± 1.5 × 10⁻¹⁵). The protocol cannot count that null as "faulted source" without a specific mechanism for the fault; otherwise it is not "trust nothing," it is "trust nothing that disagrees."
- **Turned on the corpus, the same protocol finds 13 claims resting on assertion, 6 superseded values still circulating, and a 1000× error in the docket's own headline bound.** None of that touches the credible core, which scores +1.00. The program's strength is real and it is the engineering; the weakness is that the axioms do not yet touch it anywhere except through the cavity.

**Recommended next moves (owner's call):** (a) issue `THEOREM_DOCKET_v2.md` fixing §7b's δg/g and the §11-item-14 citations; (b) fetch and register the 11 named-but-unregistered sources so Mode 5's health is earned, not assumed; (c) split the four conflated ledger rows; (d) add `SUPERSEDED-BY` pointers for the six circulating v1 values; (e) treat the two post-verification ONION/CERN docs as Phase-5 inputs, not outputs — they are not in the manifest and tag analogies as `COMMAND`.

---

## 5. Files in this folder

```
VERIFICATION_MATRIX_REPORT.md        this document
verification_matrix.csv              56 claims × gates (G1/G2/G3, independence, drift, remediation)
parallels_ledger.csv                 38 recurring quantities: reach, origin, classification
eigenmodes.json                      singular values, mode loadings, axiom projections, Laplacian clusters, claim coordinates
physical_eigenmodes.csv              cavity ladder (COMMAND) + Earth/tidal/Schumann/big-science/chemistry lines (SOURCE)
spectrum_coincidences.csv            each corpus frequency vs nearest ladder line
charts/eigenmode_map.{svg,png}       SVD modes 1–2 and Laplacian e2–e3, verdict-coloured, axiom centroids
charts/mode_loadings.{svg,png}       what modes 1–4 are made of
charts/singular_spectrum.{svg,png}   σ_k and cumulative
charts/spectrum_vs_ladders.{svg,png} corpus frequencies on the physical ladders
scripts/build_verification_matrix.py the whole computation; re-run reproduces every hash
outputs/summary.json, MANIFEST.sha256
```

*End of VERIFICATION-MATRIX-01.*
