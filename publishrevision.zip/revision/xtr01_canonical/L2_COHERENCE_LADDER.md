# L2 Coherence Ladder

Question: is any Earth-temperature acoustic or seismic process quantum?

Pre-registered expectation: no Earth-temperature acoustic or seismic process is quantum; quantum enters the program in exactly two ways, through molecular mechanisms in biology and through sensors. Verdicts: QUANTUM-MOLECULAR = 3 (radical-pair, enzyme H tunnelling, photosynthetic vibronic coherence), QUANTUM-DEVICE = 2 (SQUID, atom interferometer), CLASSICAL = 4 (coherent phonon condensation 21.5 kHz, Glauber 25 kHz, dislocation kink-pair at 300 K, Earth normal modes).

Rows: 9. n_th computed as 1/(exp(h f / k T)-1), f = 1/tau_coh when tau_coh > 0; f = 21500 for 21.5 kHz and 25000 for 25 kHz; tau_coh = inf gives n_th = inf. Float format %.6g. LF.