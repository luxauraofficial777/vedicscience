# BRIDGE B5 (Canonical v2) — Quantum Gravimetry & Multi-Station IGETS Scaling of `E4`

**Revised Edition Verdict (`MSL-ADD-01`):** **`SUPPORTED` (`DERIVATION` from `OWN-TEST` `E4` baseline)** · Paired with multi-station stacking test **`T-4`**.
- Single-station `E4` synodic 95% UL: $0.459\text{ nm/s}^2$ ($\delta g/g < 4.68 \times 10^{-11}$, `CONTRADICTED` for stationary synodic anomaly).
- $N = 10$ coherent IGETS stations: $\text{UL}(N=10) = 0.459 / \sqrt{10} = \mathbf{0.145\text{ nm/s}^2}$ (`DERIVATION`).
- $N = 30$ coherent IGETS stations: $\text{UL}(N=30) = 0.459 / \sqrt{30} = \mathbf{0.0838\text{ nm/s}^2}$ (`DERIVATION`).
- Quantum-limited ($10\times$ lower noise floor + $10\times$ stations): $\text{UL} = \mathbf{0.0145\text{ nm/s}^2}$ ($\delta g/g \approx \mathbf{1.48 \times 10^{-12}}$, `DERIVATION`).

# BRIDGE B3 — Quantum sensing ↔ geophysics (the honest "quantum × seismology")

**Status:** COMPLETE (derivation). **Evidence class:** DERIVATION (instrument physics) + SOURCE anchors.

**Anchor A (quantum sensors):**
- Superconducting gravimeter (Goodkind, *Rev. Sci. Instrum.* 70, 4131 (1999)): Brownian noise floor 0.01 µgal/√Hz = 1×10⁻¹⁰ m s⁻²/√Hz; long-period peak excursions 0.1–0.3 µgal = 1×10⁻⁹–3×10⁻⁹ m s⁻²; year-long sensitivity ~1 nGal = 1×10⁻¹¹ m s⁻².
- Atom-interferometer gravity gradiometer (Stray et al., *Nature* 602, 590 (2022)): 20 E statistical uncertainty in 10 min; short-term 466 E/√Hz (1 E = 10⁻⁹ s⁻², i.e. ~2×10⁻⁸ m s⁻² over a 1 m baseline).

**Anchor B (geophysics):** E4 upper limit at the lunar synodic period, single IGETS station (st026, 95 months): 0.459 nm s⁻² = 4.59×10⁻¹⁰ m s⁻² (δg/g < 4.7×10⁻¹¹).

**Scale ladder (acceleration, m s⁻²):**
- Stray gradiometer sensitivity 2×10⁻⁸ (per m baseline) ≈ 44× the E4 UL.
- SG long-period floor 1×10⁻⁹ ≈ 2.2× the E4 UL.
- SG Brownian floor 1×10⁻¹⁰ ≈ 0.22× the E4 UL per √Hz.
- E4 UL (integrated, 1 station) 4.59×10⁻¹⁰.

**Equation:** for white residuals, UL ∝ 1/√N. With a 10× lower instrument noise floor and 10 more stations:
UL_new = UL_old / (10√10) = 4.59×10⁻¹⁰ / 31.62 = 1.45×10⁻¹¹ m s⁻² (0.0145 nm s⁻²), i.e. δg/g ≈ 1.48×10⁻¹². For the anomalistic Mm band (baseline 1.2345 nm s⁻²): 0.0390 nm s⁻².

**Domain of validity:** E4 UL is an integrated amplitude at a fixed period after IGETS Level-3 corrections; SG/atom-interferometer floors are quoted in different bands and must be treated as order-of-magnitude anchors.

**Falsifier:** the bridge fails if the derived SG noise floor disagrees with the published one by more than 2×. It does not require any gate to be wrong.