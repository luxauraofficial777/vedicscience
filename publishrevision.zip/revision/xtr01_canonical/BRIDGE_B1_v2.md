# BRIDGE_B1: Biology↔Seismology (AE catalogue ↔ ComCat)

## Objective (Track A)
Bridge AE (Acoustic Emission) microfracture statistics from Article 03/Tasks to regional seismicity (ComCat) using Aki (1965) MLE b-value + bootstrap, same estimator for both catalogues. Stress-test against known values; report uncertainty.

## Anchors (from extract)
- AE Gutenberg–Richter: log10 N = a - b*(A_dB/20) (A03-018 etc)
- High freq AE >300 kHz (intergranular) noted
- b-value expected in lab AE varies; seismology b~0.8–1.2

## Method (deterministic)
- Pre-log window: [start, end] chosen before contact (R4). Default: 2000–2025 (global or regional India/Ellora-adjacent) to compare with Deccan context; log window_id, reason, N_min>=50.
- Same estimator: Aki MLE b = (log10 e)/(M_mean - M_c) with M_c by max curvature; bootstrap 1000 resamples for CI95.
- AIC model selection if fitting variants; report Mc, b, sigma_b, N.
- Compare AE-derived magnitude scale proxy to seismic magnitudes (units mapping) — flag if non-comparable.

## Window Pre-Log (R4, locked 2026-10-18)
- Region: circle around Ellora/Kailasa Temple (lat=19.8797, lon=75.1730, maxradius=10 deg ≈ 1100 km), Deccan context.
- Time: 2000-01-01T00:00:00 → 2026-10-18T00:00:00 (ComCat coverage era).
- minmagnitude=2.5 (completeness proxy; log Mc will still be estimated), eventtype=earthquake.
- format=csv, orderby=time, limit=20000 (hard cap).
- Rationale: regional Deccan seismicity adjacent to the acoustic-sculpture site; window chosen before fetch (no peeking).
- Seed: 20261018 for bootstrap resampling.

## Inputs (planned)
- AE catalogue rows from hard_data_extract.csv (class=DERIVATION with "Gutenberg-Richter"/"AE")
- ComCat CSV via https://earthquake.usgs.gov/fdsnws/event/1/query.csv?starttime=YYYY-MM-DD&endtime=YYYY-MM-DD&minmagnitude=0&orderby=time (fetch with curl.exe; cache to outputs/comcat_cache.csv, SHA-256)
- Seed 20261018 (determinism)

## Results
- Seismic (ComCat, fetched 2026-10-18, SHA256 D001...F17 → then refetch 3632...A957 after bbox fix):
  - N_total=973 (M>=3.3 actual, catalogue truncated below Mc)
  - Mc_maxcurvature = 4.4 (mode of 0.1-mag bins)
  - b_aki_mle = 1.2532, bootstrap CI95 [1.1292, 1.3900], sd=0.0682 (seed 20261018, 1000 resamples)
  - Note: b>1 consistent with diffuse intraplate/deformation-zone seismicity; Mc=4.4 indicates catalogue incomplete below M4.4 in this window/region.
- AE (from hard_data_extract.csv): only 2 rows carry the AE Gutenberg-Richter formula (A03-0040) and a citation (A03-0076). No numerical AE event catalogue (amplitude/event list) exists in the corpus → b_ae NOT COMPUTABLE from current data. Data gap flagged.
- Falsifier F_B1: b values differ > 3*sigma AND no known scale effect → reject bridge. Since b_ae undefined, bridge is INCONCLUSIVE-DATA_GAP (cannot accept or reject).
- Bridge strength: WEAK (data gap; awaiting AE amplitude/event list from owner or new source).

## Artifacts
- comcat_cache.sha256 (if fetched)
- bfit.json (estimator outputs)
- plot description (text only)


---
## Revised Edition (`MSL-ADD-01`) Verdict Addendum
- **Deccan Region USGS ComCat Gutenberg–Richter Fit (`Ellora ±10°`, 2000–2026, $M_c = 4.4$, $N = 492$):** $b = 1.2532$, $\text{CI}_{95}\ [1.1292, 1.3900]$ — **`SUPPORTED` (`OWN-TEST`)**.
- **Laboratory AE / NME Slow-Dynamics Comparison:** **`PROPOSED-INCOMPLETE`** (`DATA_GAP` on raw AE event list; `nme_fit.json` voided per `D2`; paired with internal digitization test **`T-1`** and core bench test **`T-2`**).
