# DEFERRALS — XTR-01 Track B

| Item | Reason | Cost / next step | Falsifier |
| :--- | :--- | :--- | :--- |
| BRIDGE B1 (lab AE vs ComCat b/p) | No open acoustic-emission catalogue fetched in this session; directive forbids substituting a figure read off a plot | Locate Zenodo/PANGAEA/journal supplementary AE catalogue; cite and hash; then fit b and p with Aki 1965 MLE | b or p differ beyond 2σ |
| BRIDGE B2 (rock memory vs cell memory) | No digitised NME recovery or cellular mechanical-memory curves available | Digitise published curves (tag DERIVATION); attempt log-time, stretched-exponential and PM-space fits | Biological curve not fit at AIC parity, or timescales differ >10³ without scaling variable |
| `already_in_ledger` coverage (R5) | claims_ledger.csv indexes Task reports, not Article 02 / Master Report lines | Verifier samples 10% and maps manually | Coverage <80% reported as a result |
| Literature anchors not re-fetched | Hore & Mouritsen 2016, Xu 2021, Coste 2010, Yang 2014, Goodkind 1999, Stray 2022, Vallée 2017, Touboul 2022, Schumann references | Fetch and hash before any row is cited as SOURCE | — |
| FDTD reconciliation (V3) | Analytic 1.57 Pa/m vs FDTD 1.74 Pa/m, not run to steady state | Run sim_cavity_acoustics to steady state | — |
| Onion φ_skin threshold | No direct measurement; derived from bulk invisibility argument | Requires geodesy uncertainty refinement and skin-fraction measurement | φ_skin above threshold makes lens visible to bulk constraints |
| Bench protocols | No new bench work per R14 | Written only; costed separately | — |
| **`T-1` Raw NME Digitization (`D2`)** | `AgentA/outputs/nme_fit.json` fitted an analytical log curve to itself ($R^2=1.0$) and has been voided | Digitize raw TenCate & Shankland (1996) / TenCate et al. (2000) $\Delta f/f_0$ vs. $\log_{10}(t)$ points (`SOURCE`) and refit slow-dynamics slope | Slope differs from $-1/\ln(10)$ or KWW beats log-time by $\Delta\text{AIC} > 2$ |
| **`R14` Citation Registration (`B3, B4, B6` — `D4`)** | `Ritz 2004`, `Hore & Mouritsen 2016`, `Xu 2021`, `Coste 2010`, and `Saunders 1984` were cited from secondary knowledge without primary PDF fetch | Fetch primary PDFs, compute SHA-256 hashes, and register in `citations_xtr.jsonl`; until then all stay tagged *(not re-fetched)* and `PRIOR-CONSTRAINED` | Primary threshold differs by $>10\times$ from quoted bar |
| **`L3` Memory Exponent Normalization (`D7`)** | `L3_MEMORY_LADDER_v2.csv` compares dimensionless power-law exponents ($b=1.2532$, $p\approx 1$) with dimensional relaxation times (hours/days) | Normalize all `L3` entries into dimensionless logarithmic decay rates $d(\ln \mathcal{M})/d(\ln t)$ | Normalized rates fail to cluster across scales |
