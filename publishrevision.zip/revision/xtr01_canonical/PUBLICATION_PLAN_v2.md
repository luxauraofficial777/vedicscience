# XTR-01 CANONICAL MERGED PUBLICATION PLAN (`PUBLICATION_PLAN_v2.md` — Remediation `D9`)

Merges Track B's 5-paper roadmap and pre-registered `T-1..T-9` test queue with Track A's target venue matrix and 8 figure specifications.

## Part I — Track B Five-Paper Roadmap & Pre-Registered Test Queue (`T-1` to `T-9`)

# PUBLICATION PLAN — XTR-01 (revised corpus)

| ID | Working title | Contents | Consumed XTR-01 deliverables | Defects to close before drafting (FINAL_MASTER §7) |
| :--- | :--- | :--- | :--- | :--- |
| P1 | Nonlinear mesoscopic acoustics of basalt: softening, holding power and seam-selective excavation | Engineering core with v2 numbers; holding-power bound; seam-area leverage from onion lens (structure, not engine); 34 Hz extrapolation as stated hypothesis; FDTD reconciled | STRESS_LEDGER (ST01–ST04, ST07), BRIDGE_B6, L1 ladder, onion synthesis | FDTD V3 reconciliation (analytic 1.57 vs 1.74 Pa/m); remove Re[D]=0.450 chain (C2); no allegory or Vedic material |
| P2 | Scale-invariant hysteresis from cells to crust? A cross-domain test | L3, B1, B2, L1 as negative control; publishable either way | L1, L2, L3 ladders, BRIDGE_B1 (deferred), BRIDGE_B2 (deferred), BRIDGE_B4, BRIDGE_B5 | B1/B2 must be executed or explicitly reported as deferred; no HYPOTHESIS in results (discussion only) |
| P3 | The Lux Aura schematic and semantic layer | 17 schematics, glossary, Λ_sl/Ξ_23D/P_bs/V(1..17) as governance allegory, Vedic concordance with both readings (R9) | semantic_glossary.csv, PREREG.md | All physics claims removed; allegory tags only; no unverified citations |
| P4 | A machine-verifiable claim ledger: hash-pinned provenance applied to a speculative corpus | Mandate M1–M10, R1–R16, independence score, eigenmode method, docket 1000× error and 3.6×10⁻¹⁰ slip as worked examples, governance benchmark vs REANA/DPHEP/IMAS | hard_data_extract.csv, citations_xtr.jsonl, outputs/MANIFEST.sha256, VERIFICATION_MATRIX_01 | R16 prose-vs-COMMAND diff clean; 13 assertion-backed claims and 14 unnamed sources resolved or flagged; six superseded values purged |

**THEOREM_DOCKET_v2 (owner-owned):** agents supply corrected §7b (4.7×10⁻¹¹, not 5×10⁻¹⁴), §11-item-14 citations, B6 prior for E1, and BP ceiling sentence for A3-weak.

---

## Part II — Track A Joint Architecture, Target Venues & Graphic Specifications

# XTR-01 Joint Publication Plan (Track A contribution)

## Goal
Revised publication separating hard data vs semantics, with three bridges (B1,B2 and Track B B3–B6), stress-test theorems, use only `_v2` originals.

## Track split (owner)
- Track A (Big Pickle): Article 03 + Tasks 01–05 → hard_data_extract.csv, glossary (my share), L1/L3, BRIDGE_B1, BRIDGE_B2.
- Track B (beam-free): Article 02 + Master Report → L2, B3–B6, joint tables.
- Verifier: VERIFY folder; independent Phase 5.

## Sections
1. Introduction (problem, scope, R1–R16 compliance)
2. Methods (determinism, SHA-256, extraction rules, estimators Aki+bootstrap, AIC, PM)
3. Hard Data (tables from CSVs, units, model citations)
4. Semantic Layer (glossary with physical referent or ALLEGORY)
5. Bridges (B1–B6 with scale ladders L1–L3)
6. Stress Tests (seven theorems + falsifiers F_B1,F_B2,...)
7. Results/Discussion (admissible only where DATA/SUPPORTED)
8. Limitations + Seed corrections (E4 δg/g 4.7e-11 noted if used)
9. Appendices (manifests, scripts, JSON artifacts)

## Artifacts checklist (Track A)
- [x] hard_data_extract.csv (382 rows)
- [x] semantic_glossary.csv (98)
- [x] L1_STRAIN_LADDER.csv (40)
- [x] L3_MEMORY_LADDER.csv (11)
- [x] BRIDGE_B1.md — quantitative: ComCat Deccan b=1.25 CI95 [1.13,1.39] (Mc=4.4); AE side DATA_GAP (no AE event catalogue in corpus)
- [x] BRIDGE_B2.md — quantitative: quadratic softening wins AIC (-43.67 vs linear -38.79); PM fit + time-domain recovery DATA_GAP (needs minor loops / more time points)
- [x] bfit_comcat.json, nme_fit.json, pm_fit.json
- [ ] contribution merged with Track B glossary (awaiting Track B)

## Phase timeline
- Phase 0: extraction/glossary/ladders (this commit set) — DONE Track A part.
- Phase 1: B1 quantitative (Aki+bootstrap) — planned (need ComCat window pre-logged; cache).
- Phase 2: B2 fits (AIC+PM) — planned.
- Phase 3: merge bridges/ladders joint.
- Phase 4: stress tests.
- Phase 5: independent verification.

## Compliance notes
- Originals read-only; no re-verify closed SPH-01/E4.
- E4 UL correction: δg/g = 4.7×10⁻¹¹ (docket §7b misprint) — flag if referenced.
- Onion lens only BP form admissible; not used here.
