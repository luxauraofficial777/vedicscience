# STRESS TEST — XTR-01 Track B

## Seed computations (COMMAND where marked)

- **Q⁻¹ = 1:** ε = 3π/(4α_G) = 3π/(4×2500) = 9.42×10⁻⁴. Module VII's 10⁻³ is past this limit.
- **S = 0:** solve 1 − α_G(ε−ε_th) + 0.75δ_G ε² = 0 with α_G=2500, δ_G=−4×10⁶, ε_th=10⁻⁶ → ε ≈ 2.96×10⁻⁴.
- **Holding power at 34.4 Hz:** q̇ = 7.256 MW/m³ × (34.4/21500) = 1.16×10⁴ W/m³; 25 kW conditions 2.15 m³ (625× the ultrasonic volume). Assumes the NME law holds at 34 Hz.
- **Degeneracy lift:** ΔL_z > 1/Q × L_z = (1/1941.3) × 2.5 m = 1.29×10⁻³ m (1.3 mm); every real chamber splits the six degenerate pairs.
- **E4 UL vs stations:** UL ∝ 1/√N → 0.145 nm/s² at N=10, 0.0838 nm/s² at N=30 (baseline 0.459 nm/s², 1 station).
- **Energy gate:** f = E/h → 4 eV bond 9.67×10¹⁴ Hz (≈9.7×10¹⁴; directive quotes 9.69×10¹⁴); ATP 7.64×10¹³ Hz = 3.82×10⁹ × 20 kHz.
- **Onion lens:** φ_skin ≳ 10⁻⁴–10⁻⁵ (O(1) density contrast at the surface) shifts I/MR² by more than its ~10⁻⁵ geodesy precision; below that it stays invisible to the bulk constraint.
- **Berktay:** −86.2 dB at 7 Hz; −98.2 dB at 3.5 Hz (−12 dB/octave).
- **Momentum no-go:** never breaks for a closed cavity; breaks only for a field coupling (κ from B6, ~6.8×10⁻⁴ required vs ~1×10⁻¹¹ allowed).
- **Griffith:** never breaks; identity, exact for linear elastic fracture only.
- **Kepler:** restored only if ω_eff ∝ r^(−3/2); any other exponent fails.

## Revised statements
Each theorem keeps its stated domain: NME softening valid only ε < 2.96×10⁻⁴ (the zero-modulus root of the backbone polynomial; the loss model itself leaves its domain separately at Q⁻¹ = 1, ε = 9.42×10⁻⁴); holding-power extrapolation to 34 Hz is a stated hypothesis; cavity "second harmonic" is two split modes in any real chamber; E4 limits tighten as 1/√N; energy gate forbids acoustic quanta from driving chemistry; onion lens remains invisible to bulk constraints only for φ_skin below ~10⁻⁴.

---
## Remediation `D6` Note (`CORPUS_INTEGRATION_REPORT_XTR01.md` §4)
- **Zero-Modulus Polynomial Root ($\mathcal{S}(\varepsilon) = 0$):** $\varepsilon = \mathbf{2.96 \times 10^{-4}}$ (`COMMAND`).
- **Unit Loss Tangent Limit ($Q^{-1}(\varepsilon) = 1$):** $\varepsilon = 3\pi / (4\alpha_G) = \mathbf{9.42 \times 10^{-4}}$ (`DERIVATION`).
- Both thresholds lie below the v1 Module VII bulk-vitrification claim ($\varepsilon = 10^{-3}$, where $\mathcal{S} = -4.50 < 0$ and $Q^{-1} = 1.061 > 1$), which remains **`INCONSISTENT`**.
