# BRIDGE B3 (Canonical v2) — Radical-Pair Magnetoreception (`CRY4`) ↔ Schumann / Geomagnetic Fields (Remediated per `D4` & `D8`)

**Revised Edition Verdict (`MSL-ADD-01`):** **`SUPPORTED`** (internal ratio arithmetic: $35.7\ \mu\text{T} / 1\text{ pT} = 3.57 \times 10^7$, or $3\text{ mT} / 1\text{ pT} = 3 \times 10^9$) · **`PRIOR-CONSTRAINED`** (external biological radical-pair bars: Ritz et al. 2004, Hore & Mouritsen 2016, Xu et al. 2021 — all tagged *(not re-fetched)* per `Rule R3`/`D4`).

# BRIDGE B4 — Radical-pair magnetoreception ↔ geomagnetic / Schumann fields

**Status:** COMPLETE (derivation). **Revised Status (`MSL-ADD-01`):** `PRIOR-CONSTRAINED` (Schumann amplitude below reported cryptochrome resolution by >10³). **Evidence class:** DERIVATION.

**Anchor A (biology):** Cryptochrome 4 (Xu et al., *Nature* 594, 535 (2021)): photoinduced flavin–tryptophan radical pairs with lifetimes >10 µs; magnetic field effects measured in vitro with B₁/₂ ≈ 3–4 mT (Hore & Mouritsen, *Annu. Rev. Biophys.* 45, 299 (2016)). Sensitivity is to mT-scale changes in field magnitude/direction, not to pT.

**Anchor B (geophysics):** Schumann resonance magnetic component ~1–10 pT (fundamental 7.83 Hz, not re-fetched); static geomagnetic field ≈ 50 µT = 5×10⁻⁵ T.

**Ratio Schumann / static:** (1×10⁻¹² T)/(5×10⁻⁵ T) = 2×10⁻⁸ (for 1 pT); (1×10⁻¹¹)/(5×10⁻⁵) = 2×10⁻⁷ (for 10 pT).

**Comparison:** Schumann amplitude is 6–7 orders of magnitude below the ~mT B₁/₂ scale of in-vitro CRY4 magnetosensitivity and 8 orders below the 50 µT static field. No amplification mechanism in the cited literature closes a 10³ gap.

**Domain of validity:** in-vitro CRY4 spectroscopy; assumes no biological amplification/filtering not present in the cited data.

**Falsifier:** if the Schumann magnetic amplitude is below the reported radical-pair resolution by more than 10³, the "Schumann–brain" claim is `PRIOR-CONSTRAINED` by 7–9 orders of magnitude against published in-vitro CRY4 bars *(not re-fetched)*. (Satisfied.)