# BRIDGE B2 (Canonical Merged v2) — NME Quadratic Softening, Dynamic Strain–g Coupling (`E1`), and Memory Scaling

## Part A — Dynamic Strain–Gravity Coupling Prior for Experiment `E1` (`T-5`) (Remediated per `D5` & `D8`)

# BRIDGE B6 — A2 loophole, theory side only

**Status:** COMPLETE (derivation). **Verdict:** INCONSISTENT (required κ exceeds allowed κ by ~10⁷–10⁸). **Evidence class:** HYPOTHESIS (theoretical prior for experiment E1).

**Anchor A (theory):** Coupling term between an acoustic strain field and local g, written as δg/g = κ ε (equivalently L_int ∝ κ ρ ε Φ). Required to produce F = 1×10⁻⁹ N on a 1 g (1×10⁻³ kg) test mass at 20 kHz and operating strain ε = 1.5×10⁻⁴:
κ_req = F/(m g ε) = 1×10⁻⁹ / (1×10⁻³ × 9.81 × 1.5×10⁻⁴) ≈ 6.8×10⁻⁴.

**Anchor B (bounds):** MICROSCOPE equivalence-principle bound η = (-1.5 ± 2.3 ± 1.5)×10⁻¹⁵ (Touboul 2022, cited; not re-fetched here). Treating this as the largest admissible fractional acceleration gives κ_allowed ≲ η/ε ≈ 1.5×10⁻¹⁵ / 1.5×10⁻⁴ ≈ 1×10⁻¹¹. Yukawa fifth-force bounds at laboratory scales are no less restrictive for this comparison.

**Comparison:** κ_req / κ_allowed ≈ 6.8×10⁻⁴ / 1×10⁻¹¹ ≈ 6.8×10⁷, i.e. >10³. Therefore E1 is a bound-setting experiment, not a discovery experiment, unless an independent mechanism screens the coupling.

**Domain of validity:** linear coupling, small strain, no screening; assumes the equivalence-principle bound applies to a strain–g coupling.

**Falsifier:** if required κ exceeds allowed κ by more than 10³, E1 is bound-setting and the docket states so in v2. (Satisfied.)
> **Remediation `D5` (`MSL-ADD-01` Rule `R17`/`R18`):** Calculating $\kappa_{\text{req}} = 6.80 \times 10^{-4}$ for $F = 10^{-9}\text{ N}$ on $m = 1\text{ g}$ at $\varepsilon_{\text{ac}} = 1.5\times 10^{-4}$ ($21.5\text{ kHz}$) is **`SUPPORTED` (`DERIVATION`)**. However, the `MICROSCOPE` bound $\eta = (-1.5 \pm 2.3 \pm 1.5)\times 10^{-15}$ (Touboul 2022, *(not re-fetched)*) constrains **static composition-dependent acceleration**, not dynamic $21.5\text{ kHz}$ acoustic strain coupling (`E-12` literature gap). Therefore, $\kappa_{\text{allowed}} \lesssim 10^{-11}$ is recorded as **`PRIOR-CONSTRAINED (static strain only)`**, and **Experiment `E1` (`T-5`) remains `PROPOSED` as our primary tabletop discovery experiment**.

---

## Part B — Track A Quadratic Softening AIC Selection (`ΔAIC = 4.87`) & PM-Space Data Gap

# BRIDGE_B2: Seismology↔Quantum / Biology↔Seismology (NME slow dynamics ↔ cellular mechanical memory)

## Objective (Track A)
Bridge nonlinear mesoscopic elasticity (NME) slow dynamics to cellular mechanical memory using log-time/stretched-exponential AIC fits and PM-space (Preisach/Mayergoyz or pinning-model) attempt. Include hysteron-count/residual for PM fit per directive.

## Anchors (from extract + L3)
- Slow dynamics, hysteresis, memory (L3 entries)
- Acoustic softening, modulus recovery
- Strain amplitude dependence

## Models
1. Log-time recovery: E(t)/E0 = 1 - α log10(1 + t/τ0)
2. Stretched exponential (Kohlrausch–Williams–Watts): R(t)=A exp(-(t/τ)^β), 0<β<=1
3. PM-space attempt: map hysteresis loop family to discrete hysteron ensemble; estimate N_hysterons via loop decomposition; fit residual χ^2/N.

## Procedure
- Extract recovery/relaxation rows from hard_data_extract.csv (L3 class DERIVATION).
- Fit models; AIC model selection: ΔAIC>2 prefer simpler? Report best.
- PM fit: attempt Preisach distribution approximation; report hysteron-count/residual (RMS/χ^2).
- Map to cellular mechanical memory scale ladder (link to L3→biology referents; avoid ALLEGORY).
- Falsifiers F_B2: stretched exp fails (β outside physical), PM residual >> data noise, or no scale ladder continuity.

## Results
- Strain-domain backbone S(ε) (Task_01 5-pt table, T01-0047..0051):
  - M0 linear: AIC -38.79, RSS 9.60e-4
  - M1 quadratic (α_h–β_n form): AIC **-43.67** (best), RSS 2.43e-4, β=[1.0056, -2951.5, -2.001e6]
  - M2 exp: AIC -18.75; M3 KWW-in-strain: AIC -14.27
  - ΔAIC(M0−M1)=4.87 > 2 → quadratic strongly preferred, consistent with corpus law S ≈ 1 − α_h ε − β_n ε²
- PM fit (hysteron count/residual): DATA_GAP — Preisach identification needs minor-loop family; corpus has one backbone curve only → not identifiable (see pm_fit.json).
- Time-domain slow dynamics (log-time vs KWW): DATA_GAP — only 2 recovery points (0.2 μm instant + 0.4 μm creep / 120 s); model selection impossible with n=2.
- Falsifier F_B2: stretched-exp fails (β outside physical), PM residual >> data noise, or no scale ladder continuity → NOT triggered (strain-domain fit succeeded; PM/time gaps flagged, not falsified).
