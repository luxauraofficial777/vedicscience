import csv
import json
import math
import random
from pathlib import Path

OUT = Path(r"C:\LuxAura\study\AgentA\outputs")
SEED = 20261018
BOOT_N = 1000
DELTA = 0.1  # bin width for Mc (max-curvature)

def aki_b(mags, mc):
    mags = [m for m in mags if m >= mc - 1e-9]
    if not mags:
        return None
    mean = sum(mags) / len(mags)
    if mean - mc <= 1e-9:
        return None
    return math.log10(math.e) / (mean - mc)

def max_curvature_mc(mags, delta=DELTA):
    # standard max-curvature: Mc = mode of NON-cumulative frequency-magnitude counts
    lo = min(mags)
    hist = {}
    for m in mags:
        b = round((m - lo) / delta)
        hist[b] = hist.get(b, 0) + 1
    if not hist:
        return lo
    best_k = max(hist, key=lambda k: hist[k])
    return lo + best_k * delta

def main():
    mags = []
    with (OUT / "comcat_deccan_raw.csv").open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            try:
                mags.append(float(row["mag"]))
            except (TypeError, ValueError):
                pass
    if not mags:
        print("NO_DATA")
        return
    mc = max_curvature_mc(mags)
    b_mle = aki_b(mags, mc)
    if b_mle is None:
        print("MC_FAILED", mc)
        return
    n_mc = len([m for m in mags if m >= mc])
    # bootstrap CI
    rng = random.Random(SEED)
    bs = []
    for _ in range(BOOT_N):
        samp = [mags[rng.randrange(len(mags))] for _ in range(len(mags))]
        bb = aki_b(samp, mc)
        if bb is not None:
            bs.append(bb)
    bs.sort()
    lo = bs[int(0.025 * len(bs))]
    hi = bs[int(0.975 * len(bs))]
    result = {
        "catalogue": "USGS ComCat (circle ~ Ellora, bbox 9.88-29.88N/65.17-85.17E)",
        "window": "2000-01-01..2026-10-18, M>=2.5",
        "n_total": len(mags),
        "n_at_or_above_mc": n_mc,
        "Mc_maxcurvature": round(mc, 3),
        "b_aki_mle": round(b_mle, 4),
        "b_bootstrap_CI95": [round(lo, 4), round(hi, 4)],
        "b_sd_bootstrap": round(
            math.sqrt(sum((x - b_mle) ** 2 for x in bs) / len(bs)), 4
        ),
        "seed": SEED,
        "boot_n": BOOT_N,
        "delta_bin": DELTA,
    }
    (OUT / "bfit_comcat.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
