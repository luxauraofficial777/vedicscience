# BRIDGE B4 (Canonical v2) — Prompt Elastogravity Signals (`PEGS`) ↔ Biological Gravisensing (Remediated per `D4` & `D8`)

**Revised Edition Verdict (`MSL-ADD-01`):** **`SUPPORTED`** (internal ratio arithmetic: $\Delta g_{\text{bio}} / \Delta g_{\text{PEGS}} = 10^{-2}\text{ m/s}^2 / 10^{-9}\text{ m/s}^2 = 1.0 \times 10^7$) · **`PRIOR-CONSTRAINED`** (external otolith/statolith/Piezo threshold bars *(not re-fetched)*).

# BRIDGE B5 — Prompt elastogravity signals (PEGS) ↔ biological gravisensing

**Status:** COMPLETE (derivation). **Revised Status (`MSL-ADD-01`):** `PRIOR-CONSTRAINED` (gap ≈10⁷). **Evidence class:** DERIVATION.

**Anchor A (geophysics):** PEGS amplitude ~1 nm s⁻² = 1×10⁻⁹ m s⁻² (Vallée et al., *Science* 358, 1164 (2017): up to ~1.6 nm s⁻² at 1000–1500 km for Mw 9.1).

**Anchor B (biology):** Otolith / statolith / Piezo gravisensing thresholds ≈10⁻³ g ≈1×10⁻² m s⁻² (Coste et al., *Science* 330, 55 (2010); mechanobiology reviews).

**Gap:** (1×10⁻²)/(1×10⁻⁹) = 1×10⁷.

**Conclusion:** No organism whose gravisensing threshold is ~10⁻² m s⁻² can detect a ~10⁻⁹ m s⁻² PEGS. The "animals sense the gravity precursor" idea closes at this gap.

**Domain of validity:** compares sustained-acceleration biological thresholds with transient PEGS amplitudes; frequency-dependent vestibular sensitivity and possible stochastic pooling are not included in the cited anchors.

**Falsifier:** a gap >10⁴ closes the idea; a gap <10 opens it. (Gap = 10⁷, closes.)