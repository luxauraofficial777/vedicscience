# BRIDGE B6 (Canonical v2) — Lunar Synodic Gravimetry (`E4`) ↔ *Nautilus* Shell Banding & `A2` Field Coupling (Remediated per `D4, D5, D8`)

## Part 1 — Lunar Synodic Gravimetry (`E4`, $29.53\text{ d}$) vs. *Nautilus* Chamber Growth Lines
- **In-House Gravimetry (`E4` `OWN-TEST`):** At the $29.530589\text{ d}$ lunar synodic period, our pre-registered IGETS Level-3 residual search bounds any coherent surface gravitational modulation to $\text{UL} = 0.459\text{ nm/s}^2$ ($\delta g/g < \mathbf{4.68 \times 10^{-11}}$) — **`CONTRADICTED`** as a direct gravitational forcing mechanism.
- **External Biological Bar (*Nautilus pompilius* ~30 lines/septum, Saunders 1984 *(not re-fetched)*):** Recorded under `MSL-ADD-01` (`Rule R17`, `D4`/`D8`) as **`PRIOR-CONSTRAINED`** (biological lunar periodicity is mediated by optical moonlight and tidal-current foraging depth cues rather than a $\delta g/g \sim 10^{-11}$ gravitational anomaly).

## Part 2 — Dynamic Acoustic Strain–Gravity Coupling (`E1` / `T-5`, Remediation `D5`)
- Required coupling for $F = 10^{-9}\text{ N}$ on $m = 1\text{ g}$ at $\varepsilon_{\text{ac}} = 1.5\times 10^{-4}$ ($21.5\text{ kHz}$): $\kappa_{\text{req}} = \mathbf{6.80 \times 10^{-4}}$ (**`SUPPORTED` `DERIVATION`**).
- Static equivalence-principle bar: $\kappa_{\text{allowed}} \lesssim 10^{-11}$ (**`PRIOR-CONSTRAINED` on static $\omega \to 0$ media only**).
- Dynamic $21.5\text{ kHz}$ coupling remains unsearched in the literature (`E-12` gap) and is **`PROPOSED`** for tabletop test **`E1` (`T-5`)**.
