# Extrapolation report — XTR-02 pass 2 (beam-free)

Script: `scripts/extrapolate.py` — exit code 0. Outputs: `outputs/extrapolation_summary.json`, `outputs/extrapolation_values.json`, `outputs/extrapolation_chart.png`, `outputs/MANIFEST.sha256`.

## B4 — Schumann-band magnetic amplitude vs cryptochrome resolution

- Schumann amplitude / static field (50 uT): 1e-12 / 5e-5 = 2e-08.
- Cryptochrome resolution (from 1 us coherence, 28 kHz/uT): 3.571428571428572e-05 T (35.714285714285715 uT).
- Gap (resolution / Schumann): 35714285.71428572.
- Verdict: INCONSISTENT.

## B5 — PEGS vs biological gravisensing

- PEGS amplitude: 1e-09 m/s^2. Biological threshold: 1e-02 m/s^2.
- Gap: 10000000.0.
- Verdict: INCONSISTENT.

## B6 — kappa required vs MICROSCOPE bound

- kappa_required: 0.0006795786612300374.
- kappa_allowed: 1e-11.
- Ratio: 67957866.12300375.
- Verdict: INCONSISTENT.

## B2 — Memory timescale comparison

| Domain | Timescale (s) | log10 | Functional form |
|---|---|---|---|
| NME slow dynamics (TenCate 2000) | 1000.0 | 3.0 | Log-time recovery: modulus vs log t |
| Cellular mechanical memory (Yang 2014) | 86400.0 | 4.936513742478893 | Decay over days (stretched exponential candidate) |
| Crustal poroelastic (BP) | 31557600.0 | 7.499103967085228 | Non-stationary chi2/dof (year-to-year pore storage) |

Ratios: cell/NME = 86.4; crust/cell = 365.25; crust/NME = 31557.6.

## L3 — Shared functional form?

Computed table of timescales and forms above; forms differ (log-time vs stretched-exponential candidate vs year-to-year non-stationary). Shared functional form: false. Verdict: INCONSISTENT. Full ladder: 8 rows (see `outputs/extrapolation_values.json`).
