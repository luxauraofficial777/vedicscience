# L1 Strain Ladder

Question: at what strain do biology and crust overlap?

Pre-registered expectation: cells and bone respond at 1e-3 to 1e-1, rock NME at 1e-6, tides at 1e-8; biological strain thresholds are reached by rock only at failure and by the crust only in near-field strong motion. If that holds, "cells feel the Earth" is false at the strain level and any biology-seismology bridge must go through a different variable (acceleration, acoustic pressure, or field), which L2/B4/B5 test.

Rows: 11 (Piezo1 gating through near-field strong motion). Computed column: log10_min, log10_max, log10_range. Float format %.6g. LF.