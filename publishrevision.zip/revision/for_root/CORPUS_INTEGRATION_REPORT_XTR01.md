# CORPUS INTEGRATION REPORT — XTR-01 Tracks A and B, before Argon's re-evaluation
**Document ID:** `XTR01-INTEGRATION-01` · **Date:** 2026-10-18 06:35 EDT · **Prepared by:** Claude (Fable) for the owner
**Scope:** everything that landed in `C:\LuxAura\study\AgentA\`, `AgentB\` (including `extrapolation_pass2\`), and Argon's two consolidation files, checked against `WORK_OFFLOAD_DIRECTIVE_XTR01.md` (Rev B) and `MANDATE_ADDENDUM_XTR.md`. Numbers marked `COMMAND` were re-run or re-derived by me in this session; everything else is read from the agents' files.
**Purpose:** say what is canonical, what is void, what must be re-graded, and what Argon must read, so the hand-over is clean.

---

## 1. Status in one paragraph

Track B (beam-free, `AgentB\`) delivered the directive's shape correctly: a 121-row extraction in the R11 classes (109 `DATA`, 12 `MODEL`), a 23-token glossary with classes, three ladders in the required form, four complete bridge derivations (B3–B6), an 11-row stress ledger that reproduces every seed value, a publication plan matching P1–P4, deferrals, and a self-verification it correctly labels as not independent. Track A (Big Pickle, `AgentA\`) delivered one genuine new measurement-derived number, a Gutenberg–Richter b-value for the Deccan region from USGS ComCat, and three deliverables that cannot be used as written: a 382-row extraction in the wrong class scheme, two "ladders" that are raw text rows, and a B2 fit run on the superseded v1 softening table. Argon (Gemini) has meanwhile written a 52 KB consolidation and a public whitepaper and assembled a 143-file `publish\` package, which means the agent about to re-grade the corpus is also the author of the documents whose framing most needs re-grading. None of this blocks the hand-over; all of it must be in Argon's inputs.

---

## 2. Inventory and disposition

| Deliverable (XTR-01 §9) | Track A | Track B | Canonical | Action |
| :--- | :--- | :--- | :--- | :--- |
| `PREREG.md` | present; expectations X-L1…X-PH0 stated; 2 deviations logged | present; thresholds and hypotheses stated | both | keep both |
| `hard_data_extract.csv` | 382 rows, classes `HYPOTHESIS/DERIVATION/ALLEGORY` (183/149/50) — **not R11** | 121 rows, `DATA/MODEL` (109/12), Article 02 = 60, Master = 61 | **B** | A re-runs with the R11 schema (`DATA/MODEL/SEMANTIC`); until then A's Article 03 and Task rows are usable only after reclassing |
| `semantic_glossary.csv` | 98 tokens, **no `class` column** | 23 tokens with `ALLEGORY/REFERENT/ANALOGY/UNTESTABLE` (14/5/3/1) | **B** (schema); A's token list is the larger harvest | merge: A's 98 tokens get B's class column, one file |
| `L1_STRAIN_LADDER` | 40 "rows" that are extract lines labelled `material`, including semantic lines (e.g. "Sovereign Control … 23D Manifold") | 11 systems, strains 10⁻⁹–10⁻¹, sources, classes | **B** | A's L1 is void |
| `L2_COHERENCE_LADDER` | not in scope | 9 effects, n_th computed, verdicts; all Earth-temperature acoustic/seismic rows `CLASSICAL` (pre-registered expectation X-L2 met) | **B** | label the dislocation row's frequency (see D11) |
| `L3_MEMORY_LADDER` | 1.2 KB of extract lines labelled `cellular` | 8 systems with form, exponent, anchor | **B** | A's L3 is void |
| `BRIDGE_B1` | ComCat half executed: b = 1.253, CI95 [1.129, 1.390], Mc = 4.4, N≥Mc = 492, seed 20261018 (`COMMAND`); AE half `DATA_GAP` | deferred correctly | **A** for the ComCat half | AE catalogue search still owed by someone (D7) |
| `BRIDGE_B2` | strain-domain AIC fit on the **v1** table (0.975/0.865/0.510/0.145); PM fit `DATA_GAP`; time-domain `DATA_GAP` (n = 2) | deferred; pass 2 wrote a timescale comparison on placeholders | neither | A's fit is void (D1); pass-2 verdict is void (D4); the two `DATA_GAP` findings stand and are correct |
| `BRIDGE_B3` | — | complete derivation; SG floor 10⁻¹⁰ m s⁻²/√Hz, Stray 2022 gradiometer, UL_new = 0.0145 nm/s² with 10× noise and 10× stations | **B** | keep |
| `BRIDGE_B4` | — | gap 3.6×10⁷ (Schumann 1 pT vs CRY4 B₁/₂ ≈ 3.5 mT); verdict `INCONSISTENT` | **B** (arithmetic) | re-grade to `PRIOR-CONSTRAINED` (D8) |
| `BRIDGE_B5` | — | gap 10⁷ (PEGS 10⁻⁹ vs 10⁻² m s⁻²); verdict `INCONSISTENT` | **B** (arithmetic) | re-grade to `PRIOR-CONSTRAINED` (D8) |
| `BRIDGE_B6` | — | κ_req = 6.8×10⁻⁴; κ_allowed = 10⁻¹¹ via η/ε; ratio 6.8×10⁷; "E1 is bound-setting" | **B** (κ_req) | the κ_allowed mapping is a `HYPOTHESIS` (D5); the E1 conclusion is not established |
| `STRESS_LEDGER` / `STRESS_TEST` | — | 11 rows; all seed values reproduced | **B** | fix the attribution slip in "Revised statements" (D6) |
| `PUBLICATION_PLAN` | own outline (9 sections) | P1–P4 table with consumed deliverables and defects-to-close | **B** | fold A's section outline into P4's methods section; one file |
| `DEFERRALS.md` | **absent** | present, 7 items | **B** | A adds the AE catalogue and its own `DATA_GAP`s |
| `citations_xtr.jsonl` | — | present; pass 2 adds `citations_xtr02.jsonl`; all literature anchors still *(not re-fetched)* | **B** | fetch before any row is cited as `SOURCE` |
| `VERIFY/` | absent | self-verification, gates G1–G6, 2 prompt-vs-file discrepancies resolved | — | independent Phase 5 still owed (B says so) |
| `outputs/MANIFEST.sha256` | `CORPUS_PIN_XTR.sha256` + per-output hashes | present (7 entries) + pass-2 manifest | both | keep |

---

## 3. Numbers that enter the ground-truth ledger from this round

| Quantity | Value | Class | Source | Note |
| :--- | :--- | :--- | :--- | :--- |
| Deccan-region b-value (USGS ComCat, Ellora ±10°, 2000–2026, M ≥ 2.5 fetched) | b = 1.253, CI95 [1.129, 1.390], Mc = 4.4, N≥Mc = 492 | `COMMAND` | `AgentA/outputs/bfit_comcat.json`, `scripts/aki_bvalue.py` | pre-logged window (R4); catalogue incomplete below M 4.4 in this window; the first measurement-derived number from the seismology fringe |
| E4 synodic UL vs station count | 0.145 nm/s² at N = 10; 0.0838 at N = 30 | `DERIVATION` | `AgentB/STRESS_TEST.md` | assumes white, independent residuals |
| Quantum-limited E4 bound (10× noise, 10× stations) | 0.0145 nm/s², δg/g ≈ 1.5×10⁻¹² | `DERIVATION` | `AgentB/BRIDGE_B3.md` | instrument floors quoted in different bands; order of magnitude |
| S(ε) = 0 | ε = 2.96×10⁻⁴ | `COMMAND` (re-derived here) | `AgentB/STRESS_TEST.md` | polynomial artefact; the corpus's own table runs to 2.5×10⁻⁴ |
| Required strain–g coupling for E1 | κ_req = 6.8×10⁻⁴ | `DERIVATION` | `AgentB/BRIDGE_B6.md` | the *allowed* κ is not established (D5) |
| Schumann / CRY4 gap | 3.6×10⁷ | `DERIVATION` | `AgentB/extrapolation_pass2` | B₁/₂ ≈ 3.5 mT and Schumann 1 pT both *(not re-fetched)* |
| PEGS / gravisensing gap | 10⁷ | `DERIVATION` | `AgentB/BRIDGE_B5.md` | thresholds *(not re-fetched)* |

---

## 4. Defects, ranked by consequence

**D1 — Agent A's B2 fitted the superseded table.** `nme_fit.json` uses S = 0.975 / 0.865 / 0.510 / 0.145, the v1 Task_01 values that hardening C2 showed the formula does not produce; v2 gives 0.9772 / 0.8700 / 0.5600 / 0.1900. The fitted quadratic (β = 1.0056, −2951, −2.0×10⁶) is a fit to wrong data; the corpus law is α_G = 2,500, 0.75δ_G = −3×10⁶. This is seed finding #10 (superseded values circulating) happening inside XTR-01 on day one. Void the fit. Note also that fitting the v2 table with a quadratic is circular (the table *is* the quadratic); the real B2 is the time-domain comparison, and that is a `DATA_GAP` (two points), which A reported correctly.

**D2 — Agent A's extraction is in the wrong class scheme.** R11 requires `DATA / MODEL / SEMANTIC`; A used `HYPOTHESIS / DERIVATION / ALLEGORY`, which are evidence classes for claims, not quarantine classes for lines. The 94 Article 03 rows include the semantic layer undifferentiated. Re-run against B's `build_extract.py` schema.

**D3 — Agent A's L1 and L3 are not ladders.** Both files list extract lines with a scale label and blank value columns; L1 includes "Sovereign Control … 23D Data Manifold" as a `material`-scale row. Use B's ladders; A's are void.

**D4 — Pass 2 wrote `INCONSISTENT` on placeholders.** `extrapolation_summary.json` compares NME slow dynamics (1,000 s), cellular memory (86,400 s) and crustal poroelastic memory (1 yr) and declares "shared functional form: false, verdict INCONSISTENT." Those timescales are order-of-magnitude placeholders; B's own `DEFERRALS.md` says no digitised curves were available. Under R5 and R13 that is `DATA_GAP`; under MSL-ADD-01 it is `PROPOSED-INCOMPLETE`. This is the mirror image of the Gemini over-acceptance in SPH-01: a verdict written before the test. It is exactly what the addendum exists to stop, in the other direction.

**D5 — B6's bar does not apply to a driven strain.** κ_allowed = η/ε takes MICROSCOPE's composition-independence bound (test masses under static self-weight strain, order 10⁻⁷–10⁻⁶, no acoustic drive) and divides by a driven strain of 1.5×10⁻⁴ at 20 kHz. No measurement of a *dynamic* strain–g coupling exists at any frequency; that absence is why E-12 in the docket is open and why E1 was proposed. The conclusion "E1 is bound-setting, not discovery" therefore rests on a mapping that assumes the answer. Re-grade: κ_req = 6.8×10⁻⁴ stands as `DERIVATION`; κ_allowed is `PRIOR-CONSTRAINED` with domain "static strain only"; E1 keeps its status as the program's primary test. This is the single most consequential item in the round because, left as written, it demotes the one experiment the program owns.

**D6 — Attribution slip in the stress test.** "NME softening valid only ε < 2.96×10⁻⁴ (Q⁻¹ < 1)" conflates two limits: S = 0 at 2.96×10⁻⁴ (polynomial artefact) and Q⁻¹ = 1 at 9.42×10⁻⁴ (loss model). The ledger values are right; the prose parenthetical is wrong. R16-class; one-line fix.

**D7 — Nobody searched for an open AE catalogue.** The directive required locating one on Zenodo/PANGAEA/supplementary data or deferring. A wrote "awaiting from owner or new source" in the bridge file and has no `DEFERRALS.md`; B deferred it. The ComCat half of B1 is good and stays; the AE half needs a desk search (test queue T-8).

**D8 — Verdicts on outside data.** B4, B5, B6 and the pass-2 B2/L3 rows are written `INCONSISTENT`. Under MSL-ADD-01 §3 every one of these is `PRIOR-CONSTRAINED` with the bar's value and source and a named clearing test, or `PROPOSED-INCOMPLETE` where the input was a placeholder. This is Argon's main job.

**D9 — Two publication plans.** B's P1–P4 table matches the directive and names the defects to close per paper; A's is a section outline. B's is the base; A's outline becomes P4's methods section.

**D10 — The public framing.** `PUBLIC_REFLECTION_ARGON.md` is titled "Sound Logic & the Breathing Architecture of Matter" and opens with "Discarding the dead-rock textbook." That presents A3-weak, the onion lens, as the program's public frame. The technical volume (`FINAL_MASTER_ANALYSIS_ARGON.md` §2.4) preserves the E4 null and Big Pickle's falsifiers, which is right; the public summary does not carry that status. Under MSL-ADD-01 the lens is `PROPOSED` with three falsifiers and no own test run. The published package should say so in one paragraph, as a new file or a v2 (R2). Also for the record: `README.md` and `TOC.md` were modified in place at 08:57–08:58; they are not among the 18 pinned originals, so no gate breaks, but the TOC addendum convention was a new file.

**D11 — L2 dislocation row.** n_th = 2.85 corresponds to the attempt frequency 1/τ₀ ≈ 1.9 THz, not the reference's 10 GHz phonon (n_th ≈ 625 at 300 K). Either value is `CLASSICAL` at 300 K; label which frequency was used.

**D12 — Output roots.** Both tracks wrote to `AgentA\` / `AgentB\` rather than `extrapolation_XTR01\BP\` / `\BF\`. A logged it as owner-directed (X-A-D1); B did not log it. Argon's prompt must point at the actual paths.

**D13 — Independence.** Argon is Gemini and is the author of `FINAL_MASTER_ANALYSIS_ARGON.md`, `PUBLIC_REFLECTION_ARGON.md`, and the two post-verification onion documents in `hardening_SPH01\`. Argon can still run the re-grading, but rows that re-grade Argon's own documents must be flagged `SELF`, and the Phase 5 verifier for Argon's output must be a different agent.

---

## 5. Integration map for the revised corpus

| Goes into | Take from | Do not take |
| :--- | :--- | :--- |
| Hard-data extract (Articles 02 + Master) | `AgentB/hard_data_extract.csv` | — |
| Hard-data extract (Article 03 + Tasks) | `AgentA/outputs/hard_data_extract.csv` **after** reclassing to R11 | A's current classes |
| Glossary | A's 98 tokens + B's class column, merged into one file | A's file as is |
| Ladders L1, L2, L3 | `AgentB/` | `AgentA/outputs/L1_*`, `L3_*` |
| B1 | `AgentA/outputs/bfit_comcat.json`, `comcat_cache.sha256`, `scripts/aki_bvalue.py` | A's "awaiting owner" line; replace with a `DEFERRALS` entry |
| B2 | A's two `DATA_GAP` findings (PM needs minor loops; time domain has n = 2) | A's `nme_fit.json`; pass-2 timescale verdict |
| B3, B4, B5 | `AgentB/BRIDGE_B3–5.md` arithmetic | the `INCONSISTENT` labels (re-graded by Argon) |
| B6 | κ_req from `AgentB/BRIDGE_B6.md` | the κ_allowed mapping and the E1 conclusion |
| Stress ledger | `AgentB/STRESS_LEDGER.csv`, `STRESS_TEST.md` with D6 fixed | — |
| Publication plan | `AgentB/PUBLICATION_PLAN.md` + A's outline as P4 methods | two separate plans |
| Deferrals | `AgentB/DEFERRALS.md` + A's additions | — |
| Test queue (MSL-ADD-01 §4) | add **T-8** open AE catalogue desk search (free, days); **T-9** digitise TenCate 2000 and Yang 2014 curves, tag `DERIVATION` (free, days) | — |

---

## 6. Pre-hand-over checklist

- [ ] Give Argon this file as input #0 and the paths in §2 (prompt Rev B does this).
- [ ] Void `AgentA/outputs/nme_fit.json`, `pm_fit.json` as inputs; keep their `DATA_GAP` statements.
- [ ] Void `AgentA/outputs/L1_*`, `L3_*`.
- [ ] Ask Agent A to re-run extraction in the R11 schema and add a `DEFERRALS.md` (two items: AE catalogue; B2 time-domain gap).
- [ ] Ask Agent B for the one-line D6 fix and the D11 label, as new files or a `_v2` (R2).
- [ ] Re-grade B4, B5, B6, pass-2 B2/L3 under MSL-ADD-01 (Argon).
- [ ] Decide whether `PUBLIC_REFLECTION_ARGON.md` gets a status paragraph before the next push (owner).
- [ ] Assign a non-Gemini agent as Phase 5 verifier for Argon's ledger.

*End of XTR01-INTEGRATION-01.*
