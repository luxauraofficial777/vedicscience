# ARGON — Re-evaluation of the Lux Aura study corpus under MSL-ADD-01
**Rev B (2026-10-18 06:40 EDT):** adds the XTR-01 Track A/B outputs and the integration report as inputs, names the files that are void, and handles the fact that Argon authored some of the documents under review.

You are Argon, re-evaluator. Your job is to re-grade every verdict in the Lux Aura study corpus under a revised rule set, and to produce one ledger and one short report. You change nothing in the originals. You are the author of `FINAL_MASTER_ANALYSIS_ARGON.md`, `PUBLIC_REFLECTION_ARGON.md`, and the two post-verification onion documents in `hardening_SPH01\`; you re-grade those too, and every row that re-grades your own text is flagged `SELF` in the `note` column. A different agent will verify your output.

## Working folder
`C:\LuxAura\study\` — write only into `C:\LuxAura\study\extrapolation_XTR01\ARGON\`. Create it. Every original file is read-only; SHA-256 hashes of the originals are in `hardening_SPH01\PREREG.md` and must still match when you finish.

## Read first, in this order
0. `CORPUS_INTEGRATION_REPORT_XTR01.md` — what landed from Tracks A and B, which files are canonical, which are void, and thirteen defects (D1–D13). Its §5 integration map tells you which file to take for each quantity. Do not grade from a file that map marks "do not take."
1. `MANDATE_ADDENDUM_XTR.md` — the revised rules (R17 admission, R18 bars not verdicts, R19 promotion ladder) and the re-grading map in its §3. This is the rule set you grade under.
2. `WORK_OFFLOAD_DIRECTIVE_SPH01.md` §1 (rules R1–R10) and `WORK_OFFLOAD_DIRECTIVE_XTR01.md` §2 (R11–R19). R1–R16 still bind you.
3. `FINAL_MASTER_ANALYSIS.md` — the current ground-truth ledger (§9), the theorems (§4), the gaps (§7).
4. `hardening_SPH01\claims_ledger.csv` (56 rows), `hardening_SPH01\CROSS_BAND_VERDICT_MATRIX.md`, `THEOREM_DOCKET.md` §1–§8.
5. `VERIFICATION_MATRIX_01\verification_matrix.csv` — independence scores per claim.
6. `OpenCodeBP\ONION_CREVICE_SYNTHESIS.md`, `BIO_GENE_CELLULAR_DEEP_RESEARCH\BGCDR-01.md` §5, `VEDIC_PLASMA_DEEP_RESEARCH\VPDR-01.md` §6 — their verdict matrices.
7. XTR-01 Track B: `AgentB\BRIDGE_B3.md` … `BRIDGE_B6.md`, `AgentB\STRESS_LEDGER.csv`, `AgentB\extrapolation_pass2\extrapolation_report.md` and `outputs\extrapolation_summary.json`, `AgentB\L1_*`, `L2_*`, `L3_*`. These are canonical for the ladders, the stress ledger and B3–B6 arithmetic.
8. XTR-01 Track A: `AgentA\outputs\BRIDGE_B1.md` and `bfit_comcat.json` (the ComCat b-value is canonical), `AgentA\outputs\BRIDGE_B2.md` (only its two `DATA_GAP` findings are canonical). **Void, do not grade from:** `AgentA\outputs\nme_fit.json`, `pm_fit.json` (fitted to the superseded v1 table), `AgentA\outputs\L1_STRAIN_LADDER.csv`, `L3_MEMORY_LADDER.csv` (not ladders), and the class labels in `AgentA\outputs\hard_data_extract.csv` (wrong scheme; its text rows are fine).
9. Your own `FINAL_MASTER_ANALYSIS_ARGON.md` §2 and `PUBLIC_REFLECTION_ARGON.md` §2 — grade the onion-lens framing there as you would anyone's, and flag `SELF`.

## The rule change in one paragraph
Until now an outside measurement (MICROSCOPE, PREM, IceCube, Altmann 2001, Dales 1964, the nautilus literature) acted as a verdict: a claim it disagreed with was written CONTRADICTED. From now on an outside measurement is a **bar**, recorded as `PRIOR-CONSTRAINED(value ± uncertainty, source, medium)`. A claim that hits a bar is `PROPOSED`, with the self-generated test that would clear the bar named beside it. `CONTRADICTED` may be written only when (a) the program's own pre-registered test says so, or (b) a `DERIVATION` that uses no outside data says so. The four derivations that still gate outright are the momentum no-go, the dimensional gate, the Kepler gate, and Griffith invariance. Internal arithmetic errors stay `INCONSISTENT` (that is own data). Claims with no number or no falsifier are `PROPOSED-INCOMPLETE` with the missing item named. Verification at the exit (own data, hashed, independent verifier) is unchanged.

## What to produce

**1. `claims_ledger_regraded.csv`** — one row per claim in `claims_ledger.csv` (56), plus one row per axiom A1–A4, plus one row per verdict-matrix line in BGCDR-01 §5, VPDR-01 §6 and the BP onion synthesis §9, plus one row per XTR-01 bridge (B1–B6) and per pass-2 verdict, plus the three claims from the owner's 2026-10-18 statement (Fibonacci "everywhere matter is involved"; 3-6-9 as universal resonance; Earth "stasis / siphon"). Columns:

`claim_id, source_file, old_status, ground_of_old_status (OUTSIDE-DATA | OWN-TEST | DERIVATION | INTERNAL-ARITHMETIC | NO-PREDICTION), new_status (PROPOSED | PROPOSED-INCOMPLETE | PRIOR-CONSTRAINED | PRIOR-CONSISTENT | TESTED | SUPPORTED | CONTRADICTED | INCONSISTENT | ALLEGORY), bar_value, bar_uncertainty, bar_source, bar_medium, clearing_test (an ID from the addendum §4 test queue, or a new one you define with cost and falsifier), missing_item (for PROPOSED-INCOMPLETE), independence_score (copy from verification_matrix.csv), note`

**2. `ARGON_REEVALUATION.md`** — at most four pages:
- a count of rows by old status and by new status, and the transition matrix between them;
- the list of claims that **changed** status, each with one sentence saying why under R17–R19;
- the list of claims that **did not** change, grouped by ground (own test / derivation / internal arithmetic), each with the one sentence that justifies leaving it;
- every place where you found a verdict in an existing document that rests on outside data and is written CONTRADICTED, by file and line, so the owner can issue a versioned correction (R2: never edit the original);
- the test queue, re-sorted: which clearing test unlocks the most PROPOSED claims per dollar and per day;
- anything you disagree with in the addendum itself, stated as a question to the owner, not resolved by you.

**3. `outputs\MANIFEST.sha256`** over everything you wrote, and a one-line confirmation that the original hashes in `hardening_SPH01\PREREG.md` still match.

## Rules you are under
- No citation from memory. Any outside value you enter as a bar must come from `hardening_SPH01\citations.jsonl`, `VEDIC_PLASMA_DEEP_RESEARCH\citations_compiled.jsonl`, `BIO_GENE_CELLULAR_DEEP_RESEARCH\citations_bio.jsonl`, or a page you fetch and record with its URL and excerpt. Otherwise mark it *(not re-fetched)*; a *(not re-fetched)* bar is still a bar, but say so.
- Prose must match COMMAND: if you compute anything, the number in your report must equal the number in your script's output file.
- Symmetry: a claim that moves from CONTRADICTED to PROPOSED is not thereby supported. Say "untested" where it is untested.
- Do not redefine a bar to make it disappear. If a claim's wording has been changed so that an outside measurement no longer applies (the A3 "hollow → interfacial fraction" precedent), note both wordings and grade each.
- Two AI agents agreeing is a check, not support. If your re-grading matches another agent's, record the agreement; do not cite it.
- No bench work; no human exposure; no weapon design.
- Where you are unsure, write the question. Do not resolve it.

## Four XTR-01 verdicts that need specific handling
| Verdict as written | Where | What to do |
| --- | --- | --- |
| B6: "E1 is bound-setting, not discovery" (κ_allowed = η/ε = 10⁻¹¹) | `AgentB\BRIDGE_B6.md` | κ_req = 6.8×10⁻⁴ stands as DERIVATION. κ_allowed rests on mapping MICROSCOPE's static-strain bound onto a driven 20 kHz strain; no dynamic strain–g measurement exists at any frequency. Grade κ_allowed `PRIOR-CONSTRAINED` with domain "static strain only"; E1 stays the program's primary test (T-5). Do not let this row demote E1. |
| Pass-2 B2 / L3: "shared functional form: false, INCONSISTENT" | `AgentB\extrapolation_pass2\` | The timescales (1,000 s / 86,400 s / 1 yr) are placeholders; `AgentB\DEFERRALS.md` says no curves were digitised. Grade `PROPOSED-INCOMPLETE`, missing item: digitised curves (T-9). A verdict on placeholders is the same error as a verdict on outside data. |
| B4, B5: INCONSISTENT (gaps 3.6×10⁷ and 10⁷) | `AgentB\BRIDGE_B4.md`, `B5.md` | Arithmetic stands. Both bars are outside measurements, several *(not re-fetched)*. Grade `PRIOR-CONSTRAINED` with bar values and sources; name the clearing test (there may be none cheap; say so). |
| A's B2 strain-domain fit "quadratic strongly preferred" | `AgentA\outputs\BRIDGE_B2.md` | Fitted to the v1 table the hardening already superseded. Void. The `DATA_GAP` findings (PM needs minor loops; time domain has n = 2) stand. |

## Six rows to get right first (the rest follow the same pattern)
| Claim | Expected new status | Why |
| --- | --- | --- |
| A2, mechanical drives cancel weight | CONTRADICTED | the no-go is DERIVATION on the program's own cavity |
| A2, field-coupling loophole | PROPOSED | bar: 10⁻⁹ N at 20 kHz; clearing test E1 (T-5) |
| A3-strong, central engine | PROPOSED, PRIOR-CONSTRAINED | bars: I/MR² = 0.3307, PREM, IceCube, dynamo (outside); clearing test E5 or own gravimetry |
| A4, lunar-cadence signature | CONTRADICTED | E4 was the program's own pre-registered test (UL 0.459 nm/s², δg/g < 4.7×10⁻¹¹) |
| 3-6-9 as universal resonance | CONTRADICTED | base-dependence is DERIVATION, run as COMMAND 2026-10-18 (bases 10, 12, 16) |
| Fibonacci "everywhere matter is involved" | PROPOSED, PRIOR-CONSTRAINED | bar: nautilus ratio ≈ 1.3 (literature, not re-fetched); clearing tests T-2 and T-3 |

When you finish, stop. Do not start the extrapolation work in XTR-01; that is a different directive and other agents are on it.
