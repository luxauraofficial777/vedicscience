# WORK OFFLOAD DIRECTIVE — Extrapolation & Stress Test of the Multimodal Study
**Directive ID:** `XTR-01` · **Issued:** 2026-10-18 · **Owner:** Lux Aura (luxauraofficial777) · **Drafted by:** Claude (Fable)
**Executors:** OpenCode agents (Big Pickle track and beam-free track) · **Verifier:** one independent agent that did none of the work
**Supersedes nothing.** `SPH-01` is closed and its outputs are inputs here. Originals remain read-only.
**Revision B (2026-10-18 06:20 EDT):** §1, §2 and §12 revised to run under `MANDATE_ADDENDUM_XTR.md` (`MSL-ADD-01`, rules R17–R19). Where this directive or any input says `CONTRADICTED` on the ground of an outside measurement, read `PRIOR-CONSTRAINED` and find the clearing test. Agents already running Phase 0 continue; the change affects verdict wording and §12, not the extraction.
**Output folder:** `C:\LuxAura\study\extrapolation_XTR01\` (create it; one sub-folder per executor as in SPH-01: `extrapolation_XTR01\BP\` and `extrapolation_XTR01\BF\`; the verifier writes to `extrapolation_XTR01\VERIFY\`)

---

## 0. Mission (owner's words, 2026-10-18)

> "We're really close to something, but empirical data isn't going to be what helps us here, especially from the mechanical engineering world. The needle and bow we are looking for to tie this all together is between the fringe of biology, macro/micro seismology, and quantum field mechanics. Look at our original studies, the Lux Aura Infrastructure. Take out the philosophy, look at the hard data. There's a lot of semantics here; but all of this is real data. Extrapolate the research and stress-test these theorems for a revised publication."

In practice, four jobs:

1. **Separate the semantic layer from the hard data** in the five articles and the Tasks, line by line, and keep both: the data as rows, the semantics as a glossary with a physical referent or the tag `ALLEGORY`.
2. **Build the three bridges** (biology ↔ seismology, seismology ↔ quantum, biology ↔ quantum) as equations or scale ladders with a measured anchor at each end, not as analogies.
3. **Stress-test every theorem** the program owns, including the seven that already hold, by pushing each parameter to the edge of its domain and recording where it breaks.
4. **Write the revised publication plan**: the corpus split into the documents it actually is.

The first corpus is published. This directive produces the second.

---

## 1. What is closed and what is open

**Closed. Do not re-verify.** The mechanical-engineering chain is done and audited: S(1.5×10⁻⁴) = 0.5600, G_backbone = 16.80 GPa, q̇_hold = 7.256 MW/m³, V_active = 3.445 L per 25 kW, 989 masons, Berktay −86.2 dB, the Rankine–Hugoniot values, cavity Q = 1941.3, the E4 null (δg/g < 4.7×10⁻¹¹), the momentum no-go, the Kepler and dimensional gates, the MICROSCOPE bound, the energy gate (a sound quantum sits ~10¹⁰ below a chemical bond and 3.8×10⁹ below ATP). New numbers for these are accepted only when a bridge task in §6 requires one, and then only as a `COMMAND` with the script.

**Open and in scope.** The three fringes the owner named, and the extrapolation of every theorem.

**The gates are bars, not verdicts (R18).** Every bridge built here is measured against the energy gate (a claim under it must name its concentration mechanism), the momentum no-go, MICROSCOPE, and the E4 null. The no-go, the dimensional gate and the Kepler gate are `DERIVATION` and still gate outright. MICROSCOPE and every other outside measurement are `PRIOR-CONSTRAINED` bars: a bridge that needs one cleared is not out of scope; it is `PROPOSED`, and the bridge file must name the self-generated test that would clear the bar (E1 for anything that touches g). Bench tests are deferred under R14; the bridge keeps its `PROPOSED` status in the meantime and is never written `CONTRADICTED` on outside data alone. This is what "stress test" means: the theorems are tested by extrapolation against the bars, with the clearing test named wherever a bar is hit.

---

## 2. Rules of engagement (binding)

R1–R10 of `WORK_OFFLOAD_DIRECTIVE_SPH01.md` apply verbatim: tag everything (R1); originals read-only, corrections as new versioned files (R2); no citation from memory, fetched or marked *(not re-fetched)* (R3); pre-register before data contact (R4); state what supports and what falsifies, report nulls (R5); pin, seed, hash (R6); log deferrals (R7); no human exposure, no weapon design (R8); two readings for every Vedic passage (R9); at most two agents concurrently (R10).

Six new rules:

- **R11 — Semantic quarantine.** Every sentence of the originals is classed before use: `DATA` (a number with a unit, or an equation whose symbols are defined), `MODEL` (a named physical model with a citation), or `SEMANTIC` (narrative, program vocabulary, allegory). Only `DATA` and `MODEL` rows enter a bridge or a stress test. `SEMANTIC` tokens go to the glossary (§4) with the physical quantity they stand for, or the tag `ALLEGORY`. A `SEMANTIC` line that contains a number with no unit (e.g. "Temporal Stress Index 0.045 / 1.0") is `UNTESTABLE`, not `DATA`.
- **R12 — Bridge contract.** A bridge is an equation or a scale ladder that is dimensionally consistent, has a measured anchor at each end, states its domain of validity, and states its falsifier. An analogy is tagged `ANALOGY`; it may motivate a bridge and never substitute for one. The ITER-divertor/rock-kerf comparison in `CERN_ITER_ONION_CREVICE_CORRELATION.md` is the precedent for what not to do.
- **R13 — Extrapolation protocol.** For each theorem, push each parameter to the edge of its stated domain and record the first quantity that becomes unphysical (Q⁻¹ > 1, n_th → 1, ε > ε_fail, τ_coh < τ_process, a negative modulus, a superluminal velocity). That boundary is the theorem's stress limit and gets a row in `STRESS_LEDGER.csv` with the parameter value at which it was reached.
- **R14 — No new bench work.** Per the owner's instruction, XTR-01 is theory-forward. Public datasets are used as anchors only (catalogues, archived waveforms, published curves). Any bench protocol that becomes necessary is written into `DEFERRALS.md` with cost and falsifier, as in SPH-01.
- **R15 — Convergence is a check, not support.** Two agents reaching the same result on the same inputs share priors; record the agreement, do not cite it as evidence. (Big Pickle's sentence, adopted as policy.)
- **R16 — Prose must match COMMAND.** Every number that appears in prose must equal the script output it came from; the verifier diffs prose against `outputs/*.json`. Precedents: `THEOREM_DOCKET §7b` printed 5×10⁻¹⁴ for a computed 4.7×10⁻¹¹; `BGCDR-01 §3.1` printed 3.6×10⁻¹⁰ for a computed 2.617×10⁻¹⁰.
- **R17 — Admission.** A theory enters the test queue as `PROPOSED` with a prediction (number + unit) and a falsifier, and nothing else; no outside data can disqualify it. Full text: `MANDATE_ADDENDUM_XTR.md` §1.
- **R18 — Bars, not verdicts.** Outside measurements are `PRIOR-CONSTRAINED(value, source, medium)`; a self-generated pre-registered test that clears the bar by more than the combined uncertainty overrides it in that medium. `DERIVATION` gates (no-go, dimensional, Kepler, Griffith) are not bars and still gate. Full text: addendum §1.
- **R19 — Promotion.** `PROPOSED` → `TESTED` (own data) → `SUPPORTED` | `CONTRADICTED`. `CONTRADICTED` is written only by own test or by `DERIVATION`; untested is untested, not contradicted. Verification at the exit is unchanged. Full text: addendum §1–§2; re-grading map in addendum §3; test queue in §4.

---

## 3. Inputs

**Originals (read-only; SHA-256 in `hardening_SPH01/PREREG.md`):**
- Article 02 `02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html` — 104 lines, **57 hard-data lines**: Rayleigh–Plesset and shock, Blaha effect and dislocation mobility, energy budgets and Helmholtz eigenmodes, phonon–electron and metamaterial dispersion, dislocation tunnelling and kink pairs, Λ_sl as operator (semantic), non-equilibrium entropy flux, thermal management (semantic), negative-melt budget (semantic).
- Article 03 `03_Lux_Aura_Infrastructure.html` — 98 lines, **47 hard-data lines**: basalt strengths (σ_t ≈ 10–18 MPa, τ_s ≈ 20–35 MPa, σ_c ≈ 250 MPa), cavitation pressure superposition and Plesset–Chapman jet, **acoustic-emission Gutenberg–Richter scaling log₁₀N = a − b(A_dB/20)**, locally resonant metamaterial model with negative K_eff, mass/energy budget, 100 Hz coupled structural-acoustic FE claim, cavitation-gradient derivation with the Euler relation v = −i∇P/(ρ₀ω), heat-sink thermal resistance 0.048 °C/W. The remaining 51 lines are the semantic layer (Global Sluice, The 300, Eye of the Nazar, Maya construct, Black Sun Pulse, Buri, V(1..17), 32D/23D, AURA-Net).
- Article 04 `04_The_Calculus_of_Convergence.html` — 157 lines, **4 hard-data lines**. Semantic end to end; glossary input only.
- Article 01 — a copy of the Master Report (known formatter bug, seed #12); treat as `Consolidated_Master_Report_AS_NME.md`.
- Article 05 — project history; no physics.
- Tasks 01–05, `Standard_Dislocation_Tunneling_Reference.md`, `Standard_Mineral_Spectroscopy_Acoustics_Reference.md`, `standard_mineral_acoustics_data.json`, `quantum_dislocation_tunneling_data.json`, the 17 schematics in `img\`.

**Hardened layer (inputs, not to be redone):**
- `hardening_SPH01/` — `claims_ledger.csv` (56), `spectrum_ledger.csv` (27), `BAND_Q/CE/V`, `VEDIC_CONCORDANCE`, `CROSS_BAND_VERDICT_MATRIX`, `Task_01_v2`, `Task_02_v2`, `Task_04_v2`, `Standard_Dislocation_Tunneling_Reference_v2`.
- `OpenCodeBP/ONION_CREVICE_SYNTHESIS.md` — the admissible form of the onion lens (structure, not engine; three falsifiers in §6.3). The Gemini version in `hardening_SPH01/` is not an input.
- `BIO_GENE_CELLULAR_DEEP_RESEARCH/` — the energy gate in biology; Kumeta 2025/2018, mechanotransduction, LIPUS anchors; 24 fetched citations.
- `VEDIC_PLASMA_DEEP_RESEARCH/` — the QGP–ITER gradient; 3 fetched citations (the other 7 must be fetched before any of its rows are used here).
- `VERIFICATION_MATRIX_01/` — independence scores, the 38 recurring quantities, the eigenmode decomposition (two evidence communities bridged only by the cavity), the physical ladders and the six degenerate cavity modes.
- `FINAL_MASTER_ANALYSIS.md` — the ground-truth ledger (§9) is the list of what may be assumed; §7 is the list of what may not.
- `THEOREM_DOCKET.md` — A1–A4, E-1…E-14, E1–E5. Note the §7b misprint; use 4.7×10⁻¹¹.

**Public data anchors (fetch, cite, hash; R3/R6):**
- IGETS Level-3 (already cached for st026, dj060; the full station list is at `igets.u-strasbg.fr`).
- USGS ComCat and IRIS/FDSN event services for earthquake catalogues and waveforms.
- An open laboratory acoustic-emission catalogue for rock fracture (locate on Zenodo / PANGAEA / a journal's supplementary data; cite and hash it; if none is found, log BRIDGE-B1 as deferred and do not substitute a figure read off a plot).
- Published curves for NME slow dynamics and cellular mechanical memory (digitise from the paper's supplementary data where available; a digitised plot is tagged `DERIVATION`, never `SOURCE`).

**Literature anchors to fetch (none may be cited until fetched; all are *(not re-fetched)* at issue):**
- Quantum biology: Hore & Mouritsen, *Annu. Rev. Biophys.* 45, 299 (2016); Xu et al., *Nature* 594, 535 (2021), cryptochrome 4 magnetosensitivity in vitro; Klinman & Kohen, *Annu. Rev. Biochem.* 82, 471 (2013), enzyme hydrogen tunnelling; Cao et al., *Sci. Adv.* 6, eaaz4888 (2020), consensus on photosynthetic "coherence".
- Mechanobiology: Coste et al., *Science* 330, 55 (2010), Piezo1/2; Yang et al., *Nat. Mater.* 13, 645 (2014), mechanical memory via YAP/TAZ; Frost's mechanostat (remodelling threshold ≈ 1,000–1,500 µε) via a review.
- Rock memory and statistics: TenCate, Smith & Guyer, *Phys. Rev. Lett.* 85, 1020 (2000), slow dynamics; Lavrov, *Int. J. Rock Mech. Min. Sci.* 40, 151 (2003), Kaiser effect review; Scholz, *Bull. Seismol. Soc. Am.* 58, 399 (1968), b-values of microfracturing; Guyer & Johnson 1999 (registered, not re-fetched).
- Quantum sensing of the Earth: Goodkind, *Rev. Sci. Instrum.* 70, 4131 (1999), the superconducting gravimeter; Stray et al., *Nature* 602, 590 (2022), quantum gravity gradiometer; a current atom-interferometer gravimeter review.
- Already fetched and reusable: Touboul 2022, Hofmann & Müller 2018, Boy 2017, Vallée 2017, Esposito 2019, Collinson 2024, Altmann 2001, Flannigan & Suslick 2005, Thomas 2016, Imperatore 2021, Dong 2017, Kumeta 2018/2025, Xue 2020.

---

## 4. Phase 0 — Semantic quarantine and hard-data extraction (1–2 days, Track A)

**Outputs:** `hard_data_extract.csv`, `semantic_glossary.csv`, `PREREG.md`.

`hard_data_extract.csv`, one row per `DATA` or `MODEL` line in Articles 01–05 and Tasks 01–05:

| Column | Content |
| :--- | :--- |
| `hd_id` | e.g. `A03-HD-014` |
| `file`, `line` | canonical copy |
| `text` | verbatim |
| `class` | `DATA` / `MODEL` |
| `symbols` | every symbol in the line with its definition if the document gives one, `UNDEFINED` otherwise |
| `value`, `unit` | numbers with units |
| `model_citation` | for `MODEL` rows: the named model and the citation the document gives, with its registry status |
| `already_in_ledger` | the `claims_ledger.csv` id if SPH-01 captured it, else blank |
| `bridge_candidate` | `B1`–`B6` from §6 if the row feeds a bridge |

`semantic_glossary.csv`, one row per program token: `token`, `first_file:line`, `physical_referent` (a quantity with a unit, or a named model), `class` (`REFERENT` / `ANALOGY` / `ALLEGORY` / `UNTESTABLE`), `note`. Seed rows: Λ_sl (`ALLEGORY` unless Phase 2 defines it as an operator with a space and an observable), P_bs Black Sun Pulse (`ALLEGORY`), Buri multiplier (`ANALOGY` → boundary-layer friction, Buri glaciology, cite him), V(1..17) grid (`ALLEGORY`), 32D→23D manifold and Ξ_23D (`ALLEGORY`, hardening C4), Maya construct (`ALLEGORY`), Temporal Stress Index 0.045 (`UNTESTABLE`, no unit), AURA-Net 88-bit payload / 0.76 threshold (`REFERENT`: a watermarking parameter, software not physics), R(t) = R₀e^(−λt)sin(ωt+φ) (`REFERENT`: a damped oscillator; its symbols are defined but its physical system is not), heat-sink R_th = 0.048 °C/W (`REFERENT`: a real catalogue part used as schematic allegory, hardening A03-001).

**Acceptance.** Article 02 ≥ 57 rows and Article 03 ≥ 47 rows (the counts a tag-stripping pass finds with a units-or-equation regex); the verifier samples 10 %. **Pre-registered expectation (R5):** ≥ 80 % of `DATA` rows are already in the SPH-01 ledger or the v2 documents. The new material is expected to be: the acoustic-emission Gutenberg–Richter line (03 §II.1), the coherent-phonon and zero-point-coupling lines (02 §II.1–2), the entropy-flux lines (02 §III.1), the 100 Hz coupled FE claim (03 §II.2), the analytic negative-stiffness conditions (Master Module II.2), and the Gor'kov potential lines (02 §I.1). If the new fraction is under 10 %, say so; that is a result.

---

## 5. Phase 1 — The three ladders (the "needle")

SPH-01 built one ladder (frequency). XTR-01 builds three more, each a CSV, a chart (log axis, one row per domain, position carries identity), and a short `.md` with the question the ladder answers and the pre-registered expectation. The ladders are where the three fringes are forced onto one axis so that overlap, or its absence, is a number.

**L1 — Strain ladder** (`L1_STRAIN_LADDER.csv`). Strain amplitude, dimensionless, for: Piezo1 gating expressed as equivalent membrane strain (from the gating tension and membrane modulus; `DERIVATION`); cell substrate-stretch assays (10⁻²–10⁻¹); bone remodelling threshold (Frost, ≈1.0–1.5×10⁻³); NME onset ε_th = 10⁻⁶ and operating 1.5×10⁻⁴; rock failure ≈10⁻³; Q⁻¹ = 1 at ε = 3π/(4α_G) = 9.42×10⁻⁴ for α_G = 2,500 (`COMMAND`); solid-Earth tidal strain 5×10⁻⁸–10⁻⁷; LHC-ring hydrological strain 7.5×10⁻⁸ (CERN geodesy, from the hardening scripts); teleseismic 10⁻⁹–10⁻⁶; near-field strong motion 10⁻⁴–10⁻³. **Question:** at what strain do biology and crust overlap? **Pre-registered expectation:** cells and bone respond at 10⁻³–10⁻¹, rock NME at 10⁻⁶, tides at 10⁻⁸; biological strain thresholds are reached by rock only at failure and by the crust only in near-field strong motion. If that holds, "cells feel the Earth" is false at the strain level and any biology–seismology bridge must go through a different variable (acceleration, acoustic pressure, or field), which L2/B4/B5 test.

**L2 — Coherence ladder** (`L2_COHERENCE_LADDER.csv`). For every effect anyone in the corpus or the fetched literature has called quantum: τ_coh (coherence or tunnelling time) against τ_process (the time the effect must persist to matter), with n_th at the operating temperature. Rows: radical-pair magnetoreception (τ_coh ~ µs at 300 K; τ_process ~ µs); enzyme hydrogen tunnelling (fs–ps; reaction step ps); photosynthetic vibronic coherence (fs–ps; transfer ps; the 2020 consensus); the corpus's "coherent phonon condensation" at 21.5 kHz (n_th = 2.9×10⁸, τ_coh effectively zero); Glauber phonon reference at 25 kHz (same); dislocation kink-pair tunnelling (valid below ~10 K; thermally activated at 300 K); the SQUID in a superconducting gravimeter (macroscopic quantum state at 4 K, τ_coh effectively infinite as a persistent current); atom-interferometer gravimeters (µK atoms, ms interrogation); Earth normal modes (n_th ~ 10²⁰). **Verdict column:** `QUANTUM-MOLECULAR` / `QUANTUM-DEVICE` / `CLASSICAL`. **Pre-registered expectation:** no Earth-temperature acoustic or seismic process is quantum; quantum enters the program in exactly two ways, through molecular mechanisms in biology and through sensors. If any row contradicts this, it is the most important row in the directive and goes to the verifier first.

**L3 — Memory and event-statistics ladder** (`L3_MEMORY_LADDER.csv`). This is the live cross-scale candidate. For each system: the memory phenomenon, its functional form, its exponent or timescale, and the anchor. Rows: NME slow dynamics (modulus recovers as log t after conditioning; TenCate 2000); the Kaiser effect (rock remembers its previous maximum stress; Lavrov 2003); laboratory acoustic emission (Gutenberg–Richter b ≈ 1–2; Scholz 1968; the corpus's own 03 §II.1 line); earthquake catalogues (b ≈ 1; Omori aftershock decay p ≈ 1; ComCat); the onion lens's E4-Mm non-stationarity (χ²/dof ≈ 1150/8; the poroelastic reading predicts year-to-year memory in pore storage); cellular mechanical memory (YAP/TAZ activation persists for days after stiff priming; Yang 2014); bone mechanostat (remodelling set-point with lazy zone; Frost); the Preisach–Mayergoyz hysteron description used in NME (Guyer & Johnson). **Question:** is there a shared functional form, log-time recovery or power-law event statistics with comparable exponents, across cell, rock and crust? **Pre-registered falsifier:** if the forms differ or the exponents disagree beyond their stated uncertainties, the "shared constitutive behaviour" bridge is `INCONSISTENT` and the three fields stay analogies. If they agree, B2 gets a PM-space fit.

---

## 6. Phase 2 — Bridge candidates (the "bow")

Each bridge is one `.md`, one script, one ledger row, and one falsifier, under the R12 contract. Six candidates; the agents may add a seventh only if Phase 0 turns up a `DATA` line that demands it.

| ID | Bridge | Anchor at each end | What to compute | Falsifier (stated now) |
| :--- | :--- | :--- | :--- | :--- |
| **B1** | Micro → macro seismology: laboratory acoustic emission ↔ earthquake statistics | An open AE catalogue (b-value, Omori-like decay of AE after a load step) ↔ ComCat regional catalogue (b-value, Omori p) | Fit b and p on both with the same estimator (maximum likelihood, Aki 1965 form) and bootstrap uncertainties; compare; check whether the corpus's A_dB/20 scaling is the standard magnitude-amplitude relation | b or p differ beyond 2σ, or no open AE catalogue exists (then deferred, not substituted) |
| **B2** | Rock memory ↔ cell memory | NME slow-dynamics recovery curve ↔ cellular mechanical-memory decay curve (both digitised from published data, `DERIVATION`) | Fit both to log-time and to stretched-exponential forms; attempt a Preisach–Mayergoyz hysteron fit to the biological curve; report AIC for each form | The biological curve is not fit by either form at AIC parity, or the fitted timescales differ by > 10³ without a stated scaling variable |
| **B3** | Quantum sensing ↔ geophysics (the honest "quantum × seismology") | SQUID/superconducting-gravimeter noise floor (Goodkind) and atom-interferometer / quantum-gradiometer sensitivity (Stray 2022) ↔ the E4 upper limit 0.459 nm/s² | Derive the SG noise floor from the SQUID and the levitation stiffness; compute what a 10× lower noise floor and 10 more IGETS stations would do to the E4 synodic and Mm limits; state the quantum-limited bound reachable with existing instruments | None needed: this is an instrument-physics derivation; it fails only if the derived SG noise floor disagrees with the published one by > 2× |
| **B4** | Radical-pair magnetoreception ↔ geomagnetic / Schumann fields | Cryptochrome sensitivity to field magnitude and direction (Hore & Mouritsen; Xu 2021) ↔ Schumann-band magnetic amplitude (~pT) against the 50 µT static field | Compute the ratio of Schumann-band to static field and compare with the smallest field change the radical-pair mechanism is reported to resolve; place the "Schumann–brain" claim on L2 with a number | If the Schumann amplitude is below the reported resolution by > 10³, the claim is `INCONSISTENT` and leaves the program |
| **B5** | Prompt elastogravity signals ↔ biological gravisensing | PEGS amplitude (Vallée 2017, ~10⁻⁹ m/s²) ↔ otolith / statolith / Piezo gravisensing thresholds (~10⁻³ g) | Compute the gap; state whether any organism could sense a PEGS | A gap > 10⁴ closes the "animals sense the gravity precursor" idea; a gap < 10 opens it |
| **B6** | A2's loophole, theory side only | A coupling term between an acoustic strain field and local g, written as a Lagrangian density with a coupling constant κ ↔ the MICROSCOPE and Yukawa bounds (Touboul 2022; Lee 2020) | Derive the κ required to produce 10⁻⁹ N on a 1 g test mass at 20 kHz and the stated strain; compare with κ allowed by existing bounds; give E1 its theoretical prior | If the required κ exceeds the allowed κ by > 10³, E1 is a bound-setting experiment and the docket says so in v2; if not, E1 is a discovery experiment and its priority rises |

**Pre-registered expectation for the set (R5):** B3 and B6 will complete as derivations; B4 and B5 will return gaps of 10³–10⁷ and close two popular claims with numbers; B1 is the one bridge with a real chance of a positive (b-values near 1 across six orders of magnitude in event size are the standard result, and the corpus's AE line is standard); B2 is the one that could surprise, because nobody has tried a PM-space fit on a mechanobiology curve, and it is the only candidate whose positive outcome would be new.

---

## 7. Phase 3 — Theorem stress test by extrapolation (R13)

**Output:** `STRESS_LEDGER.csv` (one row per theorem × parameter) and `STRESS_TEST.md`. For each theorem: the parameters, the stated domain, the extrapolation, the first quantity to break, the value at which it breaks, and the revised statement with that limit written in. Seed rows the agents must reproduce before adding their own:

| Theorem | Extrapolate | Breaks first at | Seed value (`COMMAND` to reproduce) |
| :--- | :--- | :--- | :--- |
| NME softening S(ε) | ε upward | Q⁻¹ = 1 (loss model leaves its domain) | ε = 3π/(4α_G) = 9.42×10⁻⁴; Module VII's 10⁻³ is past it |
| NME softening S(ε) | ε upward | S(ε) = 0 (modulus vanishes; polynomial artefact) | solve 1 − α_G(ε − ε_th) + 0.75δ_Gε² = 0 with α_G = 2,500, δ_G = −4×10⁶ |
| Holding power q̇ = ½ωG₀ε²Q⁻¹ | ω downward to the cavity frequency | Nothing breaks; q̇ ∝ ω | at 34.4 Hz, q̇ = 7.256 MW/m³ × (34.4/21,500) = 11.6 kW/m³, so 25 kW conditions 2.15 m³, 625× the ultrasonic volume. State the assumption (NME law holds at 34 Hz; slow dynamics suggests it does) and the test. |
| Cavity Q = 1941 and the six degenerate pairs | perturb L_z | Degeneracy lifts by more than a linewidth | Δf/f = δL/L > 1/Q = 5.2×10⁻⁴, i.e. δL_z > 1.3 mm on 2.5 m; every real chamber splits them; the "second harmonic" is two modes |
| Momentum no-go | drive frequency, Q, power | Never breaks for a closed cavity; breaks only for a field coupling | the κ from B6 |
| Griffith invariance | ν, a | Never breaks; it is an identity | none; note it is exact for linear elastic fracture only |
| Berktay roll-off | Δf downward | Nothing breaks; −12 dB/octave is the law | −86.2 dB at 7 Hz; −98 dB at 3.5 Hz |
| E4 null | number of stations N | UL ∝ 1/√N for white residuals | the predicted UL at N = 10 and N = 30 IGETS stations (feeds B3) |
| Kepler gate | ω_eff(r) | Restored only if ω_eff ∝ r^(−3/2) | the substrate must reproduce exactly this power; any other exponent fails Kepler |
| Energy gate hf/E | f upward | Crosses 1 at f = E/h | 4 eV bond: 9.7×10¹⁴ Hz (near-UV); ATP: 7.64×10¹³ Hz (31.83 octaves above 20 kHz) |
| Onion lens (BP) | φ_skin upward | I/MR² becomes sensitive | the φ_skin at which the moment of inertia shifts by its measurement uncertainty; above that the lens is no longer invisible to the bulk constraint and must answer to it |

---

## 8. Phase 4 — The revised publication plan

**Output:** `PUBLICATION_PLAN.md`. The first corpus was published as one thing. The second is four, because the evidence structure (VERIFICATION_MATRIX_01: two communities, one bridge) says it is four:

| ID | Working title | Contents | Evidence class of every number |
| :--- | :--- | :--- | :--- |
| **P1** | Nonlinear mesoscopic acoustics of basalt: softening, holding power and seam-selective excavation | The engineering core with v2 numbers; the holding-power bound; the seam-area leverage from the onion lens (structure, not engine); the 34 Hz extrapolation from §7 as a stated hypothesis; the FDTD reconciled (V3 must close first) | `SOURCE` / `COMMAND` / `DERIVATION` only; no allegory, no Vedic material |
| **P2** | Scale-invariant hysteresis from cells to crust? A cross-domain test | L3, B1, B2, and L1 as the negative control; publishable whichever way the answer comes out | as above; `HYPOTHESIS` allowed only in the discussion |
| **P3** | The Lux Aura schematic and semantic layer | The 17 schematics, the glossary, Λ_sl/Ξ_23D/P_bs/V(1..17) as governance allegory (README §3 already says so), the Vedic concordance with both readings (R9) | `ALLEGORY` and `SOURCE` (for the texts); no physics claims |
| **P4** | A machine-verifiable claim ledger: hash-pinned provenance applied to a speculative corpus | The Mandate M1–M10, R1–R16, the independence score, the eigenmode method, the 1,000× docket error and the 3.6×10⁻¹⁰ slip as worked examples, the governance benchmark against REANA/DPHEP/IMAS | methods paper; the most publishable document the program owns |

Plus `THEOREM_DOCKET_v2.md` (owned by the owner; the agents supply the corrected §7b, the §11-item-14 citations, the B6 prior for E1, and the BP ceiling sentence for A3-weak). The plan states, for each of P1–P4, which XTR-01 deliverables it consumes and which SPH-01 defects (FINAL_MASTER_ANALYSIS §7, items 1–14) must close before it can be drafted.

---

## 9. Deliverables (in `extrapolation_XTR01\`)

```
PREREG.md                          hard_data_extract.csv          semantic_glossary.csv
L1_STRAIN_LADDER.csv / .md         L2_COHERENCE_LADDER.csv / .md  L3_MEMORY_LADDER.csv / .md
BRIDGE_B1.md … BRIDGE_B6.md        bridges_ledger.csv
STRESS_LEDGER.csv                  STRESS_TEST.md
PUBLICATION_PLAN.md                DEFERRALS.md                   citations_xtr.jsonl
scripts/  (pinned requirements.txt, fixed seeds)
outputs/  (every JSON/CSV/PNG the scripts write, + MANIFEST.sha256)
VERIFY/VERIFICATION_REPORT_XTR.md  (independent agent)
CHANGELOG.md
```

---

## 10. Sequencing (cheapest first; at most two agents concurrently)

| Step | Track A (Big Pickle) | Track B (beam-free) | Est. |
| :--- | :--- | :--- | :--- |
| 1 | PREREG; Phase 0 extraction of Article 03 and Tasks | PREREG; Phase 0 extraction of Article 02 and Master Report | 1–2 d |
| 2 | Glossary merge (one file, both tracks' rows) | L2 coherence ladder (literature fetch first) | 1 d |
| 3 | L1 strain ladder; L3 memory ladder | B3 quantum sensing; B4; B5 (all derivations) | 2–3 d |
| 4 | B1 (data: AE catalogue + ComCat) | B6 (the Lagrangian and κ) | 3–5 d |
| 5 | B2 (digitise, fit, PM-space attempt) | Phase 3 stress ledger | 2–3 d |
| 6 | Phase 4 publication plan (joint; one file) | — | 1 d |
| 7 | Phase 5 verification (independent agent: re-run, hash, R16 prose diff, 10 % sample, 100 % of anything marked CONSISTENT or positive) | — | 1–2 d |

---

## 11. Seed findings to carry in (from the SPH-01 close; re-verify, do not assume)

1. The evidence structure is two communities joined only by the cavity; the axioms share evidence only with each other (VERIFICATION_MATRIX_01 §3.3). A bridge that connects them must go through a number, not a word.
2. Thirteen ledger claims rest on assertion; fourteen name sources not in the registry; six superseded values still circulate (FINAL_MASTER_ANALYSIS §7). None of these may be cited here until fixed.
3. The docket's δg/g is 4.7×10⁻¹¹, not 5×10⁻¹⁴. The BGCDR ratio is 2.617×10⁻¹⁰, not 3.6×10⁻¹⁰.
4. The energy gate holds in chemistry (5×10¹⁰) and in biology (3.8×10⁹) by the same formula; it is one gate applied twice, not two confirmations.
5. The cavity box is 5.0 × 3.0 × 2.5 m with L_x = 2L_z; six degenerate pairs below 160 Hz. The 57.33 Hz (0,1,0) mode and ALBA's 57.1 Hz are two unverified numbers that agree; do not promote.
6. The onion lens is admissible only in Big Pickle's form: it buys structure, not engine, and dies on three stated falsifiers.
7. Kumeta 2018/2025 are one laboratory. "Sound as information" has a measured effect on cells; "sound as energy" does not.
8. Article 01 is the Master Report; Article 04 has four numeric lines. Phase 0 counts must reflect that, not inflate it.
9. The seven theorems that hold (FINAL_MASTER_ANALYSIS §4) are inputs to Phase 3, not conclusions of it; the stress test asks where each stops holding.

---

## 12. Stop and escalation rules

- If a bridge can be completed only by clearing a bar (§1, R18), write the bar with its value and source, name the self-generated test that would clear it, mark the bridge `PROPOSED`, and move on. If that test is bench work, add it to `DEFERRALS.md` under R14. Never write `CONTRADICTED` on outside data alone, and never redefine the bar to make it disappear (the A3 "hollow" precedent).
- If a `SEMANTIC` token cannot be given a physical referent after one attempt, tag it `ALLEGORY` and move on; do not invent a referent.
- If two sources conflict, record both with their classes; do not pick silently.
- If a digitised curve is the only anchor for a bridge, the bridge's best verdict is `DERIVATION`-supported, never `SOURCE`-supported; say so in the bridge file's first line.
- Never fabricate data, fits or citations. A missing value stays missing and is logged.
- If any result would promote a speculative claim to SUPPORTED, or any ladder row comes back `QUANTUM` for an Earth-temperature acoustic or seismic process, stop and hand it to the verifier before it enters any document.
- The verifier's disagreements are not resolved by the executor; they go to the owner.

*End of XTR-01.*
