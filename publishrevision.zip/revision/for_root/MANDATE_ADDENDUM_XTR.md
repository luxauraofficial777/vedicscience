# MANDATE OF SOUND LOGIC — ADDENDUM FOR THE PHYSICAL MEDIUM
**Addendum ID:** `MSL-ADD-01` · **Date:** 2026-10-18 · **Owner:** Lux Aura (luxauraofficial777) · **Drafted by:** Claude (Fable) at the owner's instruction
**Applies to:** `WORK_OFFLOAD_DIRECTIVE_XTR01.md` (Rev B) and every later directive in `C:\LuxAura\study`. Does not alter `M1–M10` for software, where the Mandate is already proven. Extends the Mandate to the physical medium, where the constant is not the same.

---

## 0. Why (owner's words, 2026-10-18)

> "The corpus rules for the mandate have to be loosened, or we will never get anywhere relying on 300 years of other people's data. We need to test our theories without disqualifying them before testing."

The Mandate as applied in `SPH-01` graded a claim at the moment it was stated, so an outside measurement acted as a **verdict**. Under this addendum an outside measurement acts as a **bar**: the thing a self-generated test must clear, recorded with its number, never the thing that ends a claim. Admission to testing is loosened. Verification is not.

---

## 1. New rules

### R17 — Admission
A theory enters the test queue with status **`PROPOSED`** and no evidence requirement. It needs exactly two things:

1. a prediction with a number and a unit, and
2. a falsifier stated before data contact (R4).

Nothing else can keep it out, and nothing outside the corpus can disqualify it. A theory that has neither is **`PROPOSED-INCOMPLETE`**: it stays in the queue with the missing item named, and it cannot be tested until the item is supplied.

### R18 — Bars, not verdicts
An outside measurement is recorded as **`PRIOR-CONSTRAINED(value ± uncertainty, source, medium)`**. It sets the bar a self-generated test must clear in that quantity. A self-generated, pre-registered test whose result differs from the bar by more than the combined uncertainty **overrides the bar in that medium, for that quantity**. A self-generated test that agrees with the bar promotes the outside value to `SOURCE` in the program's own hands. Until the program's own test has run, the claim's status is `PROPOSED`, the bar is noted, and no verdict is written.

Three things are **not** bars, because they use no outside data, and they continue to gate as `DERIVATION`:
- the momentum-conservation no-go (computed on the corpus's own cavity),
- the dimensional gate and the Kepler gate (algebra),
- Griffith invariance (an identity).

The energy gate (hf against a bond or ATP energy) is a bar with a requirement attached: a claim under it must **name its energy-concentration mechanism** (cavitation, focusing, coherent many-quantum coupling) to be admitted as `PROPOSED`; without one it is `PROPOSED-INCOMPLETE`, exactly as SPH-01 §4 already wrote it.

### R19 — Promotion ladder
`PROPOSED` → `TESTED` (own data, pre-registered, hashed) → `SUPPORTED` or `CONTRADICTED`.

- `SUPPORTED` requires the own test to clear its bar by more than the combined uncertainty **and** to survive the independent verifier (SPH-01 Phase 5).
- `CONTRADICTED` is written **only** by a self-generated, pre-registered test, or by a `DERIVATION` that uses no outside data.
- A theory that stays `PROPOSED` with no test run is **untested, not contradicted**, and the ledger says so in those words.

---

## 2. What this addendum does not loosen

R1 (tags), R2 (originals read-only), R3 (fetched or marked *not re-fetched*), R4 (pre-registration), R5 (symmetry; nulls reported), R6 (pinned, seeded, hashed), R8 (no human exposure, no weapon design), R15 (convergence is a check), R16 (prose equals `COMMAND`). The loosening is at the **door** of the test queue. The **exit** is as strict as before, and stricter in one respect: a `SUPPORTED` now needs the program's own data, not a citation.

---

## 3. Re-grading map (apply to every existing verdict)

| Old status (SPH-01 / docket) | Ground of the old status | New status under MSL-ADD-01 |
| :--- | :--- | :--- |
| `CONTRADICTED` | an outside measurement | `PRIOR-CONSTRAINED(value, source)`; claim is `PROPOSED`; the clearing test is named |
| `CONTRADICTED` | a `DERIVATION` with no outside data, or the program's own test | `CONTRADICTED` (unchanged) |
| `INCONSISTENT` | internal arithmetic or self-contradiction | `INCONSISTENT` (unchanged; this is own-data) |
| `CONSISTENT` | agrees with an outside value | `PRIOR-CONSISTENT`; promotes to `SOURCE`-own when the program measures it |
| `CONSISTENT` | agrees with the program's own script or test | `SUPPORTED` (unchanged) |
| `UNTESTABLE-AS-WRITTEN` | no number, no falsifier | `PROPOSED-INCOMPLETE` with the missing item named |
| `ALLEGORY` | no prediction by the project's own definition | `ALLEGORY` (unchanged); re-admissible as `PROPOSED` the day a prediction with a unit is written for it |

### Worked re-gradings

| Claim | Old | New | Bar (if any) | Test that clears it |
| :--- | :--- | :--- | :--- | :--- |
| A1 mass from substrate modes | OPEN, constrained | `PROPOSED` | η = (−1.5 ± 2.3 ± 1.5)×10⁻¹⁵ (MICROSCOPE); Kepler exponent −3/2 (`DERIVATION`, still gates) | a substrate model producing ω_eff ∝ r^(−3/2) and η < 10⁻¹⁵, then an EP test of its predicted residual |
| A2 resonance cancels weight (mechanical) | CONTRADICTED | `CONTRADICTED` | none: the no-go is `DERIVATION` on the program's own cavity | none; the claim is closed by the program's own arithmetic |
| A2 field-coupling loophole | OPEN | `PROPOSED` | 10⁻⁹ N at 20 kHz on 1 g (own E1 protocol); κ bound from B6 | **E1** |
| A3-strong central engine | CONTRADICTED | `PROPOSED`, `PRIOR-CONSTRAINED` | I/MR² = 0.3307; PREM normal modes; neutrino opacity; dynamo (all outside) | a self-generated seismic or gravimetric measurement whose residual the bar does not predict (E5 on IRIS normal modes is the cheapest) |
| A3-weak interfacial structure (BP lens) | HYPOTHESIS | `PROPOSED` | none beyond the three BP falsifiers | E4-Mm poroelastic refit, own pipeline |
| A4 lunar-cadence signature | CONSTRAINED; null | `CONTRADICTED` | none: E4 was the program's own pre-registered test | closed by own data; a new prediction re-enters as `PROPOSED` |
| Fibonacci "everywhere matter is involved" | CONTRADICTED (nautilus, galaxies, literature) | `PROPOSED`, `PRIOR-CONSTRAINED` | nautilus ratio ≈ 1.3 (literature); phyllotaxis = Douady–Couder mechanism | **T-2** nautilus measurement; **T-3** Douady–Couder reproduction |
| 3-6-9 as universal resonance | CONTRADICTED | `CONTRADICTED` | none: base-dependence is `DERIVATION` and was run as `COMMAND` in-session (base 10 / 12 / 16) | closed by own computation; re-admissible only with a base-independent prediction |
| Earth "stasis / siphon" | — | `PROPOSED-INCOMPLETE` | E4 null for its one prior form | needs a number and a falsifier before it can be queued |
| Ψ_g gravity as exploitable layer | ALLEGORY | `ALLEGORY` → `PROPOSED` the day a coupling constant is written | MICROSCOPE; B6 κ | E1 |
| Mohenjo-daro vitrification | INCONSISTENT (C3) | `PRIOR-CONSTRAINED` (Dales 1964: no vitrified zone in the excavation record) | the excavation reports | a self-generated site measurement or a primary-record re-read; absent that, `PROPOSED` with the bar noted |
| Infrasound syncope (Sammohana) | INCONSISTENT | `PRIOR-CONSTRAINED` (Altmann 2001) + `DERIVATION` (Berktay −86.2 dB stands) | the Berktay roll-off is arithmetic and still gates the 7 Hz beat | A3 anechoic roll-off measurement (deferred, R8 governs exposure) |

---

## 4. Test queue (own-data tests, cheapest first)

| ID | Test | Cost | Status |
| :--- | :--- | :--- | :--- |
| T-1 | Doubling-sequence digit roots in bases 10, 12, 16 | 10 s | **run 2026-10-18**; 3-6-9 is base-10 arithmetic (`COMMAND`) |
| T-2 | Nautilus chamber-radius ratio from one shell, photo and ruler | 1 h | queued |
| T-3 | Douady–Couder phyllotaxis: ferrofluid drops, oil dish, ring magnet; vary drop rate, count spiral arms | < $100, a weekend | queued; first self-generated measured resonance in the corpus |
| T-4 | E4 at 10+ IGETS stations (own pipeline; Mm/tropical ratio, synodic UL ∝ 1/√N) | free, compute | queued (feeds XTR-01 B3) |
| T-5 | E1 kHz g-modulation search | $2–5k, weeks | protocol written; the program's primary physics test |
| T-6 | Kumeta 2025 replication: cell line, speaker, RNA-seq | a cell lab | queued; the one biological test |
| T-7 | Q⁻¹ on a basalt core at 21.5 kHz and at 34.4 Hz (makes q̇_hold convergent and tests the 625× extrapolation) | a materials lab | queued |

---

## 5. Instruction to agents

Where any existing document in `C:\LuxAura\study` writes `CONTRADICTED` on the ground of an outside measurement, read `PRIOR-CONSTRAINED` and look for the clearing test in §3 or §4. Do not rewrite the originals (R2). Write the re-graded ledger as a new file, `claims_ledger_regraded.csv`, with columns `claim_id, old_status, ground, new_status, bar_value, bar_source, clearing_test`. Argon's re-evaluation (`ARGON_REEVALUATION_PROMPT.md`) produces that file.

*End of MSL-ADD-01.*
