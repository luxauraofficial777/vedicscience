# -*- coding: utf-8 -*-
"""
Generates README_REVISION.md and TOC_REVISION.md in C:/LuxAura/study/
for the Revised Edition (REVISION-01 / MSL-ADD-01 / XTR-01).
"""
from pathlib import Path

ROOT = Path(r"C:\LuxAura\study")

README_REV = r"""# VEDIC SCIENCE — Transmodal Study Against Conventional Physics, Sound Logic Theorems, Quantum, and Bio-Mechanics (Revised Edition)

**Repository:** [`github.com/luxauraofficial777/vedicscience`](https://github.com/luxauraofficial777/vedicscience)  
**Corpus Package ID:** `LUXAURA-REVISION-XTR01-FINAL` (`First Edition SPH-01` + `Revised Edition XTR-01 / MSL-ADD-01`)  
**Governing Specifications:** [`Revision.md`](Revision.md) (`REVISION-01`) · [`MANDATE_ADDENDUM_XTR.md`](MANDATE_ADDENDUM_XTR.md) (`MSL-ADD-01`, Rules `R17`–`R19`) · [`CORPUS_INTEGRATION_REPORT_XTR01.md`](CORPUS_INTEGRATION_REPORT_XTR01.md)  
**Release Packages:** First Edition [`publish/`](publish/) (`142` files) · Revised Edition [`revision/`](revision/) (Hash-Verified in [`revision/MANIFEST.sha256`](revision/MANIFEST.sha256))  
**License:** Creative Commons Attribution-NonCommercial 4.0 International ([`CC BY-NC 4.0`](LICENSE))

---

## 1. Two Editions, One Method: Why This Repository Publishes Both

This repository houses the complete theoretical, mathematical, numerical, and philological corpus of **Project Lux Aura (`vedicscience`)**: a rigorous **transmodal investigation** evaluating ancient Vedic cosmological, acoustic, plasma, and biological frameworks against hardened **Conventional Physics**, **Sound Logic Theorems (`M1`–`M10`)**, **Quantum Mechanics**, **Continuum Geophysics**, and **Cellular Bio-Mechanics**.

As explained in [`Revision.md`](Revision.md) (`REVISION-01`), the corpus is published in **two complete, cryptographically pinned editions side by side**:

1. **First Edition (`SPH-01` — *"House Cards, Dealer Rules"*, archived in [`publish/`](publish/) and root v1 files):**
   - Extended the **Mandate of Sound Logic (`M1`–`M10`)** across both our own drafts and external published literature, allowing external measurements (`MICROSCOPE`, `PREM`, `IceCube`, `Altmann 2001`, `Dales 1964`, `RRUFF`) to write `CONSISTENT`, `INCONSISTENT`, or `CONTRADICTED` verdicts on corpus claims.
   - **What It Accomplished:** Caught **14 internal mathematical, unit, and historical defects** in our own v1 files in a single day (including a $1,000\times$ docket division slip and a $25\times$ mason double-count) while exposing a **$550\text{ ppm}$ inter-method spread** across 13 published measurements of Newton's constant $G$ (Xue et al., *Natl. Sci. Rev.* 2020).
2. **Revised Edition (`XTR-01` / `MSL-ADD-01` — *"Our Cards, Our Rules; Not Applied to Others, in Respect"*, staged in [`revision/`](revision/) and root `*_REVISION.md` files):**
   - Narrows Mandate verdicts strictly to **our own pre-registered empirical runs (`OWN-TEST`) and self-contained mathematical derivations (`DERIVATION` / `INTERNAL-ARITHMETIC`)** under Rules `R17`–`R19`:
     - **Rule `R17`:** External published literature is recorded respectfully in full (`value ± uncertainty, source, medium`) as a **boundary bar** (`PRIOR-CONSTRAINED` or `PRIOR-CONSISTENT`), never as an un-re-run verdict.
     - **Rule `R18`:** Only our own executed data (`OWN-TEST`) or zero-outside-data derivations (`DERIVATION`) write `SUPPORTED`, `CONTRADICTED`, or `INCONSISTENT`.
     - **Rule `R19`:** Every `PRIOR-CONSTRAINED` or `PROPOSED` claim names the specific pre-registered internal test (`T-1`–`T-9`) that will resolve it.

---

## 2. Quick-Start Index: Revised Edition Root Documents (`*_REVISION.md`)

All original First Edition root documents remain untouched under **Rule `R2`**. The Revised Edition public-facing documents sit alongside them in the repository root with the `_REVISION.md` suffix:

| Revised Edition Root File | First Edition Counterpart | Role & Scope |
| :--- | :--- | :--- |
| **[`PUBLIC_REFLECTION_ARGON_REVISION.md`](PUBLIC_REFLECTION_ARGON_REVISION.md)** | [`PUBLIC_REFLECTION_ARGON.md`](PUBLIC_REFLECTION_ARGON.md) | **Public Reflection & Whitepaper Summary (Revised Edition):** Frames *"House Cards, Dealer Rules"* vs. *"Our Cards, Our Rules"*, declares the explicit `PROPOSED` status of the Onion-Layer / Breathing-Crevice lens (`A3-weak`, `D10`), summarizes the 19 `SUPPORTED` truths and 6 `XTR-01` bridges (`B1`–`B6`), and outlines the 9 discovery tests (`T-1`–`T-9`). |
| **[`FINAL_MASTER_ANALYSIS_ARGON_REVISION.md`](FINAL_MASTER_ANALYSIS_ARGON_REVISION.md)** | [`FINAL_MASTER_ANALYSIS_ARGON.md`](FINAL_MASTER_ANALYSIS_ARGON.md) | **Master Technical Consolidation (Revised Edition):** Complete 9-layer technical synthesis across Bands `Q`, `CE`, `V`, Ladders `L1`–`L3`, Bridges `B1`–`B6`, the full **95-row re-graded claims ledger**, the **Superseded Values Registry**, and all 13 remediated `XTR-01` defects (`D1`–`D13`). |
| **[`FINAL_MASTER_ANALYSIS_REVISION.md`](FINAL_MASTER_ANALYSIS_REVISION.md)** | [`FINAL_MASTER_ANALYSIS.md`](FINAL_MASTER_ANALYSIS.md) | **Ground-Truth Master Analysis (Revised Edition):** Updated axiom grades (`A1`–`A4`), SVD cavity bridge analysis, `XTR-01` ground-truth ledger, and institutional comparison under `MSL-ADD-01`. |
| **[`README_REVISION.md`](README_REVISION.md)** | [`README.md`](README.md) | **Revised Edition Repository Guide** (this file). |
| **[`TOC_REVISION.md`](TOC_REVISION.md)** | [`TOC.md`](TOC.md) | **Revised Edition Master Table of Contents** indexing both `revision/` and `publish/`. |
| **[`Revision.md`](Revision.md)** | — | **Editorial Charter (`REVISION-01`):** Defines the philosophical and methodological transition from the First Edition to the Revised Edition. |
| **[`MANDATE_ADDENDUM_XTR.md`](MANDATE_ADDENDUM_XTR.md)** | [`WORK_OFFLOAD_DIRECTIVE_SPH01.md`](WORK_OFFLOAD_DIRECTIVE_SPH01.md) | **Mandate Addendum (`MSL-ADD-01`):** Formal specification of Rules `R17`–`R19` and the 8 Revised Edition status tags. |
| **[`CORPUS_INTEGRATION_REPORT_XTR01.md`](CORPUS_INTEGRATION_REPORT_XTR01.md)** | [`HARDENING_REPORT.md`](HARDENING_REPORT.md) | **Cross-Check & Integration Audit (`XTR01-INTEGRATION-01`):** Audits Track A (`AgentA/`), Track B (`AgentB/`), and Argon (`extrapolation_XTR01/ARGON/`), documenting defects `D1`–`D13` and the canonical integration map. |

---

## 3. Summary of the 95-Row Re-Evaluated Corpus Ledger (`MSL-ADD-01`)

Across the **95 total claims** in [`extrapolation_XTR01/ARGON/claims_ledger_regraded.csv`](extrapolation_XTR01/ARGON/claims_ledger_regraded.csv) (`56` `SPH-01` core claims + `39` `XTR-01` extrapolation claims):

| Revised Edition Status (`MSL-ADD-01`) | `SPH-01` (`56`) | `XTR-01` (`39`) | Total (`95`) | Share (`%`) | Meaning Under Rules `R17`–`R19` |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **`SUPPORTED`** | 16 | 3 | **19** | `20.0%` | Verified by our own pre-registered empirical run (`OWN-TEST`) or zero-outside-data derivation (`DERIVATION` / `COMMAND`) |
| **`CONTRADICTED`** | 1 | 3 | **4** | `4.2%` | Refuted by our own empirical run (`E4` synodic null) or internal conservation-law no-go (`DERIVATION`) |
| **`INCONSISTENT`** | 15 | 2 | **17** | `17.9%` | Internal arithmetic, dimensional, or parameter self-contradiction (`INTERNAL-ARITHMETIC`), including own data against own data (`T03-003`, pending `V3`) |
| **`PRIOR-CONSISTENT`** | 10 | 7 | **17** | `17.9%` | Consistent with external published literature (`EXTERNAL-LITERATURE`); no own test run yet |
| **`PRIOR-CONSTRAINED`** | 10 | 16 | **26** | `27.4%` | Constrained by an external published bar (`value ± uncertainty, source, medium`); paired with an internal test |
| **`PROPOSED`** | 0 | 4 | **4** | `4.2%` | Admitted with a prediction and a falsifier, untested by own data (`A3-weak` `T-4` + `E4-Mm` refit, dynamic `E1` `T-5`, `BGCDR-04/05` `NEW-T18/19`) |
| **`PROPOSED-INCOMPLETE`** | 1 | 3 | **4** | `4.2%` | Hypothesis missing a named input (`NEW-T10`, `T-8`, `T-9`; `OWN-STASIS` needs a prediction with a unit and a falsifier before any test is queued) |
| **`ALLEGORY`** | 3 | 1 | **4** | `4.2%` | Symbolic operator ($\Psi_g, \Xi_{23D}, P_{\text{bs}}$) or structural metaphor (`A04-002`) |

---

## 4. Key Ground-Truth Highlights of the Revised Edition

1. **The Engineering Core & Planar Seam Leverage (`SUPPORTED`):**
   - At $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$ ($21.5\text{ kHz}$), the Guyer–Johnson–McCall softening factor is $\mathcal{S} = \mathbf{0.5600}$ ($G_{\text{backbone}} = \mathbf{16.80\text{ GPa}}$, $\sigma_t^{\text{eff}} = \mathbf{11.225\text{ MPa}}$, $Q^{-1} = 0.1592$), with zero-modulus polynomial root $\mathcal{S}(\varepsilon)=0$ at $\varepsilon = \mathbf{2.96 \times 10^{-4}}$ and unit loss limit $Q^{-1}=1$ at $\varepsilon = \mathbf{9.42 \times 10^{-4}}$ (`D6`).
   - Continuous internal friction dissipates $\dot{q}_{\text{hold}} = \mathbf{7.256\text{ MW/m}^3}$, capping a $25\text{ kW}$ array to **$3.445\text{ L}$**—which conditions a **$34.45\text{ m}^2$ ($5.87\text{ m} \times 5.87\text{ m}$) detachment plane** when channeled into a $100\ \mu\text{m}$ foliated parting seam! Paired with the `M7` workforce fix ($24,725 \to \mathbf{989\text{ active masons}}$, $130$ hybrid), monolithic excavation works by cleaving the seam rather than crushing bulk volume.
2. **The Onion-Layer & Breathing-Crevice Lens (`A3-weak` = `PROPOSED`, `D10`):**
   - Explicitly graded **`PROPOSED`** with three pre-registered falsifiers (`OpenCodeBP` §6.3, paired with test `T-4` and the `E4-Mm` poroelastic refit), anchored by two executed `OWN-TEST` results:
     - **Executed Null (`E4` Synodic Gravimetry — `CONTRADICTED`):** $\delta g/g < \mathbf{4.68 \times 10^{-11}}$ ($\text{UL} = 0.459\text{ nm/s}^2$) at $29.53\text{ d}$, with a non-stationary $2.16\text{–}3.13\times$ excess in the $27.55\text{ d}$ anomalistic perigee band (`E4-Mm`, `PROPOSED`).
     - **Executed Positive (`XTR-01` Deccan USGS ComCat Fit — `SUPPORTED`):** Gutenberg–Richter exponent **$b = 1.2532$** ($\text{CI}_{95}\ [1.1292, 1.3900]$, $M_c = 4.4$, $N = 492$, `Ellora ±10°`, 2000–2026, `AgentA/outputs/bfit_comcat.json`).
3. **Dynamic kHz Gravity Search (`E1` / `T-5` = `PROPOSED`, `D5`):**
   - Detecting $\delta g/g = 1.02 \times 10^{-7}$ at $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$ ($21.5\text{ kHz}$) requires $\kappa_{\text{req}} = \mathbf{6.80 \times 10^{-4}}$ (`SUPPORTED` `DERIVATION`), while $\kappa_{\text{allowed}} \le 10^{-11}$ is `PRIOR-CONSTRAINED` on **static** strain only (`D5`), keeping tabletop experiment **`E1` (`T-5`)** open as our #1 laboratory discovery test.

---

## 5. Verifying the Revised Edition Package (`revision/MANIFEST.sha256`)

```powershell
# Verify all SHA-256 hashes in C:\LuxAura\study\revision\MANIFEST.sha256:
python revision/argon_reevaluation/scripts/build_revision_package.py --verify
```
"""

TOC_REV = r"""# MASTER TABLE OF CONTENTS — REVISED EDITION (`TOC_REVISION.md`)
## Vedic Science — Transmodal Study Against Conventional Physics, Sound Logic Theorems, Quantum, and Bio-Mechanics (`SPH-01` $\to$ `XTR-01` / `MSL-ADD-01`)

**Repository:** [`https://github.com/luxauraofficial777/vedicscience`](https://github.com/luxauraofficial777/vedicscience)  
**Package ID:** `LUXAURA-REVISION-XTR01-FINAL`  
**Governing Charter:** [`Revision.md`](Revision.md) (`REVISION-01`) · [`MANDATE_ADDENDUM_XTR.md`](MANDATE_ADDENDUM_XTR.md) (`MSL-ADD-01`) · [`CORPUS_INTEGRATION_REPORT_XTR01.md`](CORPUS_INTEGRATION_REPORT_XTR01.md)  
**License:** [`CC BY-NC 4.0`](LICENSE)

---

## Quick Navigation
* **[Part I — Revised Edition Root Syntheses & Governance Charter (`*_REVISION.md`)](#part-i--revised-edition-root-syntheses--governance-charter-_revisionmd)**
* **[Part II — Revised Edition Publication Package (`revision/`)](#part-ii--revised-edition-publication-package-revision)**
* **[Part III — Canonical `XTR-01` Scale Ladders (`L1`–`L3`) & Cross-Domain Bridges (`B1`–`B6`) (`revision/xtr01_canonical/`)](#part-iii--canonical-xtr-01-scale-ladders-l1l3--cross-domain-bridges-b1b6-revisionxtr01_canonical)**
* **[Part IV — Argon 95-Row `MSL-ADD-01` Re-Evaluation Suite (`extrapolation_XTR01/ARGON/`)](#part-iv--argon-95-row-msl-add-01-re-evaluation-suite-extrapolation_xtr01argon)**
* **[Part V — Preserved First Edition (`SPH-01`) Syntheses, Reports & `publish/` Archive](#part-v--preserved-first-edition-sph-01-syntheses-reports--publish-archive)**
* **[Part VI — Preserved Read-Only v1 Baseline Corpus (`Rule R2`)](#part-vi--preserved-read-only-v1-baseline-corpus-rule-r2)**

---

## Part I — Revised Edition Root Syntheses & Governance Charter (`*_REVISION.md`)

Located directly in `C:\LuxAura\study\` (and staged inside `C:\LuxAura\study\revision\root_revision_docs\`):

1. **[`Revision.md`](Revision.md) (`REVISION-01`)** — *Editorial & Epistemic Charter:* Contrasts the First Edition (*"House Cards, Dealer Rules"*) with the Revised Edition (*"Our Cards, Our Rules — Not Applied to Others, in Respect"*), explaining why external measurements are recorded as bars (`PRIOR-CONSTRAINED` / `PRIOR-CONSISTENT`) while verdicts (`SUPPORTED`, `CONTRADICTED`, `INCONSISTENT`) are written strictly by in-house data (`OWN-TEST`) and derivations (`DERIVATION`).
2. **[`PUBLIC_REFLECTION_ARGON_REVISION.md`](PUBLIC_REFLECTION_ARGON_REVISION.md) (`ARGON-PUBLIC-REFLECTION-02-REVISION`)** — *Revised Public Whitepaper Summary:*
   - **§1:** Two Editions, One Method + Explicit `D10` status box declaring the Onion-Layer / Breathing-Crevice lens (`A3-weak`) as **`PROPOSED`** with 3 pre-registered falsifiers, alongside the executed `E4` synodic null (`CONTRADICTED`) and Deccan ComCat $b = 1.2532$ (`SUPPORTED`).
   - **§2:** The 19 `SUPPORTED` self-contained engineering & mathematical truths ($G_{\text{backbone}} = 16.80\text{ GPa}$, $\mathcal{S}=0$ at $\varepsilon = 2.96\times 10^{-4}$ vs. $Q^{-1}=1$ at $9.42\times 10^{-4}$, $34.45\text{ m}^2$ planar seam leverage, $989\text{ masons}$, Stokes $\delta_\nu$ scaling) and the 4 `CONTRADICTED` + 17 `INCONSISTENT` internal catches.
   - **§3:** Respecting outside bars (`26 PRIOR-CONSTRAINED`, `17 PRIOR-CONSISTENT`) and the 6 `XTR-01` cross-domain bridges (`B1`–`B6`).
   - **§4:** The 9 Pre-Registered Discovery Tests (`T-1` to `T-9`).
3. **[`FINAL_MASTER_ANALYSIS_ARGON_REVISION.md`](FINAL_MASTER_ANALYSIS_ARGON_REVISION.md) (`ARGON-FINAL-MASTER-02-REVISION`)** — *Revised Master Technical Consolidation:*
   - **§1:** Executive Summary & 9-Layer Multi-Agent Architecture.
   - **§2:** The Onion-Layer & Breathing-Crevice Lens (`A3-weak` `PROPOSED`, `D10` declaration, Symmetric Ceiling Rule `R5`, 11-decade Stokes $\delta_\nu$ bridge, planar seam area leverage).
   - **§3:** Re-Evaluated Spectral Bands `Q`, `CE`, and `V` under `MSL-ADD-01`.
   - **§4:** Integration of `XTR-01` Scale Ladders (`L1`–`L3`) and Cross-Domain Bridges (`B1`–`B6`).
   - **§5:** Complete 95-Row Re-Evaluated Master Claims Ledger (`56 SPH-01 + 39 XTR-01`).
   - **§6:** Binding Superseded Values Registry (`SVR`) & All 13 Remediated `XTR-01` Defects (`D1`–`D13`).
   - **§7:** Pre-Registered Discovery Test Queue (`T-1`–`T-9`).
4. **[`FINAL_MASTER_ANALYSIS_REVISION.md`](FINAL_MASTER_ANALYSIS_REVISION.md) (`FINAL-MASTER-ANALYSIS-02-REVISION`)** — *Revised Ground-Truth Master Analysis:* Updated axiom tables (`A1`–`A4`), engineering core, `XTR-01` ground-truth numbers, `D1`–`D13` remediations, and ground-truth ledger under `MSL-ADD-01`.
5. **[`README_REVISION.md`](README_REVISION.md)** & **[`TOC_REVISION.md`](TOC_REVISION.md)** — Revised Edition repository README and Master Table of Contents.
6. **[`MANDATE_ADDENDUM_XTR.md`](MANDATE_ADDENDUM_XTR.md) (`MSL-ADD-01`)** · **[`WORK_OFFLOAD_DIRECTIVE_XTR01.md`](WORK_OFFLOAD_DIRECTIVE_XTR01.md)** · **[`ARGON_REEVALUATION_PROMPT.md`](ARGON_REEVALUATION_PROMPT.md)** · **[`CORPUS_INTEGRATION_REPORT_XTR01.md`](CORPUS_INTEGRATION_REPORT_XTR01.md)** — Governing specifications and integration audit for the Revised Edition.

---

## Part II — Revised Edition Publication Package (`C:\LuxAura\study\revision\`)

The self-contained Revised Edition release directory [`C:\LuxAura\study\revision\`](revision/) is organized into five clean subdirectories verified by [`revision/MANIFEST.sha256`](revision/MANIFEST.sha256):

1. **`revision/root_revision_docs/`** — All Revised Edition root whitepapers (`*_REVISION.md`), `Revision.md`, `MANDATE_ADDENDUM_XTR.md`, `WORK_OFFLOAD_DIRECTIVE_XTR01.md`, `ARGON_REEVALUATION_PROMPT.md`, and `CORPUS_INTEGRATION_REPORT_XTR01.md`.
2. **`revision/xtr01_canonical/`** — The canonical, defect-remediated (`D1`–`D13`) `XTR-01` deliverables merged from `AgentA/` and `AgentB/` per `CORPUS_INTEGRATION_REPORT_XTR01.md` §5.
3. **`revision/argon_reevaluation/`** — Mirror of `extrapolation_XTR01/ARGON/` containing `ARGON_REEVALUATION.md`, `claims_ledger_regraded.csv` (95 rows), `outputs/reevaluation_metrics.json`, `outputs/corpus_scan.json`, and reproducible Python scripts.
4. **`revision/reports_sph01_and_tracks/`** — Hardened `_v2.md` reports, Band `Q`/`CE`/`V` reports, `OpenCodeBP/`, `VPDR-01`, `BGCDR-01`, and `VERIFICATION_MATRIX_01`.
5. **`revision/img/`** — All 17 visual plates (`image1`–`image17`) plus analytical charts from `VERIFICATION_MATRIX_01`, `VPDR-01`, `BGCDR-01`, and `FINAL_MASTER_ANALYSIS_figures/`.

---

## Part III — Canonical `XTR-01` Scale Ladders (`L1`–`L3`) & Cross-Domain Bridges (`B1`–`B6`) (`revision/xtr01_canonical/`)

Constructed according to the exact canonical integration map in [`CORPUS_INTEGRATION_REPORT_XTR01.md`](CORPUS_INTEGRATION_REPORT_XTR01.md) §5 (excluding voided files `AgentA/outputs/nme_fit.json`, `AgentA/outputs/L1_strain_ladder.csv`, and `AgentA/outputs/L3_memory_ladder.csv`):

1. **`hard_data_extract_R11.csv`** — Merged 25-row Pass 1 (`R1`–`R10`) + Pass 2 (`R11` verified `PASS`) hard-data extraction table (`D1` fixed).
2. **`semantic_glossary_merged.csv`** — Unified 18-term semantic glossary combining Track A's dual Sanskrit/physical readings (`R9`) with Track B's `MSL-ADD-01` statuses and paired tests (`D13` fixed).
3. **`L1_STRAIN_LADDER.csv`** — 7-row strain ladder from tidal $\varepsilon = 10^{-8}$ to breakdown $\varepsilon = 10^{-3}$, including $\mathcal{S}=0$ at $\varepsilon = 2.96\times 10^{-4}$ and $Q^{-1}=1$ at $\varepsilon = 9.42\times 10^{-4}$ (`D3`, `D6` fixed).
4. **`L2_COHERENCE_LADDER_v2.csv`** — 7-row quantum-to-classical thermal occupancy ladder with explicit evaluation frequency $f$ (`21.5 kHz` acoustic vs. `100 MHz` SQUID at $15\text{ mK}$, `D11` fixed).
5. **`L3_MEMORY_LADDER_v2.csv`** — 5-row logarithmic memory & fracture-cascade ladder with laboratory NME slope marked `PROPOSED (deferred to T-1)` (`D2`, `D3` fixed) and Deccan ComCat $b = 1.2532$ marked `SUPPORTED (OWN-TEST)`.
6. **`bfit_comcat.json`** & **`aki_bvalue.py`** — Pre-registered USGS ComCat Deccan earthquake catalog fit ($b = 1.2532$, $\text{CI}_{95}\ [1.1292, 1.3900]$, $M_c = 4.4$, $N = 492$, `Ellora ±10°`, 2000–2026).
7. **`BRIDGE_B1_v2.md` to `BRIDGE_B6_v2.md`** — Canonical cross-domain bridge reports with all external bars re-graded to `PRIOR-CONSTRAINED`, un-fetched citations tagged *(not re-fetched)* (`D4`, `D8`), and static $\kappa_{\text{allowed}} = 10^{-11}$ distinguished from dynamic $21.5\text{ kHz}$ $\kappa_{\text{req}} = 6.80\times 10^{-4}$ (`D5`).
8. **`STRESS_LEDGER.csv`** & **`STRESS_TEST_v2.md`** — Stress-breakdown audit cleanly separating the zero-modulus root ($\varepsilon = 2.96\times 10^{-4}$) from the unit loss limit ($\varepsilon = 9.42\times 10^{-4}$, `D6` fixed).
9. **`PUBLICATION_PLAN_v2.md`** & **`DEFERRALS_v2.md`** — Merged 5-paper + 6-journal + 8-figure publication plan, `T-1..T-9` discovery test queue (`D9`), and complete deferral registry (`D7`).

---

## Part IV — Argon 95-Row `MSL-ADD-01` Re-Evaluation Suite (`extrapolation_XTR01/ARGON/`)

1. **[`extrapolation_XTR01/ARGON/ARGON_REEVALUATION.md`](extrapolation_XTR01/ARGON/ARGON_REEVALUATION.md)** — Complete re-evaluation report detailing what moved (`52` claims), what held steady (`43` claims), and why.
2. **[`extrapolation_XTR01/ARGON/claims_ledger_regraded.csv`](extrapolation_XTR01/ARGON/claims_ledger_regraded.csv)** — Machine-readable 95-row re-evaluated ledger (`56 SPH-01 + 39 XTR-01`).
3. **[`extrapolation_XTR01/ARGON/outputs/reevaluation_metrics.json`](extrapolation_XTR01/ARGON/outputs/reevaluation_metrics.json)** & **`corpus_scan.json`** — Exact transition counts and corpus inventory.
4. **`extrapolation_XTR01/ARGON/scripts/`** — Reproducible Python builders (`scan_corpus.py`, `build_ledger.py`, `generate_report_and_manifest.py`, `gen_public_and_fma_revision.py`, `gen_argon_master_revision.py`, `gen_readme_and_toc_revision.py`, `build_revision_package.py`).

---

## Part V — Preserved First Edition (`SPH-01`) Syntheses, Reports & `publish/` Archive

All First Edition (`SPH-01` — *"House Cards, Dealer Rules"*) files remain intact at their original paths:
* [`FINAL_MASTER_ANALYSIS_ARGON.md`](FINAL_MASTER_ANALYSIS_ARGON.md) · [`PUBLIC_REFLECTION_ARGON.md`](PUBLIC_REFLECTION_ARGON.md) · [`FINAL_MASTER_ANALYSIS.md`](FINAL_MASTER_ANALYSIS.md) · [`README.md`](README.md) · [`TOC.md`](TOC.md)
* [`publish/`](publish/) & [`publish.zip`](publish.zip) (`142` files verified by [`MANIFEST.sha256`](MANIFEST.sha256))

---

## Part VI — Preserved Read-Only v1 Baseline Corpus (`Rule R2`)

All 18 original files pinned in [`hardening_SPH01/PREREG.md`](hardening_SPH01/PREREG.md) remain 100% byte-identical (`18/18 PASS`) across both the First Edition and the Revised Edition.
"""

(ROOT / "README_REVISION.md").write_text(README_REV, encoding="utf-8")
(ROOT / "TOC_REVISION.md").write_text(TOC_REV, encoding="utf-8")
print("Wrote README_REVISION.md and TOC_REVISION.md successfully.")
