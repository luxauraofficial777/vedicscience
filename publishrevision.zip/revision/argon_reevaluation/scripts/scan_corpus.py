import os
import re
import json
import hashlib

STUDY_DIR = r"C:\LuxAura\study"
OUT_DIR = r"C:\LuxAura\study\extrapolation_XTR01\ARGON\outputs"
os.makedirs(OUT_DIR, exist_ok=True)

# 1. Verify PREREG.md 18 original file hashes
prereg_path = os.path.join(STUDY_DIR, "hardening_SPH01", "PREREG.md")
prereg_hashes = []
with open(prereg_path, "r", encoding="utf-8") as f:
    for line in f:
        m = re.match(r"\|\s*`([^`]+)`\s*\|\s*([\d,]+)\s*\|\s*`([0-9a-fA-F]{64})`\s*\|", line.strip())
        if m:
            rel_path, size_str, expected_hash = m.group(1), int(m.group(2).replace(",", "")), m.group(3).lower()
            full_path = os.path.join(STUDY_DIR, rel_path.replace("/", os.sep))
            with open(full_path, "rb") as bf:
                data = bf.read()
            actual_hash = hashlib.sha256(data).hexdigest().lower()
            prereg_hashes.append({
                "file": rel_path,
                "expected_size": size_str,
                "actual_size": len(data),
                "expected_sha256": expected_hash,
                "actual_sha256": actual_hash,
                "match": (actual_hash == expected_hash and len(data) == size_str)
            })

# 2. Scan existing corpus for CONTRADICTED and INCONSISTENT occurrences
contradicted_hits = []
inconsistent_hits = []
for root, dirs, files in os.walk(STUDY_DIR):
    rel_root = os.path.relpath(root, STUDY_DIR).replace("\\", "/")
    if rel_root.startswith("extrapolation_XTR01/ARGON") or rel_root.startswith("publish") or rel_root.startswith(".git"):
        continue
    for fn in sorted(files):
        if fn.endswith((".md", ".csv")):
            fp = os.path.join(root, fn)
            rel_fp = os.path.relpath(fp, STUDY_DIR).replace("\\", "/")
            try:
                with open(fp, "r", encoding="utf-8", errors="replace") as f:
                    for idx, line in enumerate(f, 1):
                        if "CONTRADICTED" in line:
                            contradicted_hits.append({
                                "file": rel_fp,
                                "line": idx,
                                "text": line.strip()[:240]
                            })
                        if "INCONSISTENT" in line and not rel_fp.endswith(".csv"):
                            inconsistent_hits.append({
                                "file": rel_fp,
                                "line": idx,
                                "text": line.strip()[:240]
                            })
            except Exception:
                pass

scan_result = {
    "prereg_count": len(prereg_hashes),
    "prereg_all_match": all(x["match"] for x in prereg_hashes) and len(prereg_hashes) == 18,
    "prereg_files": prereg_hashes,
    "contradicted_hits_count": len(contradicted_hits),
    "contradicted_hits": contradicted_hits,
    "inconsistent_md_hits_count": len(inconsistent_hits),
    "inconsistent_md_hits": inconsistent_hits
}

with open(os.path.join(OUT_DIR, "corpus_scan.json"), "w", encoding="utf-8") as f:
    json.dump(scan_result, f, indent=2, ensure_ascii=False)

print(f"PREREG files checked: {len(prereg_hashes)}, all match: {scan_result['prereg_all_match']}")
print(f"CONTRADICTED hits found: {len(contradicted_hits)}")
print(f"INCONSISTENT md hits found: {len(inconsistent_hits)}")
