#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_readme_counts.py — REVISION-PROOFREAD-01 Rev B, follow-up F11 (2026-10-18)

The README §3 status table (README.md, README_REVISION.md and its copies, and the gen_readme_and_toc_revision.py
string) still carried the pre-decision counts and three wrong test pairings after apply_ledger_decisions.py.
This rewrites the eight status rows from reevaluation_metrics.json (first 56 rows = SPH-01, last 39 = extended),
fixes the A3-weak pairing (T-3 -> T-4 + E4-Mm refit), and points the verify command at the script's real path.
Deterministic; every anchor must match exactly once per file; logged into outputs/ledger_decisions_changes.json.
"""
import os, io, json, hashlib

HERE = os.path.dirname(os.path.abspath(__file__)); ARG = os.path.dirname(HERE); REV = os.path.dirname(ARG)
def rd(p): return io.open(p, encoding="utf-8", errors="surrogateescape", newline="").read()
def wr(p, s): io.open(p, "w", encoding="utf-8", errors="surrogateescape", newline="").write(s)
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()

m = json.load(open(os.path.join(ARG, "outputs", "reevaluation_metrics.json"), encoding="utf-8"))
NC, NS, NE = (m[k]["new_status_counts"] for k in ("all_95_rows", "sph01_56_rows", "extra_39_rows"))
assert NC["SUPPORTED"] == 19 and NC["INCONSISTENT"] == 17 and NC["PRIOR-CONSISTENT"] == 17

OLD = {
 "SUPPORTED": "| **`SUPPORTED`** | 16 | 4 | **20** | `21.1%` | Verified by our own pre-registered empirical run (`OWN-TEST`) or zero-outside-data derivation (`DERIVATION` / `COMMAND`) |",
 "CONTRADICTED": "| **`CONTRADICTED`** | 2 | 2 | **4** | `4.2%` | Refuted by our own empirical run (`E4` synodic null) or internal conservation-law no-go (`DERIVATION`) |",
 "INCONSISTENT": "| **`INCONSISTENT`** | 15 | 1 | **16** | `16.8%` | Internal arithmetic, dimensional, or parameter self-contradiction (`INTERNAL-ARITHMETIC`) |",
 "PRIOR-CONSISTENT": "| **`PRIOR-CONSISTENT`** | 11 | 8 | **19** | `20.0%` | Consistent with external published literature (`EXTERNAL-LITERATURE`); no own test run yet |",
 "PRIOR-CONSTRAINED": "| **`PRIOR-CONSTRAINED`** | 7 | 19 | **26** | `27.4%` | Constrained by an external published bar (`value ± uncertainty, source, medium`); paired with an internal test |",
 "PROPOSED": "| **`PROPOSED`** | 0 | 3 | **3** | `3.2%` | Testable hypothesis with stated falsifiers (`A3-weak` / `E4-Mm` `T-3`, dynamic `E1` `T-5`, `L1`–`L3` `T-1`) |",
 "PROPOSED-INCOMPLETE": "| **`PROPOSED-INCOMPLETE`** | 1 | 2 | **3** | `3.2%` | Hypothesis missing an internal parameter or field measurement (`T-2`, `T-9`) |",
 "ALLEGORY": "| **`ALLEGORY`** | 4 | 0 | **4** | `4.2%` | Symbolic operator ($\\Psi_g, \\Xi_{23D}, P_{\\text{bs}}$) or structural metaphor (`A04-002`) |",
}
MEAN = {
 "SUPPORTED": "Verified by our own pre-registered empirical run (`OWN-TEST`) or zero-outside-data derivation (`DERIVATION` / `COMMAND`)",
 "CONTRADICTED": "Refuted by our own empirical run (`E4` synodic null) or internal conservation-law no-go (`DERIVATION`)",
 "INCONSISTENT": "Internal arithmetic, dimensional, or parameter self-contradiction (`INTERNAL-ARITHMETIC`), including own data against own data (`T03-003`, pending `V3`)",
 "PRIOR-CONSISTENT": "Consistent with external published literature (`EXTERNAL-LITERATURE`); no own test run yet",
 "PRIOR-CONSTRAINED": "Constrained by an external published bar (`value ± uncertainty, source, medium`); paired with an internal test",
 "PROPOSED": "Admitted with a prediction and a falsifier, untested by own data (`A3-weak` `T-4` + `E4-Mm` refit, dynamic `E1` `T-5`, `BGCDR-04/05` `NEW-T18/19`)",
 "PROPOSED-INCOMPLETE": "Hypothesis missing a named input (`NEW-T10`, `T-8`, `T-9`; `OWN-STASIS` needs a prediction with a unit and a falsifier before any test is queued)",
 "ALLEGORY": "Symbolic operator ($\\Psi_g, \\Xi_{23D}, P_{\\text{bs}}$) or structural metaphor (`A04-002`)",
}
def new_row(s): return f"| **`{s}`** | {NS.get(s, 0)} | {NE.get(s, 0)} | **{NC.get(s, 0)}** | `{100.0 * NC.get(s, 0) / 95:.1f}%` | {MEAN[s]} |"
PAIRS = [(OLD[s], new_row(s)) for s in OLD] + [
 ("(`OpenCodeBP` §6.3, paired with test `T-3`)", "(`OpenCodeBP` §6.3, paired with test `T-4` and the `E4-Mm` poroelastic refit)"),
 ("python extrapolation_XTR01/ARGON/scripts/build_revision_package.py --verify", "python revision/argon_reevaluation/scripts/build_revision_package.py --verify"),
]
TARGETS = [os.path.join(REV, p) for p in ("README.md", "README_REVISION.md", "root_revision_docs/README_REVISION.md", "for_root/README_REVISION.md")] + \
          [os.path.join(HERE, "gen_readme_and_toc_revision.py")]
log = {}
for p in TARGETS:
    t = rd(p); crlf = "\r\n" in t; before = sha(p); n = 0
    for o, nw in PAIRS:
        for oo, nn in ((o, nw), (o.replace("\\", "\\\\"), nw.replace("\\", "\\\\"))):
            if crlf: oo, nn = oo.replace("\n", "\r\n"), nn.replace("\n", "\r\n")
            c = t.count(oo)
            if c == 1: t = t.replace(oo, nn); n += 1; break
        else:
            raise SystemExit(f"anchor missing in {os.path.relpath(p, REV)}: {o[:90]}")
    wr(p, t); log[os.path.relpath(p, REV).replace("\\", "/")] = {"sha256_before": before, "sha256_after": sha(p), "edits": n}
pc = os.path.join(ARG, "outputs", "ledger_decisions_changes.json")
j = json.load(open(pc, encoding="utf-8")); j["F11_readme_table"] = log
json.dump(j, open(pc, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("README table rewritten in", len(log), "files;", sum(v["edits"] for v in log.values()), "edits")
