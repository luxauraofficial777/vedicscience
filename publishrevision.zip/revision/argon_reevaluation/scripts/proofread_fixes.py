#!/usr/bin/env python3
"""
proofread_fixes.py — final publication finishes for C:\LuxAura\study\revision\
Run from the study root. Deterministic. Every change is logged to revision/argon_reevaluation/outputs/proofread_changes.json.
Fixes:
  F1  links: resolve root-relative targets from inside revision/ (prefix ../), map extrapolation_XTR01/ARGON/ -> argon_reevaluation/
  F2  L2_COHERENCE_LADDER_v2.csv regenerated (n_th = k_B T / h f, explicit f and T per row) — the v2 on disk had empty rows
  F3  '100 MHz SQUID (at 15 mK)' -> 'SQUID readout at 4 K'; L2 row count 7 -> 9
  F4  STRESS_TEST_v2.md line: '(Q^-1<1)' misattribution on the 2.96e-4 zero-modulus root
  F5  '$\\to$' -> '→' in heading lines only
  F6  MANIFEST.sha256 and REVISION_MANIFEST.json regenerated (uppercase hex, CRLF, same layout)
"""
import os, re, json, hashlib, glob, sys
ROOT = os.path.abspath('.')
REV = os.path.join(ROOT, 'revision')
assert os.path.isdir(REV), 'run from C:\\LuxAura\\study'
log = {'F1_links': [], 'F2_L2': None, 'F3_text': [], 'F4_stress': [], 'F5_headings': [], 'F6_manifest': None, 'unresolved_links': []}

def rd(p): return open(p, encoding='utf-8', errors='surrogateescape').read()
def wr(p, s): open(p, 'w', encoding='utf-8', errors='surrogateescape', newline='').write(s)

# ---------------- F1 links ----------------
LINK = re.compile(r'(\]\()([^)\s#]+)((?:#[^)]*)?\))')
mds = [p for p in glob.glob(os.path.join(REV, '**', '*.md'), recursive=True)]
# for_root/ holds copies whose links are ROOT-relative (for promotion to the study root); the in-place fixer must not touch them
F1_SKIP = [p for p in mds if '/for_root/' in p.replace('\\', '/')]
for p in mds:
    if p in F1_SKIP: continue
    d = os.path.dirname(p); s = rd(p); changed = 0
    def fix(m):
        global changed
        pre, t, post = m.group(1), m.group(2), m.group(3)
        if t.startswith(('http://', 'https://', 'mailto:')): return m.group(0)
        tt = t.replace('\\', '/')
        if os.path.exists(os.path.join(d, tt)): return m.group(0)                     # already resolves
        new = None
        if tt.startswith('extrapolation_XTR01/ARGON/') or tt == 'extrapolation_XTR01/ARGON':
            tail = tt[len('extrapolation_XTR01/ARGON'):].lstrip('/')
            new = os.path.relpath(os.path.join(REV, 'argon_reevaluation', tail), d).replace('\\', '/')
        elif tt.startswith('revision/') and os.path.exists(os.path.join(REV, tt[len('revision/'):])):
            new = os.path.relpath(os.path.join(REV, tt[len('revision/'):]), d).replace('\\', '/')
        elif os.path.exists(os.path.join(ROOT, tt)):
            new = os.path.relpath(os.path.join(ROOT, tt), d).replace('\\', '/')
        else:
            # verbatim copies in reports_sph01_and_tracks/ etc. keep links relative to their ORIGIN folder
            for origin in ('hardening_SPH01', 'BIO_GENE_CELLULAR_DEEP_RESEARCH', 'VEDIC_PLASMA_DEEP_RESEARCH',
                           'VERIFICATION_MATRIX_01', 'OpenCodeBP', 'AgentA', 'AgentB', ''):
                cand = os.path.normpath(os.path.join(ROOT, origin, tt))
                if cand.startswith(ROOT) and os.path.exists(cand):
                    new = os.path.relpath(cand, d).replace('\\', '/'); break
        if new is None:
            log['unresolved_links'].append({'file': os.path.relpath(p, ROOT), 'target': t}); return m.group(0)
        if new.endswith('/.'): new = new[:-1]
        log['F1_links'].append({'file': os.path.relpath(p, ROOT), 'from': t, 'to': new}); changed += 1
        return pre + new + post
    s2 = LINK.sub(fix, s)
    if s2 != s: wr(p, s2)

# ---------------- F2 L2 ladder ----------------
kB, h = 1.380649e-23, 6.62607015e-34
rows = [
 # system, T_K, f_eval_Hz, f_note, tau_coh_s, tau_process_s, verdict, status, anchor
 ("Radical-pair magnetoreception (cryptochrome)", 300, 1.0e6, "hyperfine/Larmor-scale radical-pair frequency", 1e-6, 1e-6, "QUANTUM-MOLECULAR", "PRIOR-CONSISTENT", "Hore & Mouritsen 2016; Xu et al. 2021 (not re-fetched)"),
 ("Enzyme hydrogen tunnelling", 300, 1.085e12, "barrier-crossing attempt frequency used by Track B", 1e-12, 1e-12, "QUANTUM-MOLECULAR", "PRIOR-CONSISTENT", "Klinman & Kohen 2013 (not re-fetched)"),
 ("Photosynthetic vibronic coherence (2020 consensus)", 300, 1.085e12, "vibronic mode frequency used by Track B", 1e-12, 1e-12, "QUANTUM-MOLECULAR", "PRIOR-CONSISTENT", "Cao et al. 2020 (not re-fetched)"),
 ("Corpus 'coherent phonon condensation' at 21.5 kHz", 300, 2.15e4, "NME drive frequency (corpus)", 0.0, 4.651e-5, "CLASSICAL", "DERIVATION (own computation; A02-001 INCONSISTENT as a condensate)", "Article 02 / claims_ledger A02-001"),
 ("Corpus Glauber phonon reference at 25 kHz", 300, 2.5e4, "reference mode (corpus)", 0.0, 4.0e-5, "CLASSICAL", "DERIVATION (own computation)", "spectrum_ledger SP-15"),
 ("Dislocation kink-pair tunnelling (Petukhov-Pokrovskii)", 300, 1.878e12, "attempt frequency 1/tau_0, tau_0 = 0.5324 ps (verify_quantum_resonance.py); the reference's 10 GHz phonon would give n_th ~ 625", 5.324e-13, 1e-12, "CLASSICAL at 300 K (quantum regime below ~10 K)", "DERIVATION (own computation; SDT-001 v2)", "Standard_Dislocation_Tunneling_Reference_v2.md"),
 ("SQUID persistent current (superconducting gravimeter readout)", 4.2, 0.0, "DC persistent current; SQUID readout at liquid-helium temperature", float('inf'), float('inf'), "QUANTUM-DEVICE", "PRIOR-CONSISTENT", "Goodkind 1999 (not re-fetched)"),
 ("Atom-interferometer gravimeter / gradiometer", 1e-6, 1.0e3, "pulse-sequence scale used by Track B", 1e-3, 1e-3, "QUANTUM-DEVICE", "PRIOR-CONSISTENT", "Stray et al. 2022 (not re-fetched)"),
 ("Earth radial breathing mode 0S0", 300, 8.1466e-4, "observed 0S0 frequency", 1.6e7, 1.6e7, "CLASSICAL", "PRIOR-CONSISTENT", "spectrum_ledger SP-05; Roult et al. 2010 (not re-fetched)"),
]
out = ["system,T_K,f_eval_Hz,f_eval_note,n_th_at_f_eval,tau_coh_s,tau_process_s,verdict,msl_add_01_status,anchor"]
for sys_, T, f, note, tc, tp, v, st, anc in rows:
    nth = "inf" if f == 0 else f"{kB*T/(h*f):.4g}"
    q = lambda x: '"' + x.replace('"', "'") + '"'
    out.append(",".join([q(sys_), f"{T:g}", f"{f:.4g}", q(note), nth, ("inf" if tc == float('inf') else f"{tc:.4g}"), ("inf" if tp == float('inf') else f"{tp:.4g}"), q(v), q(st), q(anc)]))
l2 = os.path.join(REV, 'xtr01_canonical', 'L2_COHERENCE_LADDER_v2.csv')
wr(l2, "\n".join(out) + "\n")
log['F2_L2'] = {'rows': len(rows), 'kT_over_h_300K_Hz': kB*300/h}

# ---------------- F3 text fixes ----------------
TEXT = [
 (r"\(`21\.5 kHz` acoustic vs\. `100 MHz` SQUID at \$15\\text\{ mK\}\$, `D11` fixed\)", "(`21.5 kHz` acoustic vs. the SQUID readout of a 4 K superconducting gravimeter, `D11` fixed)"),
 (r"\(`21\.5 kHz` acoustic vs\. `100 MHz` SQUID\)", "(`21.5 kHz` acoustic vs. the SQUID readout of a 4 K superconducting gravimeter)"),
 (r"7-row quantum-to-classical thermal occupancy ladder", "9-row quantum-to-classical thermal occupancy ladder"),
]
for p in mds:
    s = rd(p); s2 = s
    for pat, rep in TEXT:
        s2, n = re.subn(pat, rep, s2)
        if n: log['F3_text'].append({'file': os.path.relpath(p, ROOT), 'pattern': pat, 'n': n})
    if s2 != s: wr(p, s2)

# ---------------- F4 stress test ----------------
st = os.path.join(REV, 'xtr01_canonical', 'STRESS_TEST_v2.md')
s = rd(st)
old = "NME softening valid only ε < 2.96×10⁻⁴ (Q⁻¹<1)"
new = "NME softening valid only ε < 2.96×10⁻⁴ (the zero-modulus root of the backbone polynomial; the loss model itself leaves its domain separately at Q⁻¹ = 1, ε = 9.42×10⁻⁴)"
if old in s:
    wr(st, s.replace(old, new)); log['F4_stress'].append({'file': os.path.relpath(st, ROOT), 'from': old, 'to': new})

# ---------------- F5 headings ----------------
for p in mds:
    lines = rd(p).split('\n'); ch = 0
    for i, ln in enumerate(lines):
        if ln.startswith('#') and '$\\to$' in ln:
            lines[i] = ln.replace('$\\to$', '→'); ch += 1
    if ch:
        wr(p, '\n'.join(lines)); log['F5_headings'].append({'file': os.path.relpath(p, ROOT), 'n': ch})

# ---------------- F1b root-ready copies ----------------
# revision/for_root/<name>.md = root_revision_docs/<name>.md with every relative link rebased to the study root,
# so the owner can copy them to C:\LuxAura\study\ unchanged.
FR = os.path.join(REV, 'for_root'); os.makedirs(FR, exist_ok=True)
rrd = os.path.join(REV, 'root_revision_docs')
for p in sorted(glob.glob(os.path.join(rrd, '*.md'))):
    s = rd(p)
    def rebase(m):
        pre, t, post = m.group(1), m.group(2), m.group(3)
        if t.startswith(('http://', 'https://', 'mailto:')): return m.group(0)
        ab = os.path.normpath(os.path.join(rrd, t.replace('\\', '/')))
        if not os.path.exists(ab): return m.group(0)
        return pre + os.path.relpath(ab, ROOT).replace('\\', '/') + post
    wr(os.path.join(FR, os.path.basename(p)), LINK.sub(rebase, s))
log['F1b_for_root'] = sorted(os.path.basename(p) for p in glob.glob(os.path.join(FR, '*.md')))

# ---------------- F6 manifest ----------------
os.makedirs(os.path.join(REV, 'argon_reevaluation', 'outputs'), exist_ok=True)
wr(os.path.join(REV, 'argon_reevaluation', 'outputs', 'proofread_changes.json'), json.dumps(log, indent=1, ensure_ascii=False))
files = sorted(os.path.relpath(p, REV).replace('\\', '/') for p in glob.glob(os.path.join(REV, '**', '*'), recursive=True) if os.path.isfile(p))
files = [f for f in files if f not in ('MANIFEST.sha256',)]
entries = []
for f in files:
    b = open(os.path.join(REV, f), 'rb').read()
    entries.append((hashlib.sha256(b).hexdigest().upper(), len(b), f))
open(os.path.join(REV, 'MANIFEST.sha256'), 'w', encoding='utf-8', newline='').write("".join(f"{h}  {f}\r\n" for h, n, f in entries))
rm = os.path.join(REV, 'REVISION_MANIFEST.json')
j = json.load(open(rm, encoding='utf-8'))
j['files'] = [{'path': f, 'bytes': n, 'sha256': h} for h, n, f in entries if f != 'REVISION_MANIFEST.json']
j['total_files'] = len(j['files'])
j['proofread'] = {'by': 'Claude (Fable)', 'date': '2026-10-18', 'changes': 'argon_reevaluation/outputs/proofread_changes.json', 'audit': 'PROOFREAD_AUDIT.md'}
open(rm, 'w', encoding='utf-8', newline='').write(json.dumps(j, indent=2, ensure_ascii=False))
# re-hash REVISION_MANIFEST.json into MANIFEST.sha256 (it changed)
entries = [(hashlib.sha256(open(os.path.join(REV, f), 'rb').read()).hexdigest().upper(), os.path.getsize(os.path.join(REV, f)), f) for f in files]
open(os.path.join(REV, 'MANIFEST.sha256'), 'w', encoding='utf-8', newline='').write("".join(f"{h}  {f}\r\n" for h, n, f in entries))
log['F6_manifest'] = {'entries': len(entries)}
print(json.dumps({k: (len(v) if isinstance(v, list) else v) for k, v in log.items()}, indent=1))
print("unresolved:", json.dumps(log['unresolved_links'][:20], indent=1))
