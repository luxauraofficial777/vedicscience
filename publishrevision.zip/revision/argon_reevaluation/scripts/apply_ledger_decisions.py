#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
apply_ledger_decisions.py — REVISION-PROOFREAD-01 §3, owner decision 2026-10-18 08:20 EDT ("Update the ledger rows")

Applies three re-gradings AT THE SOURCE (scripts/build_ledger.py), regenerates the ledger, the metrics and
ARGON_REEVALUATION.md through Argon's own scripts, and propagates every count that changed to every document in
revision\\ that cites it (and to the gen_*.py strings those documents came from). Deterministic. Every anchor is
asserted to occur exactly once before a file is written; nothing is written if any anchor is missing.

  D1  T03-003        SUPPORTED        -> INCONSISTENT   (internal: analytic 1,570.80 Pa/m vs own FDTD 1.74 Pa/m; cleared by V3)
  D2  AXIOM-A3-WEAK  PRIOR-CONSISTENT -> PROPOSED       (bar kept as context; T-4 + E4-Mm refit; flagged SELF)
  D3  OWN-STASIS     PRIOR-CONSISTENT -> PROPOSED-INCOMPLETE (old_status OPEN, ground NO-PREDICTION; nothing queued)

  P1  build_ledger.py / generate_report_and_manifest.py: ARGON_DIR -> revision\\argon_reevaluation (defect D12)
  P2  generate_report_and_manifest.py: §1.2 transition matrix and the ground / changed-vs-unchanged lines are now
      computed from reevaluation_metrics.json (R16); §2, §3, §5 hard-coded lists updated; --manifest-only flag
  P3  FINAL_MASTER_ANALYSIS_ARGON_REVISION.md (3 copies): §5.1 computed from the metrics, §5.2/§5.3 rebuilt from
      the CSV with the 56/39 partition the document itself declares; §2 item 3 aligned with the ledger
  P4  count strings in FINAL_MASTER_ANALYSIS_REVISION, PUBLIC_REFLECTION_ARGON_REVISION, README(_REVISION),
      TOC(_REVISION) (all copies) and in gen_*.py; PROOFREAD_AUDIT.md §1–§3 and §5; proofread_changes.json

Run from anywhere:  python apply_ledger_decisions.py
Then:               python proofread_fixes.py ; python generate_report_and_manifest.py --manifest-only ; python proofread_fixes.py
"""
import os, sys, io, re, csv, json, hashlib, subprocess, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
ARG  = os.path.dirname(HERE)                 # revision\argon_reevaluation
REV  = os.path.dirname(ARG)                  # revision
ROOT = os.path.dirname(REV)                  # study
PY   = sys.executable
NOW  = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

MARK = "# REV-C 2026-10-18 proofread (REVISION-PROOFREAD-01 §3, owner decision 08:20 EDT)"

def rd(p): return io.open(p, encoding="utf-8", errors="surrogateescape", newline="").read()
def wr(p, s): io.open(p, "w", encoding="utf-8", errors="surrogateescape", newline="").write(s)
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()

LOG = {"applied": NOW, "decisions": ["D1 T03-003 -> INCONSISTENT (V3)", "D2 AXIOM-A3-WEAK -> PROPOSED (SELF)",
                                      "D3 OWN-STASIS -> PROPOSED-INCOMPLETE"], "files": {}}
DONE = os.path.join(ARG, "outputs", "ledger_decisions_changes.json")
if os.path.exists(DONE):
    raise SystemExit("already applied (outputs/ledger_decisions_changes.json exists)")

# Argon's scripts hard-code C:\LuxAura\study. This shim runs them with the roots resolved from where the scripts
# sit (identical on the owner's machine; the mounted path when run from the Linux side). The files are not changed.
SHIM = r'''
import sys, io
p, root, arg = sys.argv[1], sys.argv[2], sys.argv[3]
src = io.open(p, encoding="utf-8").read()
src = src.replace('STUDY_DIR = r"C:\\LuxAura\\study"', 'STUDY_DIR = r"%s"' % root)
src = src.replace('ARGON_DIR = r"C:\\LuxAura\\study\\revision\\argon_reevaluation"', 'ARGON_DIR = r"%s"' % arg)
sys.argv = [p] + sys.argv[4:]
exec(compile(src, p, "exec"), {"__name__": "__main__", "__file__": p})
'''
def run_argon(script, *extra):
    r = subprocess.run([PY, "-c", SHIM, script, ROOT, ARG, *extra], cwd=HERE, capture_output=True, text=True)
    if r.returncode: raise SystemExit(f"{os.path.basename(script)} failed:\n{r.stdout}{r.stderr}")
    return r.stdout

class Doc:
    """In-memory editor: collects asserted replacements, writes once."""
    def __init__(self, path, py=False):
        self.path, self.py = path, py
        self.text = rd(path)
        self.crlf = "\r\n" in self.text
        self.before = sha(path)
        self.edits = []
    def _variants(self, s):
        v = [s]
        if self.crlf: v = [x.replace("\n", "\r\n") for x in v]
        if self.py:   v += [x.replace("\\", "\\\\") for x in v]   # a("...") strings double their backslashes
        return v
    def rep(self, old, new, count=1):
        for o in self._variants(old):
            n = self.text.count(o)
            if n == count:
                nn = new
                if self.crlf: nn = nn.replace("\n", "\r\n")
                if self.py and o != old.replace("\n", "\r\n") and o != old: nn = nn.replace("\\", "\\\\")
                self.text = self.text.replace(o, nn)
                self.edits.append({"old": old[:160], "new": new[:160]})
                return self
        raise SystemExit(f"ANCHOR MISSING in {os.path.relpath(self.path, REV)} (expected {count}):\n  {old[:200]}")
    def sub(self, pattern, fn, lo, hi):
        """regex substitution restricted to text[lo:hi] (markers are substrings)."""
        a = self.text.index(lo); b = self.text.index(hi, a)
        seg = re.sub(pattern, fn, self.text[a:b], flags=re.M)
        self.text = self.text[:a] + seg + self.text[b:]
        return self
    def save(self):
        wr(self.path, self.text)
        LOG["files"][os.path.relpath(self.path, REV).replace("\\", "/")] = {
            "sha256_before": self.before, "sha256_after": sha(self.path), "edits": self.edits}

# ----------------------------------------------------------------------------------------------------------------
# Phase A — build_ledger.py (the source of the ledger)
# ----------------------------------------------------------------------------------------------------------------
BL = os.path.join(HERE, "build_ledger.py")

def block(doc, cid):
    i = doc.text.index(f'"claim_id": "{cid}"')
    a = doc.text.rfind("{", 0, i); b = doc.text.index("},", i) + 2
    return a, b
def brep(doc, cid, pairs):
    a, b = block(doc, cid); seg = doc.text[a:b]
    for o, n in pairs:
        assert seg.count(o) == 1, f"{cid}: anchor not unique in block: {o}"
        seg = seg.replace(o, n); doc.edits.append({"old": f"[{cid}] " + o[:140], "new": n[:160]})
    doc.text = doc.text[:a] + seg + doc.text[b:]

def phase_a():
    bl = Doc(BL)
    bl.rep('ARGON_DIR = r"C:\\LuxAura\\study\\extrapolation_XTR01\\ARGON"',
           'ARGON_DIR = r"C:\\LuxAura\\study\\revision\\argon_reevaluation"  ' + MARK +
           ': path re-pointed (D12); rows T03-003, AXIOM-A3-WEAK, OWN-STASIS re-graded; see outputs/ledger_decisions_changes.json')
    bl.rep('"T03-003": ("DERIVATION", "SUPPORTED", "delta_v = 0.3745 mm, delta_bl,eff = 0.5520 mm, Q_bl = 1941.1, grad_P = 1570.80 Pa/m", "exact", "sim_cavity_acoustics.py Stokes-Kirchhoff analytical module", "34.40 Hz air cavity boundary layer", "NONE", "", "Verified Stokes-Kirchhoff boundary-layer thickness, quality factor, and analytical pressure gradient"),',
           '"T03-003": ("DERIVATION", "INCONSISTENT", "delta_v = 0.3745 mm, delta_bl,eff = 0.5520 mm, Q_bl = 1941.1 (verified); grad_P analytic = k*P_anti = 0.6283*2500 = 1570.80 Pa/m vs own FDTD 1.74 Pa/m (not run to steady state)", "exact arithmetic; FDTD unconverged", "sim_cavity_acoustics.py Stokes-Kirchhoff analytical module vs the program\'s own FDTD run (DEFERRALS_v2.md V3)", "34.40 Hz air cavity boundary layer", "V3", "", "INCONSISTENT (owner decision 2026-10-18, PROOFREAD_AUDIT.md section 3; internal, own data vs own data): delta_bl,eff and Q_bl stand as DERIVATION; the analytic wall gradient 1570.80 Pa/m disagrees with the program\'s own FDTD (1.74 Pa/m, ~900x) and the FDTD was not run to steady state; cleared by V3 (steady-state run >= Q/pi cycles with impedance boundary; falsifier H-V3: reproduces within 10%)"),')
    brep(bl, "AXIOM-A3-WEAK", [
        ('"new_status": "PRIOR-CONSISTENT"', '"new_status": "PROPOSED"'),
        ('"clearing_test": "T-4"', '"clearing_test": "T-4; E4-Mm poroelastic refit (own pipeline)"'),
        ('"note": "Weak form of A3 (unmapped multi-tier deep-Earth boundary complexity) is PRIOR-CONSISTENT with outside seismology"',
         '"note": "SELF. PROPOSED (owner decision 2026-10-18, PROOFREAD_AUDIT.md section 3; MSL-ADD-01 section 3 row A3-weak): the outside seismology bar (LLSVP/ULVZ heterogeneity; Garnero & McNamara 2008, Ishii & Dziewonski 2002, not re-fetched) confirms unmapped deep-Earth structure, not the lens\'s content (interfacial fraction controlling acoustic/hydraulic behaviour and the E4-Mm band), which has no own test; the bar is kept as context, not as a verdict; falsifiers: the three BP falsifiers; cleared by T-4 and an E4-Mm poroelastic refit on the program\'s own pipeline. SELF: Argon authored the onion-lens framing (FINAL_MASTER_ANALYSIS_ARGON.md section 2; hardening_SPH01 onion documents)"'),
    ])
    brep(bl, "OWN-STASIS", [
        ('"old_status": "CONSISTENT"', '"old_status": "OPEN"'),
        ('"ground_of_old_status": "OUTSIDE-DATA"', '"ground_of_old_status": "NO-PREDICTION"'),
        ('"new_status": "PRIOR-CONSISTENT"', '"new_status": "PROPOSED-INCOMPLETE"'),
        ('"bar_value": "Acoustic levitation traps mm-scale spheres at nodal pressure minima; Chladni nodal trapping"',
         '"bar_value": "E4 null, UL 0.459 nm/s^2 (dg/g < 4.68e-11) at lunar synodic cadence, for the claim\'s one prior form; mm-scale acoustic levitation (outside, not re-fetched) is context only, not a bar for an Earth-scale claim"'),
        ('"bar_uncertainty": "mm-scale objects in air"', '"bar_uncertainty": "0.173 nm/s^2"'),
        ('"bar_source": "Acoustic levitation literature (not re-fetched)"', '"bar_source": "Own pre-registered test E4 [CIT-011]; acoustic levitation literature (not re-fetched)"'),
        ('"bar_medium": "Standing ultrasonic wave in air"', '"bar_medium": "Superconducting gravimetry at lunar synodic cadence"'),
        ('"clearing_test": "T-5"', '"clearing_test": "NONE"'),
        ('"missing_item": ""', '"missing_item": "a prediction with a unit and a falsifier (MSL-ADD-01 section 3: needs a number and a falsifier before it can be queued)"'),
        ('"note": "PRIOR-CONSISTENT at small scale on outside literature; PROPOSED at architectural scale (gated by A2 no-go and holding power)"',
         '"note": "PROPOSED-INCOMPLETE (owner decision 2026-10-18, PROOFREAD_AUDIT.md section 3; MSL-ADD-01 section 3 row Earth stasis / siphon): no prior ledger status existed (old_status OPEN; the earlier CONSISTENT was unsourced); the claim has no number and no falsifier; the E4 null stands as the bar for its one prior form; not queued until R17 admission is met"'),
    ])
    bl.save()

if MARK in rd(BL):
    print("Phase A already applied (marker present in build_ledger.py); continuing")
    _t = rd(BL)
    assert '"T03-003": ("DERIVATION", "INCONSISTENT"' in _t and 'MSL-ADD-01 section 3 row A3-weak' in _t and 'row Earth stasis / siphon' in _t
    # before-hash from the package manifest written before this run (uppercase hex there)
    _m = {l.split()[1]: l.split()[0].lower() for l in rd(os.path.join(REV, "MANIFEST.sha256")).splitlines() if "  " in l}
    LOG["files"]["argon_reevaluation/scripts/build_ledger.py"] = {
        "sha256_before": _m.get("argon_reevaluation/scripts/build_ledger.py", "unknown"), "sha256_after": sha(BL),
        "edits": ["ARGON_DIR -> revision/argon_reevaluation (D12)", "T03-003 -> INCONSISTENT (V3)", "AXIOM-A3-WEAK -> PROPOSED (SELF)",
                  "OWN-STASIS -> PROPOSED-INCOMPLETE (old_status OPEN, ground NO-PREDICTION, clearing_test NONE, missing_item set)"]}
else:
    phase_a()

# ----------------------------------------------------------------------------------------------------------------
# Phase B — regenerate the ledger and the metrics with Argon's builder
# ----------------------------------------------------------------------------------------------------------------
print(run_argon(BL).strip().splitlines()[0])
metrics = json.load(open(os.path.join(ARG, "outputs", "reevaluation_metrics.json"), encoding="utf-8"))
rows = list(csv.DictReader(io.open(os.path.join(ARG, "claims_ledger_regraded.csv"), encoding="utf-8", newline="")))
mA, mS, mE = metrics["all_95_rows"], metrics["sph01_56_rows"], metrics["extra_39_rows"]
NC, NS, NE = mA["new_status_counts"], mS["new_status_counts"], mE["new_status_counts"]
assert len(rows) == 95 and mA["total_rows"] == 95
assert NC == {"SUPPORTED": 19, "CONTRADICTED": 4, "INCONSISTENT": 17, "PRIOR-CONSISTENT": 17, "PRIOR-CONSTRAINED": 26,
              "PROPOSED": 4, "PROPOSED-INCOMPLETE": 4, "ALLEGORY": 4}, NC
assert (mA["changed_count"], mA["unchanged_count"]) == (52, 43), (mA["changed_count"], mA["unchanged_count"])
byid = {r_["claim_id"]: r_ for r_ in rows}
assert byid["T03-003"]["new_status"] == "INCONSISTENT" and byid["AXIOM-A3-WEAK"]["new_status"] == "PROPOSED"
assert byid["OWN-STASIS"]["new_status"] == "PROPOSED-INCOMPLETE" and byid["OWN-STASIS"]["old_status"] == "OPEN"
for cid in ["BGCDR-02", "OCBP-01", "OCBP-03", "OCBP-04", "OCBP-05", "OCBP-06", "ARGON-SELF-06"]:
    assert byid[cid]["old_status"] == "CONSISTENT" and byid[cid]["new_status"] == "PRIOR-CONSISTENT", cid
LOG["metrics_after"] = {"all": NC, "sph01": NS, "extended": NE, "changed": mA["changed_count"], "unchanged": mA["unchanged_count"],
                        "transitions": mA["transitions"]}

# ----------------------------------------------------------------------------------------------------------------
# Phase C — generate_report_and_manifest.py
# ----------------------------------------------------------------------------------------------------------------
GR = os.path.join(HERE, "generate_report_and_manifest.py")
def phase_c():
    gr = Doc(GR)
    gr.rep("import os\nimport csv\nimport json\nimport hashlib\n",
           "import os\nimport sys\nimport csv\nimport json\nimport hashlib\n" + MARK + "\n")
    gr.rep('ARGON_DIR = r"C:\\LuxAura\\study\\extrapolation_XTR01\\ARGON"',
           'ARGON_DIR = r"C:\\LuxAura\\study\\revision\\argon_reevaluation"  # re-pointed 2026-10-18 (D12)')
    gr.rep('    f.write("# SHA-256 MANIFEST — C:\\\\LuxAura\\\\study\\\\extrapolation_XTR01\\\\ARGON\\\\\\n")',
           '    f.write("# SHA-256 MANIFEST — C:\\\\LuxAura\\\\study\\\\revision\\\\argon_reevaluation\\\\\\n")')
    # §1.2 + ground/changed lines: computed from the metrics instead of hard-coded (R16)
    OLD_MATRIX = """| `CONSISTENT` | 18 `[10]` | 0 | 20 `[17]` | 0 | 0 | 0 | 0 | 0 | **38** `[27]` |
    | `INCONSISTENT` | 0 | 21 `[10]` | 0 | 16 `[14]` | 1 `[1]` | 0 | 1 `[0]` | 0 | **39** `[25]` |
    | `CONTRADICTED` | 0 | 4 `[0]` | 0 | 0 | 3 `[0]` | 0 | 0 | 0 | **7** `[0]` |
    | `UNTESTABLE-AS-WRITTEN` | 0 | 0 | 0 | 0 | 0 | 0 | 1 `[1]` | 2 `[2]` | **3** `[3]` |
    | `PARTIAL` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 `[1]` | **1** `[1]` |
    | `OPEN` | 1 `[0]` | 0 | 0 | 0 | 0 | 1 `[0]` | 0 | 0 | **2** `[0]` |
    | `HYPOTHESIS` | 0 | 0 | 0 | 0 | 0 | 2 `[0]` | 0 | 0 | **2** `[0]` |
    | `DATA_GAP` | 0 | 0 | 0 | 0 | 0 | 0 | 1 `[0]` | 0 | **1** `[0]` |
    | `ANALOGY-ONLY` | 0 | 1 `[0]` | 0 | 0 | 0 | 0 | 0 | 0 | **1** `[0]` |
    | `ALLEGORY` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 `[0]` | **1** `[0]` |
    | **Column Total** | **19** `[10]` | **26** `[10]` | **20** `[17]` | **16** `[14]` | **4** `[1]` | **3** `[0]` | **3** `[1]` | **4** `[3]` | **95** `[56]` |
    """
    gr.rep(OLD_MATRIX, '""" + sec12_matrix + r"""\n')
    gr.rep("""- **Ground breakdown (`95` rows):** `OUTSIDE-DATA` = **43** (`20` in `SPH-01`), `INTERNAL-ARITHMETIC` = **20** (`18` in `SPH-01`), `DERIVATION` = **17** (`12` in `SPH-01`), `NO-PREDICTION` = **10** (`4` in `SPH-01`), `OWN-TEST` = **5** (`2` in `SPH-01`).
    - **Changed vs. Unchanged:** **51** rows changed status (`21` in `SPH-01` + `30` extended); **44** rows did not change (`35` in `SPH-01` + `9` extended).
    """, '""" + sec12_lines + r"""\n')
    MATRIX_CODE = '''
    # --- computed from reevaluation_metrics.json (REV-C, R16: prose equals COMMAND) ---
    OLD_ORDER = ["CONSISTENT", "INCONSISTENT", "CONTRADICTED", "UNTESTABLE-AS-WRITTEN", "PARTIAL", "OPEN", "HYPOTHESIS", "DATA_GAP", "ANALOGY-ONLY", "ALLEGORY"]
    NEW_ORDER = ["PRIOR-CONSISTENT", "PRIOR-CONSTRAINED", "SUPPORTED", "INCONSISTENT", "CONTRADICTED", "PROPOSED", "PROPOSED-INCOMPLETE", "ALLEGORY"]
    def _cell(a, s): return f"{a} `[{s}]`" if a else "0"
    _ta, _ts = m_all["transitions"], m_sph["transitions"]
    _mrows = []
    for _o in OLD_ORDER:
        _cells = [_cell(_ta.get(f"{_o} -> {_n}", 0), _ts.get(f"{_o} -> {_n}", 0)) for _n in NEW_ORDER]
        _ra = sum(_ta.get(f"{_o} -> {_n}", 0) for _n in NEW_ORDER); _rs = sum(_ts.get(f"{_o} -> {_n}", 0) for _n in NEW_ORDER)
        _mrows.append(f"| `{_o}` | " + " | ".join(_cells) + f" | **{_ra}** `[{_rs}]` |")
    _mrows.append("| **Column Total** | " + " | ".join(f"**{m_all['new_status_counts'].get(_n, 0)}** `[{m_sph['new_status_counts'].get(_n, 0)}]`" for _n in NEW_ORDER)
                  + f" | **{m_all['total_rows']}** `[{m_sph['total_rows']}]` |")
    sec12_matrix = "\\n".join(_mrows)
    _g = ["OUTSIDE-DATA", "INTERNAL-ARITHMETIC", "DERIVATION", "NO-PREDICTION", "OWN-TEST"]
    sec12_lines = ("- **Ground breakdown (`95` rows):** " + ", ".join(f"`{_k}` = **{m_all['ground_counts'].get(_k, 0)}** (`{m_sph['ground_counts'].get(_k, 0)}` in `SPH-01`)" for _k in _g) + ".\\n"
                   + f"- **Changed vs. Unchanged:** **{m_all['changed_count']}** rows changed status (`{m_sph['changed_count']}` in `SPH-01` + `{m_ext['changed_count']}` extended); "
                   + f"**{m_all['unchanged_count']}** rows did not change (`{m_sph['unchanged_count']}` in `SPH-01` + `{m_ext['unchanged_count']}` extended).")

    '''
    gr.rep('\nreport_md = sec1_table + r"""', MATRIX_CODE + 'report_md = sec1_table + r"""')
    # Rev C note in the header (inside the f-string: no braces in this text)
    gr.rep("\n\n---\n\n## 1. Status Counts, Transition Matrix & Reference Rows",
           "\n\n**Rev C (2026-10-18, proofread `REVISION-PROOFREAD-01` §3, owner decision 08:20 EDT):** three rows re-graded at the source (`scripts/build_ledger.py`) and every count regenerated by `COMMAND`: `AXIOM-A3-WEAK` `PRIOR-CONSISTENT` → `PROPOSED` (`SELF`); `OWN-STASIS` `PRIOR-CONSISTENT` → `PROPOSED-INCOMPLETE`; `T03-003` `SUPPORTED` → `INCONSISTENT` (own FDTD against the analytic gradient, `V3`). Change log: `outputs/ledger_decisions_changes.json`.\n\n---\n\n## 1. Status Counts, Transition Matrix & Reference Rows")
    # §2
    gr.rep("## 2. Claims That Changed Status (`51` Rows)", "## 2. Claims That Changed Status (`52` Rows)")
    gr.rep("### B. `CONSISTENT` or `OPEN` $\\to$ `PRIOR-CONSISTENT` on `OUTSIDE-DATA` (`19` Rows)",
           "### B. `CONSISTENT` $\\to$ `PRIOR-CONSISTENT` on `OUTSIDE-DATA` (`17` Rows)")
    gr.rep("37–45. **`AXIOM-A3-WEAK`, `OWN-STASIS`, `BGCDR-02`, `OCBP-01`, `OCBP-03`, `OCBP-04`, `OCBP-05`, `OCBP-06`, `ARGON-SELF-06` (`SELF`)**: Re-graded from `OPEN`/`CONSISTENT` to `PRIOR-CONSISTENT` because each rests on outside seismological, acoustic-levitation, Piezo1,",
           "37–43. **`BGCDR-02`, `OCBP-01`, `OCBP-03`, `OCBP-04`, `OCBP-05`, `OCBP-06`, `ARGON-SELF-06` (`SELF`)**: Re-graded from `CONSISTENT` to `PRIOR-CONSISTENT` because each rests on outside seismological, Piezo1,")
    gr.rep("### C. Moves to `PROPOSED` (`3` Rows) and `PROPOSED-INCOMPLETE` (`3` Rows)",
           "### C. Moves to `PROPOSED` (`4` Rows) and `PROPOSED-INCOMPLETE` (`4` Rows)")
    gr.rep("46. **`AXIOM-A2-FIELD`**", "44. **`AXIOM-A2-FIELD`**")
    gr.rep("47. **`BGCDR-04`**", "45. **`BGCDR-04`**")
    gr.rep("48. **`BGCDR-05`**: Re-graded from `HYPOTHESIS` to `PROPOSED` under `R17` because $432/528\\text{ Hz}$ cellular selectivity has not been tested by an in-program blinded multi-frequency assay (`NEW-T19`).",
           "46. **`BGCDR-05`**: Re-graded from `HYPOTHESIS` to `PROPOSED` under `R17` because $432/528\\text{ Hz}$ cellular selectivity has not been tested by an in-program blinded multi-frequency assay (`NEW-T19`).\n"
           "47. **`AXIOM-A3-WEAK`** (`SELF`): Re-graded from `OPEN` to `PROPOSED` under `R17`–`R18` (owner decision 2026-10-18, `PROOFREAD_AUDIT.md` §3; `MANDATE_ADDENDUM_XTR.md` §3 row *A3-weak*) because the outside seismology bar (LLSVP/ULVZ heterogeneity; Garnero & McNamara 2008 `[OC-015]`, Ishii & Dziewonski 2002 `[OC-018]`, *(not re-fetched)*) confirms unmapped deep-Earth structure, not the lens's content (interfacial fraction controlling acoustic/hydraulic behaviour and the `E4-Mm` band), which has no own test; the bar is kept as context, cleared by `T-4` and an `E4-Mm` poroelastic refit on the program's own pipeline.")
    gr.rep("49. **`T02-004`**", "48. **`T02-004`**")
    gr.rep("50. **`XTR-B1-AE`**", "49. **`XTR-B1-AE`**")
    gr.rep("51. **`XTR-B2-PASS2`**", "50. **`XTR-B2-PASS2`**")
    gr.rep("recovery curves (`T-9`).\n\n---\n\n## 3. Claims That Did Not Change Status (`44` Rows)",
           "recovery curves (`T-9`).\n"
           "51. **`OWN-STASIS`**: Re-graded from `OPEN` (no prior ledger status existed; the earlier `CONSISTENT` was unsourced) to `PROPOSED-INCOMPLETE` under `R17` (owner decision 2026-10-18, `PROOFREAD_AUDIT.md` §3; `MANDATE_ADDENDUM_XTR.md` §3 row *Earth stasis / siphon*) because the claim has no number and no falsifier; mm-scale acoustic levitation is not a bar for an Earth-scale claim and is kept as context only; the `E4` null stands as the bar for its one prior form; `missing_item`: a prediction with a unit and a falsifier, before any test is queued.\n\n"
           "### D. `CONSISTENT` $\\to$ `INCONSISTENT` on Own Data (`1` Row)\n"
           "52. **`T03-003`**: Re-graded from `CONSISTENT` to `INCONSISTENT` (internal, own data against own data; owner decision 2026-10-18, `PROOFREAD_AUDIT.md` §3) because the analytic wall pressure gradient $k P_{\\text{anti}} = 0.6283 \\times 2500 = 1{,}570.80\\text{ Pa/m}$ disagrees with the program's own FDTD run ($1.74\\text{ Pa/m}$), which was not run to steady state (`DEFERRALS_v2.md` `V3`); $\\delta_{\\text{bl,eff}} = 0.552\\text{ mm}$ and $Q_{\\text{bl}} = 1941.1$ stand as `DERIVATION`; cleared by `V3` (steady-state run $\\ge Q/\\pi \\approx 618$ cycles with impedance boundary; falsifier `H-V3`: reproduces within $10\\%$).\n\n---\n\n## 3. Claims That Did Not Change Status (`43` Rows)")
    # §3
    gr.rep("### B. `DERIVATION` (`15` Rows: `2` `CONTRADICTED`, `1` `INCONSISTENT`, `12` `SUPPORTED`)",
           "### B. `DERIVATION` (`14` Rows: `2` `CONTRADICTED`, `1` `INCONSISTENT`, `11` `SUPPORTED`)")
    gr.rep("9–20. **`T01-006`, `T01-007`, `T03-002`, `T03-003`, `T05-002`,", "9–19. **`T01-006`, `T01-007`, `T03-002`, `T05-002`,")
    gr.rep("`T03-003` Stokes–Kirchhoff $Q_{\\text{bl}}=1941.1$; ", "")
    for o, n in [("21–24. **`T01-009`", "20–23. **`T01-009`"), ("25–26. **`T01-008`", "24–25. **`T01-008`"), ("27. **`T02-008`", "26. **`T02-008`"),
                 ("28–31. **`M01-003`", "27–30. **`M01-003`"), ("32–33. **`SDT-001`", "31–32. **`SDT-001`"), ("34–35. **`VPDR-01`", "33–34. **`VPDR-01`"),
                 ("36–40. **`T02-001`", "35–39. **`T02-001`"), ("41–44. **`A02-002`", "40–43. **`A02-002`")]:
        gr.rep(o, n)
    # §5 test queue: T-5 loses OWN-STASIS; V3 enters as a zero-cost desk item; ranks renumbered
    gr.rep("`A04-001`, `OWN-STASIS` | 6 | **0.60** |", "`A04-001` | 5 | **0.50** |")
    V3_ROW = ("| **6** | **`V3`** | Steady-state re-run of `sim_cavity_acoustics.py` ($\\ge Q/\\pi \\approx 618$ cycles at $34.40\\text{ Hz}$, impedance boundary) to reconcile the analytic wall gradient $1,570.80\\text{ Pa/m}$ with the FDTD $1.74\\text{ Pa/m}$ (`DEFERRALS_v2.md` `V3`; falsifier `H-V3`: within $10\\%$) | \\$0 | 0.5 | `T03-003` | 1 | **2.00** |")
    gr.rep("`T04-002` | 1 | **2.00** |\n", "`T04-002` | 1 | **2.00** |\n@@V3@@\n")
    gr.sub(r"^\| \*\*(\d+)\*\* \| ", lambda m: f"| **{int(m.group(1)) + 1}** | ", "@@V3@@", "> **Immediate zero-cost desk queue")
    gr.rep("@@V3@@", V3_ROW)
    gr.rep("(`$0`, `3.0` days total):** Running **`T-3` $\\to$ `T-2` $\\to$ `T-9` $\\to$ `T-8` $\\to$ `NEW-T12`** requires zero hardware and transitions **9** `PRIOR-CONSTRAINED` / `PROPOSED-INCOMPLETE` claims (`OWN-FIB`, `SMR-001..002`, `XTR-B2-PASS2`, `OCBP-01`, `XTR-B1-AE`, `XTR-B1-COMCAT`, `T04-002`) into",
           "(`$0`, `3.5` days total):** Running **`T-3` $\\to$ `T-2` $\\to$ `T-9` $\\to$ `T-8` $\\to$ `NEW-T12` $\\to$ `V3`** requires zero hardware and transitions **10** `PRIOR-CONSTRAINED` / `PROPOSED-INCOMPLETE` / `INCONSISTENT` claims (`OWN-FIB`, `SMR-001..002`, `XTR-B2-PASS2`, `OCBP-01`, `XTR-B1-AE`, `XTR-B1-COMCAT`, `T04-002`, `T03-003`) into")
    # --manifest-only
    gr.rep('report_path = os.path.join(ARGON_DIR, "ARGON_REEVALUATION.md")\nwith open(report_path, "w", encoding="utf-8") as f:\n    f.write(report_md)\n',
           'report_path = os.path.join(ARGON_DIR, "ARGON_REEVALUATION.md")\nif "--manifest-only" not in sys.argv:  # REV-C: re-hash after proofread link fixes without rewriting the report\n    with open(report_path, "w", encoding="utf-8") as f:\n        f.write(report_md)\n')
    gr.save()

if MARK in rd(GR):
    print("Phase C already applied (marker present in generate_report_and_manifest.py); verifying")
    gr = Doc(GR)
    if "| **6** | **`T-4` (`E5`)**" in gr.text:   # rank hotfix for the first-run placeholder bug
        gr.rep("| **6** | **`T-4` (`E5`)**", "| **7** | **`T-4` (`E5`)**"); gr.save()
    for must in ["sec12_matrix", "52. **`T03-003`**", "| **6** | **`V3`**", "| **7** | **`T-4` (`E5`)**", "| **20** | **`NEW-T17`**", "--manifest-only"]:
        assert must in rd(GR), "generator lacks: " + must
else:
    phase_c()
print(run_argon(GR).strip().splitlines()[0])
rep_txt = rd(os.path.join(ARG, "ARGON_REEVALUATION.md"))
for must in ["| `CONSISTENT` | 17 `[10]` | 0 | 19 `[16]` | 1 `[1]` |", "| `OPEN` | 0 | 0 | 0 | 0 | 0 | 2 `[0]` | 1 `[0]` | 0 | **3** `[0]` |",
             "**52** rows changed status (`22` in `SPH-01` + `30` extended); **43** rows did not change (`34` in `SPH-01` + `9` extended)",
             "52. **`T03-003`**", "| **7** | **`T-4` (`E5`)**", "| **20** | **`NEW-T17`**"]:
    assert must in rep_txt, "regenerated report lacks: " + must

# ----------------------------------------------------------------------------------------------------------------
# Phase D — FINAL_MASTER_ANALYSIS_ARGON_REVISION.md ×3: §5 rebuilt from the CSV/metrics; §2 item 3 aligned
# ----------------------------------------------------------------------------------------------------------------
def pct(n): return f"{100.0 * n / 95:.2f}%"
RULES = {
 "SUPPORTED": "`R18`: Verified by `OWN-TEST` (`ComCat` $b=1.2532$) or zero-outside-data `DERIVATION` / `COMMAND`",
 "CONTRADICTED": "`R18`: Refuted by `OWN-TEST` (`E4` synodic null) or internal conservation-law no-go (`DERIVATION`)",
 "INCONSISTENT": "`R18`: Internal arithmetic, dimensional, or parameter self-contradiction (`INTERNAL-ARITHMETIC`), including own data against own data (`T03-003`, pending `V3`)",
 "PRIOR-CONSISTENT": "`R17`: Consistent with external published literature (`EXTERNAL-LITERATURE`), no own test run",
 "PRIOR-CONSTRAINED": "`R17`: Constrained by external published bars (`value ± uncertainty, source, medium`)",
 "PROPOSED": "`R17`–`R19`: Admitted with a prediction and a falsifier, untested by own data; paired tests `T-4` (+ `E4-Mm` refit), `T-5`/`E1`, `NEW-T18`, `NEW-T19`",
 "PROPOSED-INCOMPLETE": "`R17`: Missing input named in `missing_item` (a derivation or bench value, a calibrated catalog, digitised curves; `OWN-STASIS`: a prediction with a unit and a falsifier before any test is queued)",
 "ALLEGORY": "`R1`/`R9`: Symbolic operator ($\\Psi_g, \\Xi_{23D}, P_{\\text{bs}}$) or cross-domain structural metaphor",
}
ORDER = ["SUPPORTED", "CONTRADICTED", "INCONSISTENT", "PRIOR-CONSISTENT", "PRIOR-CONSTRAINED", "PROPOSED", "PROPOSED-INCOMPLETE", "ALLEGORY"]
def row_md(r_):
    bar_v = r_["bar_value"].replace("|", "\\|") if r_["bar_value"] else "—"
    ct = f"`{r_['clearing_test']}`" if r_["clearing_test"] and r_["clearing_test"] != "NONE" else "—"
    changed = (r_["old_status"] != r_["new_status"])
    new_s = f"**`{r_['new_status']}`**" if changed else f"`{r_['new_status']}`"
    return f"| `{r_['claim_id']}` | `{r_['source_file']}` | `{r_['old_status']}` | `{r_['ground_of_old_status']}` | {new_s} | {bar_v} | {ct} | {r_['note'].replace('|', chr(92) + '|')} |"
sec5 = ["### 5.1 Aggregate Verdict Distribution & Transition Summary (`COMMAND`)", "",
        "| Revised Edition Verdict (`new_status`) | `SPH-01` Core (`56`) | Extended Corpus (`39`: Axioms, Owner Statements, `XTR-01` Bridges, Sub-Reports, `SELF`) | Combined Corpus (`95`) | Share (`%`) | Governing `MSL-ADD-01` Rule |",
        "| :--- | :---: | :---: | :---: | :---: | :--- |"]
for s in ORDER:
    sec5.append(f"| **`{s}`** | {NS.get(s, 0)} | {NE.get(s, 0)} | **{NC.get(s, 0)}** | `{pct(NC.get(s, 0))}` | {RULES[s]} |")
sec5.append(f"| **TOTAL** | **56** | **39** | **95** | **`100.00%`** | **`{mA['changed_count']}` rows changed status (`{100.0 * mA['changed_count'] / 95:.1f}%`); `{mA['unchanged_count']}` rows held steady (`{100.0 * mA['unchanged_count'] / 95:.1f}%`)** |")
sec5 += ["", "### 5.2 Complete 56-Row `SPH-01` Re-Graded Ledger Table", "",
         "| Claim ID | Source File:Line | Old Verdict (`SPH-01`) | Ground of Old Verdict | New Verdict (`MSL-ADD-01`) | External Bar / Computed Value | Clearing Test | Note |",
         "| :--- | :--- | :---: | :---: | :---: | :--- | :---: | :--- |"]
sec5 += [row_md(r_) for r_ in rows[:56]]
sec5 += ["", "### 5.3 Complete 39-Row Extended Re-Graded Ledger Table (Axioms `A1`–`A4`, Owner Statements, `XTR-01` Bridges, Sub-Reports, Argon `SELF`)", "",
         "| Claim ID | Source File:Line | Old Verdict | Ground | New Verdict (`MSL-ADD-01`) | External Bar / Computed Value | Clearing Test | Note |",
         "| :--- | :--- | :---: | :---: | :---: | :--- | :---: | :--- |"]
sec5 += [row_md(r_) for r_ in rows[56:]]
SEC5 = "\n".join(sec5) + "\n\n---\n\n"

L92_OLD = "3. **Cavity Eigenmodes, FDTD Ring-Up & Barabar Caves (`SUPPORTED` / `PROPOSED-INCOMPLETE`):** Cavity fundamental $f_{100} = 34.40\\text{ Hz}$, $Q = 1,941.3$, $\\delta_{\\text{bl}} = 0.552\\text{ mm}$, steady-state gradient $1,570.80\\text{ Pa/m}$, 20-cycle FDTD ring-up ($3.185\\%$ amplitude), and the 6 degenerate mode pairs ($L_x = 2L_z$) are **`SUPPORTED`** (`COMMAND`). Unmeasured Barabar cave dimensions (`T03-004`) and assumed $E_{s,\\text{cav}} = 35\\text{ MJ/m}^3$ (`T02-004`) are graded **`PROPOSED-INCOMPLETE`** (paired with `T-9` and `T-2`)."
L92_NEW = "3. **Cavity Eigenmodes, FDTD Ring-Up & Barabar Caves (`SUPPORTED` / `INCONSISTENT` / `PRIOR-CONSTRAINED` / `PROPOSED-INCOMPLETE`):** Cavity fundamental $f_{100} = 34.40\\text{ Hz}$, $Q = 1,941.3$, $\\delta_{\\text{bl}} = 0.552\\text{ mm}$, 20-cycle FDTD ring-up ($3.185\\%$ amplitude), and the 6 degenerate mode pairs ($L_x = 2L_z$) are **`SUPPORTED`** (`COMMAND`). The analytic wall gradient $k P_{\\text{anti}} = 1,570.80\\text{ Pa/m}$ is **`INCONSISTENT`** with the program's own unconverged FDTD ($1.74\\text{ Pa/m}$) until `V3` is run to steady state (`T03-003`). Barabar polish $R_a$ (`T03-004`) is **`PRIOR-CONSTRAINED`** on the archaeometric bar (`NEW-T11`), and the assumed $E_{s,\\text{cav}} = 35\\text{ MJ/m}^3$ (`T02-004`) is **`PROPOSED-INCOMPLETE`** (`NEW-T10`)."

old_rows = None
for sub in ["", "root_revision_docs", "for_root"]:
    p = os.path.join(REV, sub, "FINAL_MASTER_ANALYSIS_ARGON_REVISION.md")
    d = Doc(p)
    a = d.text.index("### 5.1 Aggregate Verdict Distribution"); b = d.text.index("## 6. Binding Superseded")
    seg = d.text[a:b]
    old_set = {l for l in seg.splitlines() if l.startswith("| `")}
    if old_rows is None: old_rows = old_set
    assert old_set == old_rows, "ledger tables differ between copies: " + sub
    d.text = d.text[:a] + (SEC5.replace("\n", "\r\n") if d.crlf else SEC5) + d.text[b:]
    d.edits.append({"old": "§5.1–§5.3 (hard-coded split; 87/8 rows)", "new": "§5.1 from metrics; §5.2/§5.3 from CSV (56/39)"})
    d.rep(L92_OLD, L92_NEW)
    d.save()
new_set = {l for l in SEC5.splitlines() if l.startswith("| `")}
diff_ids = sorted({re.match(r"\| `([^`]+)`", l).group(1) for l in (old_rows ^ new_set)})
assert diff_ids == ["AXIOM-A3-WEAK", "OWN-STASIS", "T03-003"], diff_ids
LOG["fma_argon_rows_changed"] = diff_ids

# gen_argon_master_revision.py: same partition and headings; §5.1 numbers; §2 item 3
g = Doc(os.path.join(HERE, "gen_argon_master_revision.py"), py=True)
g.rep('sph_rows = [r for r in rows if not r["claim_id"].startswith("XTR-")]\nxtr_rows = [r for r in rows if r["claim_id"].startswith("XTR-")]',
      'sph_rows = rows[:56]   # REV-C: the 56 SPH-01 claims are the first 56 rows (matches reevaluation_metrics.json)\nxtr_rows = rows[56:]   # REV-C: the 39 extended rows (axioms, owner statements, XTR-01 bridges, sub-reports, SELF)')
g.rep('a("| Revised Edition Verdict (`new_status`) | `SPH-01` Core (`56`) | `XTR-01` Extrapolation (`39`) | Combined Corpus (`95`) | Share (`%`) | Governing `MSL-ADD-01` Rule |")',
      'a("| Revised Edition Verdict (`new_status`) | `SPH-01` Core (`56`) | Extended Corpus (`39`: Axioms, Owner Statements, `XTR-01` Bridges, Sub-Reports, `SELF`) | Combined Corpus (`95`) | Share (`%`) | Governing `MSL-ADD-01` Rule |")')
OLD51 = [
 'a("| **`SUPPORTED`** | 16 | 4 | **20** | `21.05%` | `R18`: Verified by `OWN-TEST` (`ComCat` $b=1.2532$) or zero-outside-data `DERIVATION` / `COMMAND` |")',
 'a("| **`CONTRADICTED`** | 2 | 2 | **4** | `4.21%` | `R18`: Refuted by `OWN-TEST` (`E4` synodic null) or internal conservation-law no-go (`DERIVATION`) |")',
 'a("| **`INCONSISTENT`** | 15 | 1 | **16** | `16.84%` | `R18`: Internal arithmetic, dimensional, or parameter self-contradiction (`INTERNAL-ARITHMETIC`) |")',
 'a("| **`PRIOR-CONSISTENT`** | 11 | 8 | **19** | `20.00%` | `R17`: Consistent with external published literature (`EXTERNAL-LITERATURE`), no own test run |")',
 'a("| **`PRIOR-CONSTRAINED`** | 7 | 19 | **26** | `27.37%` | `R17`: Constrained by external published bars (`value ± uncertainty, source, medium`) |")',
 'a("| **`PROPOSED`** | 0 | 3 | **3** | `3.16%` | `R18`/`R19`: Testable hypothesis with stated falsifiers and paired test (`T-1`, `T-3`, `T-5`/`E1`) |")',
 'a("| **`PROPOSED-INCOMPLETE`** | 1 | 2 | **3** | `3.16%` | `R18`/`R19`: Missing internal parameter or unmeasured cave/core input (`T-2`, `T-9`) |")',
 'a("| **`ALLEGORY`** | 4 | 0 | **4** | `4.21%` | `R1`/`R9`: Symbolic operator ($\\Psi_g, \\Xi_{23D}, P_{\\text{bs}}$) or cross-domain structural metaphor |")',
 'a("| **TOTAL** | **56** | **39** | **95** | **`100.00%`** | **`51` rows changed status (`53.7%`); `44` rows held steady (`46.3%`)** |")',
]
new51 = [f'a("{l}")' for l in sec5[4:13]]
assert len(OLD51) == len(new51) == 9
for o, n in zip(OLD51, new51):
    # the .py keeps doubled backslashes; Doc.rep tries both spellings for the anchor, and doubles the new text when the doubled anchor matched
    g.rep(o, n)
g.rep('a("### 5.3 Complete 39-Row `XTR-01` Re-Graded Extrapolation Ledger Table")',
      'a("### 5.3 Complete 39-Row Extended Re-Graded Ledger Table (Axioms `A1`–`A4`, Owner Statements, `XTR-01` Bridges, Sub-Reports, Argon `SELF`)")')
g.rep(L92_OLD, L92_NEW)
g.save()

# ----------------------------------------------------------------------------------------------------------------
# Phase E — count strings in the other documents (all copies) and in their generators
# ----------------------------------------------------------------------------------------------------------------
C16_OLD = "`44` rows (`46.3%`) hold their exact verdict (`20 SUPPORTED`, `4 CONTRADICTED`, `16 INCONSISTENT`, `4 ALLEGORY`) and `51` rows (`53.7%`) shift from external verdicts to `PRIOR-CONSTRAINED` (`26`), `PRIOR-CONSISTENT` (`19`), `PROPOSED` (`3`), or `PROPOSED-INCOMPLETE` (`3`).**"
C16_NEW = "`43` rows (`45.3%`) keep their first-edition verdict and `52` rows (`54.7%`) change under `R17`–`R19`. By revised status: `19 SUPPORTED`, `4 CONTRADICTED`, `17 INCONSISTENT`, `4 ALLEGORY` rest on our own data and derivations (one of them, `T03-003`, moved from `CONSISTENT` to `INCONSISTENT` on our own FDTD), and `26 PRIOR-CONSTRAINED`, `17 PRIOR-CONSISTENT`, `4 PROPOSED`, `4 PROPOSED-INCOMPLETE` record outside bars and admissions.**"
C51_OLD = "All 16 claims of the Credible Engineering Core (plus 4 self-contained derivations/tests across `SPH-01` and `XTR-01`, totaling **20 `SUPPORTED` rows**) hold by our own scripts and algebra:"
C51_NEW = "The Credible Engineering Core and the self-contained derivations/tests across `SPH-01` and `XTR-01` (**19 `SUPPORTED` rows**; the cavity wall gradient in `T03-003` is `INCONSISTENT` pending `V3`) hold by our own scripts and algebra:"
C58_OLD = "$\\delta_{\\text{bl}} = 0.552\\text{ mm}$, $1,570.80\\text{ Pa/m}$, 6 degenerate pairs $<160\\text{ Hz}$ | **`SUPPORTED`** | Barabar $R_a \\approx 0.1\\text{–}2.0\\ \\mu\\text{m}$ is `PRIOR-CONSISTENT` (archaeometry) / `PROPOSED-INCOMPLETE` for unmeasured cave dimensions (`T-9`). |"
C58_NEW = "$\\delta_{\\text{bl}} = 0.552\\text{ mm}$, 6 degenerate pairs $<160\\text{ Hz}$ | **`SUPPORTED`** | Analytic wall gradient $1,570.80\\text{ Pa/m}$ is `INCONSISTENT` with our own unconverged FDTD ($1.74\\text{ Pa/m}$) until `V3` runs to steady state (`T03-003`). Barabar polish $R_a$ (`T03-004`) is `PRIOR-CONSTRAINED` on the archaeometric bar, cleared by `NEW-T11`. |"
C88_OLD = "- **`SUPPORTED` (`20` Claims — Own Tests & Self-Contained Derivations):**"
C88_NEW = "- **`SUPPORTED` (`19` Claims — Own Tests & Self-Contained Derivations):**"
C91a_OLD = "  - **Self-Contained `DERIVATION` / `COMMAND` (`19`):**"
C91a_NEW = "  - **Self-Contained `DERIVATION` / `COMMAND` (`18`):**"
C91b_OLD = "$\\delta_{\\text{bl}} = 0.552\\text{ mm}$, $1,570.80\\text{ Pa/m}$, 6 degenerate pairs ·"
C91b_NEW = "$\\delta_{\\text{bl}} = 0.552\\text{ mm}$, 6 degenerate pairs (the wall gradient in `T03-003` is `INCONSISTENT` pending `V3`) ·"
C94_OLD = "- **`INCONSISTENT` (`16` Claims — Internal Arithmetic & Parameter Self-Contradictions):**"
C94_NEW = "- **`INCONSISTENT` (`17` Claims — Internal Arithmetic & Parameter Self-Contradictions):**"
C95_OLD = "· Eleven v1 table/formula self-contradictions fixed in `_v2.md`."
C95_NEW = "· Eleven v1 table/formula self-contradictions fixed in `_v2.md` · Analytic cavity wall gradient $1,570.80\\text{ Pa/m}$ vs. our own unconverged FDTD $1.74\\text{ Pa/m}$ (`T03-003`, pending `V3`)."
C96_OLD = "- **`PRIOR-CONSTRAINED` (`26` Claims) & `PRIOR-CONSISTENT` (`19` Claims):**"
C96_NEW = "- **`PRIOR-CONSTRAINED` (`26` Claims) & `PRIOR-CONSISTENT` (`17` Claims):**"
C98_OLD = "- **`PROPOSED` (`3` Claims) & `PROPOSED-INCOMPLETE` (`3` Claims):**"
C98_NEW = "- **`PROPOSED` (`4` Claims) & `PROPOSED-INCOMPLETE` (`4` Claims):**"
C99_OLD = "  - `A3-weak` Onion-Layer / Breathing-Crevice lens + `E4-Mm` poroelastic refit (`T-3`) · `A2` dynamic kHz strain–$g$ coupling (`E1` / `T-5`, $\\kappa_{\\text{req}} = 6.80\\times 10^{-4}$) · `L1`–`L3` slow-dynamics exponent bridge (`T-1`) · `T02-004` ($E_{s,\\text{cav}} = 35\\text{ MJ/m}^3 \\to \\text{T-2}$) · `T03-004` (Barabar impulse response $\\to \\text{T-9}$)."
C99_NEW = "  - `A3-weak` Onion-Layer / Breathing-Crevice lens (`AXIOM-A3-WEAK`, `SELF`; `T-4` + `E4-Mm` poroelastic refit on our own pipeline) · `A2` dynamic kHz strain–$g$ coupling (`AXIOM-A2-FIELD`; `E1` / `T-5`, $\\kappa_{\\text{req}} = 6.80\\times 10^{-4}$) · acoustic modulation of gene expression and $432/528\\text{ Hz}$ selectivity (`BGCDR-04`, `BGCDR-05`; `NEW-T18`, `NEW-T19`) · `T02-004` ($E_{s,\\text{cav}} = 35\\text{ MJ/m}^3$; `NEW-T10`) · laboratory AE catalog for `B1` (`XTR-B1-AE`; `T-8`) · `L3` memory-bridge placeholder timescales (`XTR-B2-PASS2`; `T-9`) · Earth \"stasis / siphon\" (`OWN-STASIS`; needs a prediction with a unit and a falsifier before it can be queued)."
FMA_REV_EDITS = [(C16_OLD, C16_NEW), (C51_OLD, C51_NEW), (C58_OLD, C58_NEW), (C88_OLD, C88_NEW), (C91a_OLD, C91a_NEW), (C91b_OLD, C91b_NEW),
                 (C94_OLD, C94_NEW), (C95_OLD, C95_NEW), (C96_OLD, C96_NEW), (C98_OLD, C98_NEW), (C99_OLD, C99_NEW)]

P27_OLD = "Re-graded all **95 corpus claims** (`56 SPH-01 + 39 XTR-01`): **`44` verdicts held steady** (`20 SUPPORTED`, `4 CONTRADICTED`, `16 INCONSISTENT`, `4 ALLEGORY`) and **`51` external comparisons** moved cleanly to `PRIOR-CONSTRAINED` (`26`), `PRIOR-CONSISTENT` (`19`), `PROPOSED` (`3`), or `PROPOSED-INCOMPLETE` (`3`). |"
P27_NEW = "Re-graded all **95 corpus claims** (`56 SPH-01 + 39 XTR-01`): **`43` verdicts held steady** and **`52` changed**. By revised status, `19 SUPPORTED`, `4 CONTRADICTED`, `17 INCONSISTENT`, `4 ALLEGORY` rest on our own data and derivations (one of them, `T03-003`, moved from `CONSISTENT` to `INCONSISTENT` on our own FDTD), and `26 PRIOR-CONSTRAINED`, `17 PRIOR-CONSISTENT`, `4 PROPOSED`, `4 PROPOSED-INCOMPLETE` record outside bars and admissions. |"
P53_OLD = "### 2.2 What Our Own Rules Caught and Falsified (`4 CONTRADICTED` + `16 INCONSISTENT`)"
P53_NEW = "### 2.2 What Our Own Rules Caught and Falsified (`4 CONTRADICTED` + `17 INCONSISTENT`)"
P60_OLD = "- **Sixteen `INCONSISTENT` Claims (Internal Arithmetic & Parameter Self-Contradictions):**"
P60_NEW = "- **Seventeen `INCONSISTENT` Claims (Internal Arithmetic & Parameter Self-Contradictions):**"
P61_OLD = "and the v1 table/prose discrepancies (`C1`, `C2`, `M2`, `M7`) now quarantined in the **Superseded Values Registry**."
P61_NEW = "the v1 table/prose discrepancies (`C1`, `C2`, `M2`, `M7`) now quarantined in the **Superseded Values Registry**, and the cavity wall gradient (analytic $1,570.80\\text{ Pa/m}$ against our own unconverged FDTD $1.74\\text{ Pa/m}$, `T03-003`, open until `V3` is run to steady state)."
P65_OLD = "## 3. Respecting Outside Bars Without Outsourcing Our Verdicts (`26 PRIOR-CONSTRAINED` + `19 PRIOR-CONSISTENT`)"
P65_NEW = "## 3. Respecting Outside Bars Without Outsourcing Our Verdicts (`26 PRIOR-CONSTRAINED` + `17 PRIOR-CONSISTENT`)"
PUB_EDITS = [(P27_OLD, P27_NEW), (P53_OLD, P53_NEW), (P60_OLD, P60_NEW), (P61_OLD, P61_NEW), (P65_OLD, P65_NEW)]

R34_OLD = "summarizes the 20 `SUPPORTED` truths"
R34_NEW = "summarizes the 19 `SUPPORTED` truths"
T28_OLD = "   - **§2:** The 20 `SUPPORTED` self-contained engineering & mathematical truths"
T28_NEW = "   - **§2:** The 19 `SUPPORTED` self-contained engineering & mathematical truths"
T28b_OLD = "and the 4 `CONTRADICTED` + 16 `INCONSISTENT` internal catches."
T28b_NEW = "and the 4 `CONTRADICTED` + 17 `INCONSISTENT` internal catches."
T29_OLD = "   - **§3:** Respecting outside bars (`26 PRIOR-CONSTRAINED`, `19 PRIOR-CONSISTENT`)"
T29_NEW = "   - **§3:** Respecting outside bars (`26 PRIOR-CONSTRAINED`, `17 PRIOR-CONSISTENT`)"
T75_OLD = "detailing what moved (`51` claims), what held steady (`44` claims), and why."
T75_NEW = "detailing what moved (`52` claims), what held steady (`43` claims), and why."
TOC_EDITS = [(T28_OLD, T28_NEW), (T28b_OLD, T28b_NEW), (T29_OLD, T29_NEW), (T75_OLD, T75_NEW)]

def apply(path, edits, py=False):
    d = Doc(path, py=py)
    for o, n in edits: d.rep(o, n)
    d.save()

for sub in ["", "root_revision_docs", "for_root"]:
    apply(os.path.join(REV, sub, "FINAL_MASTER_ANALYSIS_REVISION.md"), FMA_REV_EDITS)
    apply(os.path.join(REV, sub, "PUBLIC_REFLECTION_ARGON_REVISION.md"), PUB_EDITS)
    apply(os.path.join(REV, sub, "README_REVISION.md"), [(R34_OLD, R34_NEW)])
    apply(os.path.join(REV, sub, "TOC_REVISION.md"), TOC_EDITS)
apply(os.path.join(REV, "README.md"), [(R34_OLD, R34_NEW)])
apply(os.path.join(REV, "TOC.md"), TOC_EDITS)
apply(os.path.join(HERE, "gen_public_and_fma_revision.py"), FMA_REV_EDITS + PUB_EDITS)
apply(os.path.join(HERE, "gen_readme_and_toc_revision.py"), [(R34_OLD, R34_NEW)] + TOC_EDITS)

# ----------------------------------------------------------------------------------------------------------------
# Phase F — PROOFREAD_AUDIT.md and proofread_changes.json
# ----------------------------------------------------------------------------------------------------------------
au = Doc(os.path.join(REV, "PROOFREAD_AUDIT.md"))
au.rep("**Change log (machine-readable):** `argon_reevaluation/outputs/proofread_changes.json` · **Script:** `argon_reevaluation/scripts/proofread_fixes.py` (deterministic; re-runnable)",
       "**Change log (machine-readable):** `argon_reevaluation/outputs/proofread_changes.json` · **Script:** `argon_reevaluation/scripts/proofread_fixes.py` (deterministic; re-runnable)  \n"
       "**Rev B (2026-10-18, after the owner's 08:20 EDT decision \"Update the ledger rows\"):** the three §3 rows were applied at the source and every count regenerated by `COMMAND` (F7–F10; `argon_reevaluation/scripts/apply_ledger_decisions.py`, change log `argon_reevaluation/outputs/ledger_decisions_changes.json`).")
au.rep("| `claims_ledger_regraded.csv` | 95 rows, 13 columns as specified; 20 SUPPORTED, 4 CONTRADICTED, 16 INCONSISTENT, 19 PRIOR-CONSISTENT, 26 PRIOR-CONSTRAINED, 3 PROPOSED, 3 PROPOSED-INCOMPLETE, 4 ALLEGORY |",
       "| `claims_ledger_regraded.csv` | 95 rows, 13 columns as specified. As delivered: 20 SUPPORTED, 4 CONTRADICTED, 16 INCONSISTENT, 19 PRIOR-CONSISTENT, 26 PRIOR-CONSTRAINED, 3 PROPOSED, 3 PROPOSED-INCOMPLETE, 4 ALLEGORY. After the owner's decision (F7): 19 / 4 / 17 / 17 / 26 / 4 / 4 / 4; 52 rows changed status, 43 unchanged |")
au.rep("| F6 | Manifests stale after the above. | `MANIFEST.sha256` and `REVISION_MANIFEST.json` regenerated in Argon's format; proofread artifacts added. | `MANIFEST.sha256` (119 entries, 0 mismatches), `REVISION_MANIFEST.json` |",
       "| F6 | Manifests stale after the above. | `MANIFEST.sha256` and `REVISION_MANIFEST.json` regenerated in Argon's format; proofread artifacts added; re-run after F7–F10. | `MANIFEST.sha256` (@@N@@ entries, 0 mismatches), `REVISION_MANIFEST.json`, `argon_reevaluation/outputs/MANIFEST.sha256` |\n"
       "| F7 | The three §3 rows, adopted by the owner at 08:20 EDT. | `AXIOM-A3-WEAK` → PROPOSED (bar kept as context; `T-4` + `E4-Mm` refit; flagged `SELF`); `OWN-STASIS` → PROPOSED-INCOMPLETE (`old_status` OPEN, ground NO-PREDICTION, nothing queued until it has a number and a falsifier); `T03-003` → INCONSISTENT (own FDTD 1.74 Pa/m against the analytic 1,570.80 Pa/m; `V3` added to the test queue at \\$0). Applied in `build_ledger.py`, which was re-run; `generate_report_and_manifest.py` re-pointed to `revision/argon_reevaluation/` (D12), its §1.2 matrix and ground / changed-vs-unchanged lines now computed from the metrics (R16), its §2, §3 and §5 lists updated, and re-run; the new counts (19 SUPPORTED, 17 INCONSISTENT, 17 PRIOR-CONSISTENT, 4 PROPOSED, 4 PROPOSED-INCOMPLETE; 52 changed / 43 unchanged) propagated to every citing document and to the `gen_*.py` strings they came from. | `scripts/apply_ledger_decisions.py`; `outputs/ledger_decisions_changes.json`; all copies |\n"
       "| F8 | `FINAL_MASTER_ANALYSIS_ARGON_REVISION.md` §5.1 per-column split (16/4, 2/2, 15/1 …) matched no partition of the ledger, and §5.2 \"56-Row\" held 87 rows while §5.3 \"39-Row\" held 8 (the generator split on the `XTR-` prefix). | §5.1 computed from `reevaluation_metrics.json` (first 56 rows = `SPH-01`, last 39 = extended), §5.2/§5.3 rebuilt from the CSV with that partition, headings corrected; the three copies verified to differ from the delivered tables in exactly the three re-graded rows. `gen_argon_master_revision.py` patched the same way. | three copies |\n"
       "| F9 | Test IDs paired with claims in prose disagreed with the ledger's `clearing_test` column (`T02-004`→`T-2`, `T03-004`→`T-9`, `A3-weak`→`T-3`, `L1–L3`→`T-1`), and `T03-004` was called PROPOSED-INCOMPLETE where the ledger has PRIOR-CONSTRAINED. | Aligned with the ledger (`NEW-T10`, `NEW-T11`, `T-4`, `T-9`; the PROPOSED / PROPOSED-INCOMPLETE list now names the eight rows). | `FINAL_MASTER_ANALYSIS_ARGON_REVISION.md` §2 item 3; `FINAL_MASTER_ANALYSIS_REVISION.md` §3 table and §5 list (all copies; generators in step) |\n"
       "| F10 | `argon_reevaluation/outputs/MANIFEST.sha256` could not be refreshed after the link fixes without rewriting the report. | `generate_report_and_manifest.py --manifest-only`. | script |")
au.rep("## 3. Three ledger rows for the owner's decision (not changed)", "## 3. Three ledger rows — owner decision 08:20 EDT: applied (F7)")
au.rep("These are judgement calls on Argon's deliverable. Under the directive's own rule, verifier disagreements go to the owner, not to the verifier's pen. Each would change the headline counts, which appear in six documents and the metrics JSON, so the right way to adopt any of them is to re-run `build_ledger.py` and `generate_report_and_manifest.py`, not to hand-edit.",
       "These were judgement calls on Argon's deliverable; under the directive's own rule they went to the owner, who adopted all three. They were applied at the source (`scripts/build_ledger.py`, re-run) and propagated by `scripts/apply_ledger_decisions.py`, with the generators' hard-coded count strings updated in step and the regenerated `ARGON_REEVALUATION.md` re-passed through `proofread_fixes.py`. Resulting counts: 19 SUPPORTED, 4 CONTRADICTED, 17 INCONSISTENT, 17 PRIOR-CONSISTENT, 26 PRIOR-CONSTRAINED, 4 PROPOSED, 4 PROPOSED-INCOMPLETE, 4 ALLEGORY; 52 rows changed status, 43 unchanged.")
au.rep("| Row | As graded | Why I disagree | Recommended | Count impact |", "| Row | As delivered | Why I disagreed | Applied as | Count impact |")
au.rep("| PROPOSED, bar noted, clearing test T-4 | PRIOR-CONSISTENT 19→18, PROPOSED 3→4 |",
       "| PROPOSED; bar kept as context; clearing test `T-4` + `E4-Mm` poroelastic refit on the own pipeline; note flagged `SELF` | PRIOR-CONSISTENT 19→18, PROPOSED 3→4 |")
au.rep("| PROPOSED-INCOMPLETE, missing item: a prediction with a unit and a falsifier | PRIOR-CONSISTENT 18→17, PROPOSED-INCOMPLETE 3→4 |",
       "| PROPOSED-INCOMPLETE; `old_status` OPEN, ground NO-PREDICTION; `missing_item`: a prediction with a unit and a falsifier; the E4 null recorded as the bar for its one prior form; removed from the `T-5` unlock list | PRIOR-CONSISTENT 18→17, PROPOSED-INCOMPLETE 3→4 |")
au.rep("| Keep SUPPORTED for δ_bl = 0.552 mm and Q = 1941.3; move the gradient to INCONSISTENT (internal) pending V3, or add a V3 caveat to the note | if split: SUPPORTED 20→19, INCONSISTENT 16→17 |",
       "| INCONSISTENT (internal, own data against own data); the note keeps δ_bl and Q as DERIVATION; `V3` (steady-state re-run, ≥ Q/π ≈ 618 cycles, falsifier H-V3 within 10 %) added to the test queue at \\$0 | SUPPORTED 20→19, INCONSISTENT 16→17; changed 51→52, unchanged 44→43 |")
au.rep("- Literature anchors in `citations_xtr.jsonl` remain *(not re-fetched)*; no row in this package may be cited as SOURCE until they are.",
       "- Literature anchors in `citations_xtr.jsonl` remain *(not re-fetched)*; no row in this package may be cited as SOURCE until they are.\n"
       "- The three `gen_*.py` generators carry the updated count strings and the corrected §5 partition, but still write to the study root with pre-proofread link paths and the pre-F3 L2 prose; the published documents in `revision\\` are the deliverable. Re-running a generator requires re-applying `proofread_fixes.py`.\n"
       "- The 56/39 column split in `FINAL_MASTER_ANALYSIS_ARGON_REVISION.md` §5.1 is the CSV's row order (first 56 = `SPH-01`), which is also what `reevaluation_metrics.json` reports; Argon's delivered split had no reproducible definition.")
au.save()

pc = os.path.join(ARG, "outputs", "proofread_changes.json")
j = json.load(open(pc, encoding="utf-8"))
j["ledger_decisions_revB"] = {"applied": NOW, "script": "scripts/apply_ledger_decisions.py", "log": "outputs/ledger_decisions_changes.json",
                              "rows": LOG["decisions"], "counts_after": NC, "changed": mA["changed_count"], "unchanged": mA["unchanged_count"]}
json.dump(j, open(pc, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
json.dump(LOG, open(os.path.join(ARG, "outputs", "ledger_decisions_changes.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("applied. counts:", NC, "changed/unchanged:", mA["changed_count"], mA["unchanged_count"])
print("files edited:", len(LOG["files"]))
