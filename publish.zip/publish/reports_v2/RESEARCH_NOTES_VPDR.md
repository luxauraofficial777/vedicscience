# RESEARCH_NOTES.md

## Summary
Compiled structured dataset (claims_dataset.csv) and citation list (citations_compiled.jsonl) for Vedic sciences theories x plasma/particle physics, gradient-graded against CERN QGP and ITER fusion plasma anchors. 46 atomic claims + 10 unique citations (3 fetched/verified, 7 marked not re-fetched).

## What was found
- Vedic theory claims are predominantly structural analogies (ALLEGORY/HYPOTHESIS); only oral pathas and sabdavedhi survive as physically plausible without new physics.
- 40-octave sound->light claim is arithmetically inconsistent (9.7 decades ~32-34 octaves).
- CERN QGP provides precise sound-in-primordial-matter measurement (c_s^2=0.241, T=219 MeV); ITER provides frequency-matched heating analogs (ICRH 40-55 MHz, ECRH 170 GHz).
- Local corpus numbers (7 Hz, 34.4 Hz, 20.35-28 kHz, 25 kHz, 40/40.007 kHz, 10 GHz, 464 cm^-1, 1000 cm^-1, G_eff, q_dot) included with evidence classes.

## Gaps
- Several URLs could not be fetched (PhilArchive 403, MIT/IJFMR/Zenodo/Wikipedia/Sacred-texts not attempted or not accessible); marked "(not re-fetched)".
- Tokamak magnetic field 5.3 T and plasma-as-4th-state not directly verified this session.
- No audio corpus for Vedic chant pitch analysis; remains deferred.
