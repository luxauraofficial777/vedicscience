# BAND V — VIBRATIONAL & CONTINUUM ACOUSTICS AUDIT REPORT
**Document ID:** `SPH01-BAND-V-01`  
**Directive Reference:** [`WORK_OFFLOAD_DIRECTIVE_SPH01.md`](../WORK_OFFLOAD_DIRECTIVE_SPH01.md) (§4, Band V: Tasks `V1`–`V6`)  
**Reproducible Script & Metrics:** [`scripts/phase2_band_computations.py`](scripts/phase2_band_computations.py) $\to$ [`outputs/phase2_band_metrics.json`](outputs/phase2_band_metrics.json)  
**Primary Citations Registry:** [`citations.jsonl`](citations.jsonl)

---

## Executive Summary of Band V Findings

1. **Task V1 (Resolution of the Triple $G_{\text{eff}} / \sigma_t^{\text{eff}}$ Contradiction — `C2`, `M6`):** Across the v1 corpus, three incompatible values were cited at $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$: $G_{\text{eff}} = 6.89\text{ GPa}$ / $\sigma_t^{\text{eff}} = 7.19\text{ MPa}$ ([`Task_01:116`](../Task_01_Acoustic_Softening_NME_Report.md#L116), using a miscalculated $\mathcal{S} = 0.510$ and an unsourced $\operatorname{Re}[\mathcal{D}] = 0.450$), $G_{\text{eff}} = 16.80\text{ GPa}$ ([`Task_03:120`](../Task_03_Numerical_Simulation_Spec_Report.md#L120) and [`sim_cavity_acoustics.py`](../sim_cavity_acoustics.py), using the exact backbone $\mathcal{S} = 0.5600$), and $\sigma_t^{\text{eff}} = 2.62\text{ MPa}$ ([`Master:144`](../Consolidated_Master_Report_AS_NME.md#L144), which silently substituted the $\varepsilon_{\text{ac}} = 2.5 \times 10^{-4}$ value). We establish a single, reproducible **Backbone Standard** across [`Task_01_v2.md`](Task_01_v2.md) and [`Task_02_v2.md`](Task_02_v2.md): at $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$, $\mathcal{S}(\varepsilon_{\text{ac}}) = \mathbf{0.5600}$, $G_{\text{backbone}} = \mathbf{16.80\text{ GPa}}$, and $\sigma_{t,\text{backbone}}^{\text{eff}} = 15.0\sqrt{0.5600} = \mathbf{11.225\text{ MPa}}$.
2. **Task V2 (Excavation Energy Budget, Holding Power, Griffith Invariance & Workforce Fix — `M7`):**
   - **Griffith Strain-Energy Release Rate Invariance:** Under Griffith–Irwin fracture mechanics, the critical tensile stress scales as $\sigma_t^{\text{eff}} = \sqrt{\frac{4 G_{\text{eff}} \gamma_s}{\pi (1-\nu) a}} \propto \sqrt{G_{\text{eff}}}$. Consequently, the critical elastic energy release rate per unit crack area created is **invariant** under modulus softening:
     $$G_c = \frac{(\sigma_t^{\text{eff}})^2 \pi a (1-\nu)}{2 G_{\text{eff}}} = 2\gamma_s$$
     Softening $G_{\text{eff}}$ lowers the **peak stress threshold** $\sigma_t^{\text{eff}}$ needed for a cavitation pulse to initiate cleavage, but does **not** reduce the thermodynamic work $2\gamma_s$ per unit fracture area.
   - **Volumetric Holding Dissipation ($\dot{q}_{\text{hold}}$):** Sustaining $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$ at $21.5\text{ kHz}$ ($Q^{-1} = 0.1592$) dissipates $\dot{q}_{\text{hold}} = \frac{1}{2}\omega G_0 \varepsilon_{\text{ac}}^2 Q^{-1} = \mathbf{7.256\text{ MW/m}^3}$. A $25\text{ kW}$ transducer array can therefore condition at most **$V_{\text{active}} = 3.445\text{ L}$** ($3.45 \times 10^{-3}\text{ m}^3$) of rock at any instant (a localized cutting-head kerf zone, not a bulk cliffside).
   - **Workforce Double-Counting Fix (`M7`):** In [`Task_02:134`](../Task_02_Energy_Scaling_Matrix_Report.md#L134), dividing $\bar{P}_{\text{trad}} = 74,175\text{ W}$ by $P_{\text{mason}} \cdot \eta_{\text{chisel}} = 75\text{ W} \times 0.04 = 3.0\text{ W}$ to get $24,725$ masons **double-counted** the $\sim 4\%$ chisel efficiency already embedded in the empirical specific energy $E_{s,\text{trad}} = 150\text{ MJ/m}^3$. The corrected active mason count at $150\text{ MJ/m}^3$ and $75\text{ W}$ mechanical output per mason is $74,175 / 75 = \mathbf{989\text{ masons}}$ ([`Task_02_v2.md`](Task_02_v2.md)).
3. **Task V3 (FDTD Steady-State Ring-Up & Boundary Impedance Reconciliation):** In [`Task_03:81`](../Task_03_Numerical_Simulation_Spec_Report.md#L81), a cavity with quality factor $Q_{\text{cav}} = 1,941.3$ was specified for $N_{\text{cycles}} = 20$ FDTD periods ($0.581\text{ s}$). After $20$ cycles, a resonator of $Q = 1,941.3$ reaches only $1 - \exp(-\pi \cdot 20 / 1941.3) = \mathbf{3.185\%}$ of its steady-state pressure amplitude ($\mathbf{0.1014\%}$ of steady-state energy); reaching $95\%$ of steady-state amplitude requires **$1,851.2\text{ cycles}$** ($\approx 53.8\text{ s}$) or direct frequency-domain Helmholtz inversion.
4. **Task V4 (Barabar Caves Acoustic & Roughness Audit — `M3`):** The claim that all four Barabar granite caves share a measured $34.4\text{ Hz} \pm 0.1\text{ Hz}$ resonance ("Chevalier Paradigm") traces to non-peer-reviewed web sources (ALBA Project / *Song of the Stone*), and ALBA's own technical page lists $57.1\text{ Hz}$ for Karan Chaupar. In [`Task_03:49`](../Task_03_Numerical_Simulation_Spec_Report.md#L49), $34.40\text{ Hz}$ is obtained circularly from an assumed rectangular box length $L_x = 5.00\text{ m}$ and $c_0 = 344.0\text{ m/s}$ ($f_{100} = c_0 / 2L_x = 34.40\text{ Hz}$). Additionally, the Barabar mirror-polished granite roughness is $R_a \approx \mathbf{0.1\text{–}2.0\ \mu\text{m}}$ (micrometers), not `0.1–0.5 mm` as misprinted in [`Task_03:91`](../Task_03_Numerical_Simulation_Spec_Report.md#L91).
5. **Task V5 (Berktay $-86.2\text{ dB}$ Roll-Off & Narayanastra Doppler Sweep):**
   - **Berktay Parametric Demodulation (`Sammohana`):** By Berktay's (1965) far-field envelope-demodulation law [`CIT-020`], self-demodulated pressure scales as $p_d \propto \frac{\partial^2}{\partial t^2} E^2(t) \propto (\Delta f)^2$ ($-12\text{ dB/octave}$ in pressure, $-40\log_{10}(f_{\text{ref}}/\Delta f)$ in dB). Stepping down from $1\text{ kHz}$ to $\Delta f = 7\text{ Hz}$ incurs a **$40\log_{10}(7/1000) = \mathbf{-86.20\text{ dB}}$** penalty, confirming Altmann's (2001) conclusion [`CIT-008`] that outdoor $145\text{–}165\text{ dB}$ infrasound from portable ultrasonic arrays is physically unachievable.
   - **Narayanastra Doppler Sweep:** Using the corpus script's own damping parameter $\gamma_d = 0.035$ ([`verify_metamaterial_and_hugoniot.py`](../verify_metamaterial_and_hugoniot.py#L46)), the resonator quality factor is $Q_d = 1/\gamma_d = \mathbf{28.57}$ and $Q_d^2 = \mathbf{816.3}$ (not $10^3\text{–}10^4$), with a half-width at half-maximum $\text{HWHM} = \mathbf{356.2\text{ Hz}}$ at $f_{d,\text{res}} = 20,355\text{ Hz}$. A walking target ($v_t = 2.0\text{ m/s}$) produces a monostatic Doppler shift $\Delta f = 2 v_t f_0 / c_{\text{air}} = \mathbf{231.1\text{ Hz}}$ ($0.65\times$ of a linewidth), increasing energy absorption by only $484.7 / 260.0 = \mathbf{1.86\times}$ over a stationary target (`v_t = 0`).
6. **Task V6 (Prompt Elastogravity vs. Sound-Carried Gravitational Mass):** We compare the established prompt elastogravity signals measured by Vallée et al. (*Science* 358, 1164, 2017 [`CIT-007`]) during the 2011 Tohoku $M_w\ 9.1$ earthquake ($\Delta g \sim 1\text{ nm/s}^2$ arriving ahead of seismic $P$-waves at speed $c$) against the theoretical effective gravitational mass carried by sound waves derived by Esposito, Krichevsky & Nicolis (*PRL* 122, 084501, 2019 [`CIT-008`]): $M_{\text{sound}} = -\frac{\gamma_{\text{ad}}-1}{2 c_s^2} E_{\text{sound}}$. Inside the corpus's $37.5\text{ m}^3$ cavity ($E_{\text{sound}} = 224.5\text{ kJ}$), the sound wave carries an effective gravitational mass of **$M_{\text{sound}} = -0.379\text{ g}$** ($-3.79 \times 10^{-4}\text{ kg}$), which is $2.76 \times 10^{11}$ times smaller than the $106.9\text{ t}$ rock mass.

---

## Task V1 — Unified $G_{\text{eff}}(\varepsilon_{\text{ac}})$ and $\sigma_t^{\text{eff}}(\varepsilon_{\text{ac}})$ Value Chain

Using the exact Guyer–Johnson–McCall PM backbone formula from [`Task_01_Acoustic_Softening_NME_Report.md`](../Task_01_Acoustic_Softening_NME_Report.md#L56) ($G_0 = 30.0\text{ GPa}$, $\sigma_{t,0} = 15.0\text{ MPa}$, $\alpha_G = 2500$, $\varepsilon_{\text{th}} = 10^{-6}$, $\delta_G = -4.0 \times 10^6$, Negligible $\Phi_{\text{GL}} \approx 0$ for $\varepsilon_{\text{ac}} \ll \varepsilon_{\text{cr}}$):

$$\mathcal{S}(\varepsilon_{\text{ac}}) = 1 - \alpha_G (\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) - \frac{3}{4}|\delta_G|\varepsilon_{\text{ac}}^2$$

### Table V1.1 — Reconciled Backbone Stiffness, Internal Friction & Holding Power (`COMMAND` — [`outputs/phase2_band_metrics.json`](outputs/phase2_band_metrics.json))

| Dynamic Strain $\varepsilon_{\text{ac}}$ | Exact Backbone $\mathcal{S}(\varepsilon_{\text{ac}})$ | v1 Table 3.3 $\mathcal{S}$ (Error) | Backbone Shear Modulus $G_{\text{backbone}}\ (\text{GPa})$ | Backbone Tensile Strength $\sigma_{t,\text{backbone}}^{\text{eff}}\ (\text{MPa})$ | Internal Friction $Q^{-1} = \frac{4\alpha_G \varepsilon_{\text{ac}}}{3\pi}$ | Quality Factor $Q$ | Holding Dissipation $\dot{q}_{\text{hold}}$ at $21.5\text{ kHz}$ ($\text{MW/m}^3$) | Max Rock Volume Sustained at $25\text{ kW}$ ($\text{L}$) | Model Validity |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :---: |
| $1.0 \times 10^{-5}$ | **$0.9772$** | $0.975$ | $29.316$ | $14.828$ | $0.0106$ | $94.25$ | $0.0022$ | $11,627.9\text{ L}$ | **VALID** |
| $5.0 \times 10^{-5}$ | **$0.8700$** | $0.865$ | $26.100$ | $13.991$ | $0.0531$ | $18.85$ | $0.2687$ | $93.02\text{ L}$ | **VALID** |
| **$1.5 \times 10^{-4}$** | **$0.5600$** | $0.510$ | **$16.800$** | **$11.225$** | **$0.1592$** | **$6.28$** | **$7.2562$** | **$3.445\text{ L}$** | **VALID (Nominal)** |
| $2.5 \times 10^{-4}$ | **$0.1900$** | $0.145$ | $5.700$ | $6.538$ | $0.2653$ | $3.77$ | $33.5937$ | $0.744\text{ L}$ | **Marginal** |
| $1.0 \times 10^{-3}$ | **$-4.4975$** | — | $-134.925$ | Undefined | **$1.0610$** | $0.94$ | $2,150.0$ | $0.0116\text{ L}$ ($11.6\text{ cm}^3$) | **INVALID (`C1`)** |

> **Reconciliation Note:** In [`Task_01_v2.md`](Task_01_v2.md), the unsourced constant column $\operatorname{Re}[\mathcal{D}(\omega)] = 0.450$ is removed from the primary backbone table and replaced by an explicit distinction between:
> 1. **Quasi-static / Off-Resonant Backbone Softening ($\mathcal{S} = 0.5600$ at $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$):** $G_{\text{backbone}} = 16.80\text{ GPa}$, $\sigma_t^{\text{eff}} = 11.225\text{ MPa}$ (matching [`Task_03:120`](../Task_03_Numerical_Simulation_Spec_Report.md#L120) and [`sim_cavity_acoustics.py`](../sim_cavity_acoustics.py)).
> 2. **Frequency-Dependent Lorentzian Resonance Softening ($\omega \to \omega_m(\varepsilon_{\text{ac}})$):** Modeled explicitly via Module II's frequency-dependent effective medium formula ([`verify_metamaterial_and_hugoniot.py`](../verify_metamaterial_and_hugoniot.py)), where $\operatorname{Re}[\mathcal{D}(\omega)]$ is a strong function of frequency $f$ and damping $\Gamma_m$, not a fixed constant.

---

## Task V2 — Kailasa Excavation Energy, Holding Power, Griffith Invariance & Workforce Audit

### Table V2.1 — Reconciled Excavation Energy & Power Matrix (`COMMAND` — [`Task_02_v2.md`](Task_02_v2.md))

| Parameter / Regime | v1 Reported Value ([`Task_02`](../Task_02_Energy_Scaling_Matrix_Report.md)) | Audited & Corrected v2 Value ([`Task_02_v2.md`](Task_02_v2.md)) | Physical Basis of Correction |
| :--- | :--- | :--- | :--- |
| **Excavated Basalt Volume ($V_{\text{exc}}$)** | $140,350.88\text{ m}^3$ ($400,000\text{ t}$) | $140,350.88\text{ m}^3$ (upper bound; $70,175\text{ m}^3$ for archaeological $200,000\text{ t}$ consensus) | Upper engineering benchmark retained with explicit archaeological range note |
| **Regime 1: Mechanical Chisel Specific Energy ($E_{s,\text{trad}}$)** | $150.0\text{ MJ/m}^3$ ($21.053\text{ TJ}$, $\bar{P} = 74.18\text{ kW}$) | $150.0\text{ MJ/m}^3$ ($21.053\text{ TJ}$, $\bar{P} = 74.18\text{ kW}$) | Standard specific energy of manual/mechanical rock chiseling (already includes tool-impact inefficiency) |
| **Regime 1: Required Active Masons (18-yr, 12 hr/day)** | $24,725\text{ masons}$ | **$989\text{ masons}$** (at $150\text{ MJ/m}^3$, $75\text{ W/mason}$) | v1 divided $74,175\text{ W}$ by $\eta_{\text{chisel}} = 0.04$ a **second time** (`M7`), inflating labor by $25\times$ |
| **Regime 3: Backbone Softening Factor ($\mathcal{S}$ at $1.5 \times 10^{-4}$)** | $G_{\text{eff}}/G_0 = 0.230$ ($\sqrt{0.230} = 0.4796$) | **$\mathcal{S} = 0.5600$** ($\sqrt{0.5600} = 0.7483$) | Uses reproducible backbone $\mathcal{S}(1.5\times 10^{-4}) = 0.5600$ instead of unsourced $\operatorname{Re}[\mathcal{D}] = 0.450$ |
| **Regime 3: Threshold-Adjusted Specific Energy ($E_{s,\text{NME}}$)** | $16.79\text{ MJ/m}^3$ ($8.93\times$ gain) | **$26.19\text{ MJ/m}^3$** ($5.73\times$ gain vs. $150\text{ MJ/m}^3$) | $E_{s,\text{cav}} \sqrt{\mathcal{S}} = 35.0 \times 0.7483 = 26.19\text{ MJ/m}^3$ (labelled `HYPOTHESIS` for overpressure-threshold scaling, since Griffith $G_c = 2\gamma_s$ is modulus-invariant) |
| **Active-Zone Holding Power ($\dot{q}_{\text{hold}}$ at $1.5 \times 10^{-4}$, $21.5\text{ kHz}$)** | Omitted in v1 | **$7.256\text{ MW/m}^3$** ($3.445\text{ L}$ active cutting zone at $25\text{ kW}$) | Continuous internal friction $\dot{q} = \frac{1}{2}\omega G_0 \varepsilon_{\text{ac}}^2 Q^{-1}$ restricts NME conditioning to a localized $\sim 3.4\text{ L}$ kerf volume under the cutting nozzle |

---

## Task V3 — FDTD Steady-State Ring-Up & Impedance Audit (`Task_03`)

In [`Task_03_Numerical_Simulation_Spec_Report.md`](../Task_03_Numerical_Simulation_Spec_Report.md#L81), the 3D FDTD simulation is specified for $N_{\text{cycles}} = 20$ periods of $f_0 = 34.40\text{ Hz}$ ($T_{\text{sim}} = 0.5814\text{ s}$) inside a granite chamber whose Stokes–Kirchhoff + radiation quality factor is $Q_{\text{total}} = 1,941.3$ ([`sim_cavity_acoustics.py`](../sim_cavity_acoustics.py)).

For a linear resonator driven on resonance from rest, the envelope builds up as:

$$A(N_{\text{cycles}}) = A_{\infty}\left[1 - \exp\!\left(-\frac{\pi N_{\text{cycles}}}{Q_{\text{total}}}\right)\right]$$

- At $N_{\text{cycles}} = 20$ and $Q_{\text{total}} = 1,941.3$:
  $$\frac{A(20)}{A_{\infty}} = 1 - \exp\!\left(-\frac{20\pi}{1941.3}\right) = \mathbf{0.03185}\ (3.185\%), \qquad \frac{E(20)}{E_{\infty}} = (0.03185)^2 = \mathbf{0.001014}\ (0.1014\%)$$
- Reaching $95\%$ of steady-state amplitude ($A / A_{\infty} = 0.95$) requires:
  $$N_{95\%} = -\frac{\ln(0.05)\, Q_{\text{total}}}{\pi} = \mathbf{1,851.2\text{ cycles}} \quad (T_{\text{sim}} \approx 53.81\text{ s}, \text{ or } 4.35 \times 10^6\text{ FDTD steps at } \Delta t = 12.37\ \mu\text{s})$$
- **Remediation:** For high-$Q$ cavity eigenmodes ($Q \sim 2,000$), steady-state pressure and boundary-layer shear fields should be computed directly in the **frequency domain** via the Helmholtz eigenvalue/resolvent equation $(\nabla^2 + k^2)\hat{P} = -\hat{S}(\omega)$ (as implemented in [`sim_cavity_acoustics.py`](../sim_cavity_acoustics.py)), whereas short-duration time-domain FDTD ($20$ cycles) measures only the initial transient ring-up slope $\frac{dA}{dt}\big|_{t=0}$.

---

## Task V4 — Barabar Caves Acoustic & Surface Roughness Audit (`M3`)

1. **Provenance of the "34.4 Hz Chevalier Paradigm":** Literature and web verification confirms that no peer-reviewed acoustical journal paper by "Frédéric Chevalier" exists measuring $34.4\text{ Hz} \pm 0.1\text{ Hz}$ across all four Barabar caves. The claim originates in non-peer-reviewed documentary/web materials (the *ALBA Project* / Patrice Pouillard's *Awakening* / *Song of the Stone*), and ALBA's own technical report lists a primary resonant peak of **$57.1\text{ Hz}$** for Karan Chaupar rather than $34.4\text{ Hz}$. Furthermore, the four Barabar caves have substantially different longitudinal lengths (e.g., Karan Chaupar is $\sim 10.2\text{ m}$ long, giving a half-wave mode $c/2L \approx 16.9\text{ Hz}$ and second harmonic $\approx 33.7\text{ Hz}$, whereas Lomas Rishi and Sudama have dual-chamber layouts with circular/vaulted huts). In [`Task_03:49`](../Task_03_Numerical_Simulation_Spec_Report.md#L49), $f_{100} = 34.40\text{ Hz}$ is simply the analytical result of assuming a $L_x = 5.00\text{ m}$ box at $c_0 = 344.0\text{ m/s}$ ($344 / (2 \times 5) = 34.40\text{ Hz}$). It must therefore be tagged as an **idealized benchmark cavity (`HYPOTHESIS`)**, not an empirically verified invariant across all four Barabar caves.
2. **Surface Roughness Unit Fix (`mm` $\to$ `μm`):** [`Task_03:91`](../Task_03_Numerical_Simulation_Spec_Report.md#L91) wrote *"polished Barabar granite roughness $R_a \approx 0.1\text{–}0.5\text{ mm}$"*. Mirror-polished Mauryan granite surfaces in the Barabar caves have arithmetic mean roughness in the **micrometer** range ($R_a \approx \mathbf{0.1\text{–}2.0\ \mu\text{m}}$), whereas unpolished rough-chiseled granite has $R_a \sim 0.1\text{–}0.5\text{ mm}$. Since the Stokes viscous boundary layer thickness at $34.4\text{ Hz}$ is $\delta_\nu = 374.2\ \mu\text{m}$, a mirror polish of $R_a \sim 0.1\text{–}2.0\ \mu\text{m}$ satisfies $\delta_\nu / R_a \in [187, 3742] \gg 1$, validating the hydrodynamically smooth laminar Stokes–Kirchhoff boundary-layer regime!

---

## Task V5 — Berktay Parametric Roll-Off ($7\text{ Hz}$) & Narayanastra Doppler Sweep

### 1. Berktay Far-Field Parametric Demodulation at $\Delta f = 7\text{ Hz}$ (`DERIVATION`)
By Berktay's (1965) far-field parametric array solution [`CIT-020`], when a collimated primary ultrasonic beam of carrier frequency $f_c = 40\text{ kHz}$ is modulated by an envelope $E(t)$ at difference frequency $\Delta f = f_2 - f_1$, the on-axis self-demodulated secondary pressure $p_d(r, t)$ in the far field is proportional to the **second time derivative** of the squared envelope:

$$p_d(r, t) = \frac{\beta_{\text{nl}} P_0^2 S_0}{16 \pi \rho_0 c_0^4 r \alpha_0} \frac{\partial^2}{\partial \tau^2} E^2(\tau) \propto (\Delta f)^2$$

Because $p_d \propto (\Delta f)^2$, the demodulated sound pressure level rolls off at **$-12\text{ dB per octave}$** ($-40\text{ dB per decade}$) as $\Delta f$ decreases. Relative to a standard parametric audio reference frequency $f_{\text{ref}} = 1,000\text{ Hz}$:

$$\Delta L_{\text{Berktay}}(7\text{ Hz vs. } 1\text{ kHz}) = 40 \log_{10}\!\left(\frac{7\text{ Hz}}{1000\text{ Hz}}\right) = \mathbf{-86.20\text{ dB}}$$

Thus, even if an ultrasonic array produced $120\text{ dB SPL}$ of demodulated audio at $1\text{ kHz}$, its demodulated output at $7\text{ Hz}$ drops to $\sim 33.8\text{ dB SPL}$—more than $110\text{ dB}$ below the $145\text{–}165\text{ dB}$ threshold claimed in [`Task_04:70`](../Task_04_Astra_Data_Hardening_Protocol_Report.md#L70).

### 2. Narayanastra Doppler-Shift Sweep (`COMMAND` — [`outputs/phase2_band_metrics.json`](outputs/phase2_band_metrics.json))
Evaluating the dipolar resonance Lorentzian from [`verify_metamaterial_and_hugoniot.py`](../verify_metamaterial_and_hugoniot.py) ($f_{d,\text{res}} = 20,355.0\text{ Hz}$, $\gamma_d = 0.035 \implies Q_d = 28.57$, $Q_d^2 = 816.3$, $\text{HWHM} = 356.21\text{ Hz}$) with a primary carrier parked $1.5$ linewidths below resonance ($f_{\text{carrier}} = 19,820.68\text{ Hz}$, $c_{\text{air}} = 343.0\text{ m/s}$):

| Target Speed $v_t\ (\text{m/s})$ | Physical Motion | Monostatic Doppler Shift $\Delta f = \frac{2 v_t}{c_{\text{air}}} f_{\text{carrier}}\ (\text{Hz})$ | Shifted Frequency $f_{\text{eff}}\ (\text{Hz})$ | Detuning $f_{\text{eff}} - f_{d,\text{res}}\ (\text{Hz})$ | Lorentzian Amplitude Gain $|\mathcal{L}(f_{\text{eff}})|$ | Acoustic Energy Gain $|\mathcal{L}(f_{\text{eff}})|^2$ | Gain Ratio vs. Stationary ($v_t = 0$) |
| ---: | :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| $0.0$ | Stationary (prostrate) | $0.00$ | $19,820.68$ | $-534.32$ | $16.13\times$ | $260.0\times$ | $1.00\times$ |
| $1.0$ | Slow walk | $+115.57$ | $19,936.25$ | $-418.75$ | $18.79\times$ | $352.9\times$ | $1.36\times$ |
| $2.0$ | Brisk walk / infantry | $+231.14$ | $20,051.83$ | $-303.17$ | $22.02\times$ | $484.7\times$ | **$1.86\times$** |
| $5.0$ | Running / chariot | $+577.86$ | $20,398.54$ | $+43.54$ | **$28.30\times$** | **$800.9\times$** | **$3.08\times$** (Peak) |
| $10.0$ | Galloping horse | $+1,155.72$ | $20,976.41$ | $+621.41$ | $13.94\times$ | $194.4\times$ | $0.75\times$ |
| $15.0$ | Fast projectile | $+1,733.59$ | $21,554.27$ | $+1,199.27$ | $7.88\times$ | $62.2\times$ | $0.24\times$ |

**Audit Conclusion (`INCONSISTENT` with v1 claim):** With the corpus's own damping parameter ($\gamma_d = 0.035$), a stationary target already receives $260\times$ energy gain and a walking target ($2\text{ m/s}$) receives $484.7\times$—a contrast ratio of only **$1.86\times$** (and a maximum peak contrast of $3.08\times$ at $5\text{ m/s}$), far below the $Q_d^2 \sim 10^3\text{–}10^4$ selective discrimination claimed in [`Consolidated_Master_Report_AS_NME.md:223`](../Consolidated_Master_Report_AS_NME.md#L223). Achieving a $10^4$ contrast ratio at $v_t = 2\text{ m/s}$ would require an ultra-narrow resonator with $\gamma_d \le 10^{-4}$ ($Q_d \ge 10,000$).

---

## Task V6 — Prompt Elastogravity Signals vs. Sound-Carried Gravitational Mass

We distinguish two legitimate, peer-reviewed couplings between elastic waves and gravity:

1. **Prompt Elastogravity Signals (PEGS — Vallée et al., *Science* 358, 1164, 2017 [`CIT-007`]):**
   - During great earthquakes (such as the 2011 Tohoku-Oki $M_w\ 9.1$ rupture), large-scale seismic compressional waves redistribute rock mass density $\delta \rho(\mathbf{r}, t) = -\rho_0 \nabla \cdot \mathbf{u}(\mathbf{r}, t)$ across hundreds of kilometers of crust and mantle.
   - Because changes in the Newtonian/relativistic gravitational field propagate at the speed of light $c$ rather than the seismic compressional speed $v_P \approx 6\text{–}8\text{ km/s}$, broadband seismometers and superconducting gravimeters $500\text{–}3,000\text{ km}$ from the epicenter record a **prompt gravity perturbation** $\Delta g \sim 0.5\text{–}2.0\text{ nm/s}^2$ arriving minutes *before* the seismic $P$-wave.
   - **Evidence Class:** `SOURCE` (measured and replicated across multiple $M_w > 8$ earthquakes).

2. **Effective Gravitational Mass Carried by Sound Waves (Esposito, Krichevsky & Nicolis, *PRL* 122, 084501, 2019 [`CIT-008`]):**
   - In nonlinear continuum fluid/solid mechanics, a localized acoustic wave packet of total energy $E_{\text{sound}}$ carries a nonzero second-order mass-dipole moment corresponding to an effective gravitational and inertial mass:
     $$M_{\text{sound}} = -\frac{\gamma_{\text{ad}} - 1}{2 c_s^2} E_{\text{sound}} \quad (\text{for an ideal gas of adiabatic index } \gamma_{\text{ad}})$$
   - Evaluating this formula for the corpus's $37.5\text{ m}^3$ resonant air cavity ($E_{\text{sound}} = 2.245 \times 10^5\text{ J}$, $\gamma_{\text{ad}} = 1.4$, $c_s = 344.0\text{ m/s}$):
     $$M_{\text{sound}} = -\frac{1.4 - 1.0}{2 (344.0\text{ m/s})^2} (2.245 \times 10^5\text{ J}) = \mathbf{-3.794 \times 10^{-4}\text{ kg}} = \mathbf{-0.3794\text{ g}}$$
   - **Scale Comparison:** An effective acoustic mass of $-0.38\text{ g}$ inside a $106,875\text{ kg}$ ($106.9\text{ t}$) rock block represents a fractional weight perturbation of $|\Delta M / M_{\text{rock}}| = \mathbf{3.55 \times 10^{-9}}$—nine orders of magnitude too small to levitate rock, though physically real as a second-order continuum nonlinear density deficit (`THEORETICAL` / `DERIVATION`).
