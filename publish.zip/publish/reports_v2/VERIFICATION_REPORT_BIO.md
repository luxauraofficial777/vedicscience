# VERIFICATION REPORT — BIO_GENE_CELLULAR_DEEP_RESEARCH

Date: 2026-10-18. Verifier: independent (opencode beam-free). Re-verification after fixes.

## 1. Crunch script rerun
- Command: `python scripts/crunch_bio.py`
- Exit code: **0** (stdout: `exit 0; rows 39`).
- Non-fatal warning: matplotlib `Tight layout not applied` (cosmetic only).

## 2. MANIFEST.sha256 recomputation
- Recomputed SHA-256 for all listed files.
- `outputs/bio_chart.png`, `outputs/bio_gradient_ledger.csv`, `outputs/bio_summary.json`, `scripts/crunch_bio.py`: **MATCH**.
- Manifest excludes itself (MANIFEST.sha256 not listed).
- Verdict: **PASS** (manifest discrepancy resolved).

## 3. claims_dataset_bio.csv checks
- Row count: **39** data rows.
- Columns (11): claim_id, source_file_or_url, text, category, freq_Hz, energy_eV, value, unit, evidence_class, citation_url, notes — required present.
- evidence_class: SOURCE=33, DERIVATION=6; all valid (no invalid values).
- claim_id: **0 empty, 0 duplicates.**

## 4. Internal consistency (freq_Hz + energy_eV → E=h f/e, 0.1%)
Rows tested: C-06, C-12, C-13, S-01, S-04, S-06 (6 total).
| Row | Stored eV | Computed eV | Rel. diff | Result |
|---|---|---|---|---|
| C-06 | 1.820e-12 | 1.8197e-12 | 0.017% | PASS |
| C-12 | 6.204e-09 | 6.2035e-09 | 0.008% | PASS |
| C-13 | 6.204e-09 | 6.2035e-09 | 0.008% | PASS |
| S-01 | 8.271e-11 | 8.2713e-11 | 0.004% | PASS |
| S-04 | 6.824e-13 | 6.8239e-13 | 0.002% | PASS |
| S-06 | 4.136e-12 | 4.1357e-12 | 0.008% | PASS |
- Verdict: **6/6 pass** (internal consistency resolved).

## 5. Spot-check corrected values
| Row | freq_Hz | energy_eV | Result |
|---|---|---|---|
| C-06 | 440 | 1.820e-12 | PASS |
| C-12 | 1.5e6 | 6.204e-9 | PASS |
| S-01 | 20000 | 8.271e-11 | PASS |
| S-06 | 1000 | 4.136e-12 | PASS |

## 6. Key computed numbers
- ratio phonon_20kHz / ATP_std = 8.271e-11 / 0.316 = **2.617e-10** — PASS.
- f_equiv_ATP = 0.316 eV·e/h = **7.6408e13 Hz** — PASS.
- octaves from 20 kHz = log2(7.6408e13 / 2e4) = **31.83** — PASS.

## Discrepancies for owner
All prior discrepancies resolved: manifest self-hash, internal consistency, claim count 39.
