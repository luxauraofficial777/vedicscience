# Technical Report — Iteration II (v2 — Hardened)
## Comparative Energy Scaling Matrix for Monolithic Basalt Excavation
**Project:** Acoustic Sculpture, Nonlinear Mesoscopic Elasticity (NME) & Substrate Dynamics  
**Document ID:** `AS-NME-REP-02-V2` (Supersedes [`Task_02_Energy_Scaling_Matrix_Report.md`](../Task_02_Energy_Scaling_Matrix_Report.md))  
**Audit Reference:** [`BAND_V_VIBRATIONAL.md`](BAND_V_VIBRATIONAL.md) · [`CHANGELOG.md`](CHANGELOG.md)  
**Subject:** Thermodynamic & Mechanical Energy Budget, Active-Kerf Holding Power, and Corrected Workforce Scaling for $140,350.88\text{ m}^3$ ($400,000\text{ t}$) Top-Down Basalt Excavation

---

### Page 1: Thermodynamic Foundations of Specific Excavation Energy ($E_s$)

#### 1.1 Substrate Mass-Volume Benchmark (`DERIVATION`)
For top-down monolithic excavation in dense tholeiitic flood basalt (e.g., Deccan Trap basalt at the Kailasa monolith benchmark) with bulk density $\rho_b = 2,850\text{ kg/m}^3$ and upper-benchmark excavated mass $M_{\text{exc}} = 4.00 \times 10^8\text{ kg}$ ($400,000\text{ metric tons}$; note that mainstream archaeological estimates range from $150,000\text{ to }200,000\text{ metric tons}$), the upper-bound in-situ rock volume is:

$$V_{\text{exc}} = \frac{M_{\text{exc}}}{\rho_b} = \frac{400,000,000\text{ kg}}{2,850\text{ kg/m}^3} = 140,350.8772\text{ m}^3 \approx 140,350.88\text{ m}^3$$

---

#### 1.2 Partitioning of Specific Cutting Energy ($E_s = dW / dV$)
The specific excavation energy $E_s$ ($\text{MJ/m}^3$) required to disintegrate a unit volume of intact rock into removable fragments of characteristic size $d_f$ is governed by:

$$E_s = \frac{1}{\eta_{\text{trans}}} \left( U_{\gamma}(d_f) + U_{\text{el}}(\sigma_{\text{fail}}) + U_{\text{pl}} + U_{\text{fric}} \right)$$

---

#### 1.3 Physical Basis of the Three Specific Energy Regimes

##### Regime A: Traditional Mechanical Percussion & Abrasion ($E_{s,\text{trad}} = 150\text{ MJ/m}^3$ — `SOURCE`)
Mechanical chiseling and pick-impact load the basalt matrix predominantly in uniaxial/triaxial compression ($\sigma_c \approx 250\text{ MPa}$). Note that empirical rock-mechanics values of $E_{s,\text{trad}} = 150\text{–}300\text{ MJ/m}^3$ for manual/mechanical percussion **already incorporate** the tool-to-rock impact transfer efficiency ($\eta_{\text{trans}} \approx 0.04\text{–}0.08$) and frictional heat dissipation ($U_{\text{fric}} > 0.85 E_{\text{in}}$):

$$E_{s,\text{trad}} = 150.0\text{ MJ/m}^3 = 1.50 \times 10^8\text{ J/m}^3 \quad \left(41.67\text{ kWh/m}^3\right)$$

##### Regime B: Unconditioned Acoustic Cavitation ($E_{s,\text{cav}} = 35\text{ MJ/m}^3$ — `HYPOTHESIS`)
High-intensity ultrasonic cavitation generates asymmetric bubble collapse near the basalt boundary, inducing hydro-tensile wedging and intergranular spallation ($\sigma_{t,0} = 15\text{ MPa}$ vs. $\sigma_c = 250\text{ MPa}$), modeled at an effective specific cutting energy of:

$$E_{s,\text{cav}} = 35.0\text{ MJ/m}^3 = 3.50 \times 10^7\text{ J/m}^3 \quad \left(9.72\text{ kWh/m}^3\right)$$

##### Regime C: NME-Conditioned Acoustic Cavitation ($E_{s,\text{NME-cav}} = 26.19\text{ MJ/m}^3$ — Reconciled `C2`, `HYPOTHESIS`)
Using the reconciled backbone stiffness factor from [`Task_01_v2.md`](Task_01_v2.md) at $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$ ($\mathcal{S} = G_{\text{backbone}}/G_0 = \mathbf{0.5600}$, $\sigma_{t,\text{backbone}}^{\text{eff}} = \mathbf{11.225\text{ MPa}}$), if the specific cavitation spalling energy scales with the reduced tensile stress threshold ($\sqrt{\mathcal{S}} = \sqrt{0.5600} = 0.74833$):

$$E_{s,\text{NME-cav}}(\varepsilon_{\text{ac}} = 1.5\times 10^{-4}) = E_{s,\text{cav}} \sqrt{\mathcal{S}(\varepsilon_{\text{ac}})} = 35.0\text{ MJ/m}^3 \times \sqrt{0.5600} = \mathbf{26.19\text{ MJ/m}^3}$$

*(Note: As shown in [`Task_01_v2.md`](Task_01_v2.md) §3.2, the thermodynamic Griffith surface energy release rate $G_c = 2\gamma_s$ is invariant under elastic softening; hence this threshold-proportional reduction is tagged `HYPOTHESIS`).*

---

### Page 2: Volumetric Scaling & Active-Zone Holding Power Constraint

#### 2.1 Full-Volume Comminution Energy Equations (`DERIVATION`)
1. **Traditional Mechanical Excavation Total Energy ($E_{\text{tot,trad}}$):**
   $$E_{\text{tot,trad}} = 140,350.88\text{ m}^3 \times 150.0\text{ MJ/m}^3 = \mathbf{21.053\text{ TJ}} \quad \left(5,847.95\text{ MWh}\right)$$
2. **Acoustic Cavitation Excavation Total Energy ($E_{\text{tot,cav}}$):**
   $$E_{\text{tot,cav}} = 140,350.88\text{ m}^3 \times 35.0\text{ MJ/m}^3 = \mathbf{4.912\text{ TJ}} \quad \left(1,364.52\text{ MWh}\right)$$
3. **Reconciled NME-Conditioned Cavitation Total Energy ($E_{\text{tot,NME}}$ at $\mathcal{S} = 0.5600$):**
   $$E_{\text{tot,NME}} = 140,350.88\text{ m}^3 \times 26.19\text{ MJ/m}^3 = \mathbf{3.676\text{ TJ}} \quad \left(1,021.11\text{ MWh}, \quad \eta_{\text{gain,NME}} = \mathbf{5.73\times}\right)$$

---

#### 2.2 Volumetric Holding Power Dissipation & Active Cutting-Zone Volume (`Task V2`)
Sustaining an ultrasonic strain amplitude $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$ at $f = 21.5\text{ kHz}$ ($\omega = 1.3509 \times 10^5\text{ rad/s}$) in a basalt matrix with hysteretic internal friction $Q^{-1}(\varepsilon_{\text{ac}}) = \frac{4\alpha_G \varepsilon_{\text{ac}}}{3\pi} = 0.1592$ dissipates continuous thermal power per unit rock volume:

$$\dot{q}_{\text{hold}}(\varepsilon_{\text{ac}}) = \frac{1}{2} \omega G_0 \varepsilon_{\text{ac}}^2 Q^{-1}(\varepsilon_{\text{ac}}) = \frac{2}{3\pi} \omega G_0 \alpha_G \varepsilon_{\text{ac}}^3 = \mathbf{7.256\text{ MW/m}^3}$$

Consequently, a $P_{\text{array}} = 25.0\text{ kW}$ transducer array cannot condition an entire monolith simultaneously; instead, it conditions a **localized active cutting-head kerf volume** $V_{\text{active}}$ directly beneath the progressing sonic water-saw nozzle:

$$V_{\text{active}}(\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}) = \frac{P_{\text{array}}}{\dot{q}_{\text{hold}}} = \frac{25,000\text{ W}}{7.2562 \times 10^6\text{ W/m}^3} = \mathbf{3.445 \times 10^{-3}\text{ m}^3} = \mathbf{3.445\text{ Liters}}$$

---

#### 2.3 Kerf-Slot Acoustic Trenching & Basal Resonance Spalling (Hybrid Architecture)
For a modular extraction grid with $L_b = 1.0\text{ m}$, $H_b = 1.0\text{ m}$, and acoustic kerf width $w_k = 0.025\text{ m}$ ($f_{\text{kerf}} = 0.0731$, $E_{s,\text{spall}} = 0.45\text{ MJ/m}^3$ [`HYPOTHESIS`]):

$$E_{s,\text{hybrid}} = (0.0731)(35.0\text{ MJ/m}^3) + (0.9269)(0.45\text{ MJ/m}^3) = \mathbf{2.976\text{ MJ/m}^3}, \qquad E_{\text{tot,hybrid}} = \mathbf{0.418\text{ TJ}} \quad \left(116.02\text{ MWh}\right)$$

---

### Page 3: Reconciled Energy Scaling Matrix & Workforce Audit

#### 3.1 Master Comparative Energy & Power Scaling Matrix ($V_{\text{exc}} = 140,350.88\text{ m}^3$, $\Delta t_{\text{active}} = 78,840\text{ hrs}$)

| Metric / Parameter | Symbol | Unit | Regime 1: Traditional Percussion | Regime 2: Acoustic Cavitation | Regime 3: Reconciled NME + Cavitation ($\mathcal{S}=0.5600$) | Regime 4: Kerf-Slot Cavitation + Spall ($w_k=2.5\text{ cm}$) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Specific Cutting Energy** | $E_s$ | $\text{MJ/m}^3$ | $150.00$ | $35.00$ | **$26.19$** | $2.98$ |
| **Specific Energy (Mass Basis)** | $e_m = E_s/\rho_b$ | $\text{kJ/kg}$ | $52.63$ | $12.28$ | **$9.19$** | $1.04$ |
| **Specific Energy (Electrical Eq.)** | $E_{s,\text{kWh}}$ | $\text{kWh/m}^3$ | $41.67$ | $9.72$ | **$7.28$** | $0.83$ |
| **Total Excavation Energy** | $E_{\text{tot}}$ | $\text{TJ}$ | $21.053$ | $4.912$ | **$3.676$** | $0.418$ |
| **Total Energy (MWh Equivalent)** | $E_{\text{tot,MWh}}$ | $\text{MWh}$ | $5,847.95$ | $1,364.52$ | **$1,021.11$** | $116.02$ |
| **Energy Reduction Factor** | $\eta_{\text{gain}}$ | $\text{ratio}$ | $1.00\times$ | $4.29\times$ | **$5.73\times$** | $50.40\times$ |
| **Energy Saved vs. Traditional** | $\Delta E\%$ | $\%$ | $0.00\%$ | $76.67\%$ | **$82.54\%$** | $98.02\%$ |
| **Continuous Power (18-yr / 12h/d)** | $P_{\text{req}}$ | $\text{kW}$ | $74.18\text{ kW}$ | $17.31\text{ kW}$ | **$12.95\text{ kW}$** | $1.47\text{ kW}$ |
| **Time at Fixed $25\text{ kW}$ Array Power** | $T_{25\text{kW}}$ | $\text{years (12h/d)}$ | $53.41\text{ yr}$ | $12.46\text{ yr}$ | **$9.33\text{ yr}$** | $1.06\text{ yr}$ |

---

#### 3.2 Corrected Human Manual Workforce Analysis (Fixes Double-Counting `M7`)
1. **Eliminating the $25\times$ Chisel-Efficiency Double Count (`M7`):**
   In v1 of this report, $\bar{P}_{\text{trad}} = 74,175\text{ W}$ (computed from $E_{s,\text{trad}} = 150\text{ MJ/m}^3$) was divided by $P_{\text{hum}} \cdot \eta_{\text{trans}} = 75\text{ W} \times 0.04 = 3.0\text{ W/worker}$ to obtain $24,725$ workers. However, empirical specific excavation energy $E_{s,\text{trad}} = 150\text{ MJ/m}^3$ is defined in rock-mechanics literature as the **total mechanical input work delivered by the tool**, which *already* includes the $\sim 96\%$ frictional/impact loss ($\eta_{\text{trans}} \approx 4\%$). Dividing by $0.04$ a second time inflated the required mason count by $25\times$.
2. **Corrected Active Mason Count:**
   At $P_{\text{hum}} = 75\text{ W}$ of continuous mechanical hammer/chisel power per mason:
   $$N_{\text{masons, corrected}} = \frac{74,175\text{ W}}{75\text{ W/mason}} = \mathbf{989\text{ active masons}} \quad \left(\text{or }\sim 495\text{ masons for the }200,000\text{ t archaeological estimate}\right)$$
   *(Note: Schedule convention in `Task_02` uses $18 \times 365 \times 12 = 78,840\text{ hrs}$, whereas `02_Physical_Quantum...html` uses Julian leap-year $18 \times 365.25 \times 12 = 78,894\text{ hrs}$, a $0.068\%$ calendar convention difference).*
