﻿# RESEARCH_NOTES_BIO.md

## Summary
Compiled structured dataset (claims_dataset_bio.csv) and citation list (citations_bio.jsonl) for biological (ATP/ADP/AMP/PPi/PLP/PEA, TNAP/ALPL), genetic (hypophosphatasia), and cellular acoustics (audible sound/mechanotransduction) claims, with Sound Logic cross-references. 39 atomic claims + 25 unique citations (24 fetched/verified, 1 local/not re-fetched).

## What was found
- ATP standard hydrolysis ~0.32 eV (7.3 kcal/mol); cellular ~0.5-0.6 eV (12-14 kcal/mol); AMP ~0.14 eV; PPi/PLP/PEA are TNAP substrates.
- ALPL on chr1p36.12; ~300-450+ variants; ClinVar >1,600; HPP severe 1:300,000, mild 1:6,370 European; recessive severe, dominant/recessive mild; PPi/PLP accumulation; PLP->seizures.
- Ghosh 1998: GTP/ATP stimulate ALP renaturation under reducing conditions; Caswell 1986: NTP pyrophosphatase normal in HPP fibroblasts.
- Cellular acoustics: Kumeta 2025 (Commun Biol) ~187 sound-sensitive genes, FAK/PGE2/EP4, suppresses adipogenesis 13-15%; Kumeta 2018 suppression of Ptgs2/CTGF/TNC; Valenti & Atlante 2024 sound matrix/mitochondria; mechanotransduction reviews; Kwak 2022 systematic review; Lestard 2013; 1.5 MHz LIPUS osteoblastic genes.
- Sound Logic: 20 kHz phonon 8.3e-11 eV vs ATP 0.32 eV (10^10 gap); sound acts via mechanotransduction, not energetic transitions; oral patha redundancy parallels gene regulatory information.

## Gaps
- Several sources are reviews/summaries; primary data not independently re-derived.
- 1.5 MHz ultrasound studies are LIPUS (mechanical), not audible sound; distinct mechanism.
- Local corpus Sound Logic claims (oral patha) are structural analogies (DERIVATION), not physics.
- ClinVar count is a search result total, not curated pathogenic count.
