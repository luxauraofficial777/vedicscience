# Technical Report — Iteration II
## Comparative Energy Scaling Matrix for Monolithic Basalt Excavation
**Project:** Acoustic Sculpture, Nonlinear Mesoscopic Elasticity (NME) & Substrate Dynamics  
**Document ID:** `AS-NME-REP-02`  
**Subject:** Thermodynamic & Mechanical Energy Budget for $140,350.88\text{ m}^3$ ($400,000\text{ t}$) Top-Down Basalt Excavation

---

### Page 1: Thermodynamic Foundations of Specific Excavation Energy ($E_s$)

#### 1.1 Substrate Mass-Volume Benchmark
For top-down monolithic excavation in dense tholeiitic flood basalt (e.g., Deccan Trap basalt at the Kailasa monolith benchmark) with bulk density $\rho_b = 2,850\text{ kg/m}^3$ ($2.85\text{ metric tons/m}^3$) and total excavated mass $M_{\text{exc}} = 4.00 \times 10^8\text{ kg}$ ($400,000\text{ metric tons}$), the exact in-situ rock volume is:

$$V_{\text{exc}} = \frac{M_{\text{exc}}}{\rho_b} = \frac{400,000,000\text{ kg}}{2,850\text{ kg/m}^3} = 140,350.8772\text{ m}^3 \approx 140,350.88\text{ m}^3$$

---

#### 1.2 Partitioning of Specific Cutting Energy ($E_s = dW / dV$)
The specific excavation energy $E_s$ ($\text{MJ/m}^3$) required to disintegrate a unit volume of intact rock into removable fragments of characteristic size $d_f$ is governed by the generalized energy balance:

$$E_s = \frac{1}{\eta_{\text{trans}}} \left( U_{\gamma}(d_f) + U_{\text{el}}(\sigma_{\text{fail}}) + U_{\text{pl}} + U_{\text{fric}} \right)$$

where:
* $\eta_{\text{trans}}$ is the transducer-to-substrate energy coupling efficiency,
* $U_{\gamma}(d_f) = \frac{6 \gamma_s}{d_f}$ is the Griffith surface energy required to generate new fracture surface area,
* $U_{\text{el}}(\sigma_{\text{fail}}) = \frac{\sigma_{\text{fail}}^2}{2 M_{\text{mod}}}$ is the elastic strain energy density stored prior to fracture initiation,
* $U_{\text{pl}}$ and $U_{\text{fric}}$ represent plastic deformation and frictional heat dissipation at the tool–substrate interface.

---

#### 1.3 Physical Basis of the Three Specific Energy Regimes

##### Regime A: Traditional Mechanical Percussion & Abrasion ($E_{s,\text{trad}} = 150\text{ MJ/m}^3$)
Mechanical chiseling and pick-impact load the basalt matrix predominantly in **uniaxial/triaxial compression** ($\sigma_c \approx 250\text{ MPa}$). Because the compressive-to-tensile strength ratio of basalt is $\sigma_c / \sigma_{t,0} \approx 16.7$, the stored elastic energy density required to nucleate compressive shear cones scales as $(\sigma_c / \sigma_{t,0})^2 \approx 278\times$ that of pure tensile failure. Coupled with low impact energy transfer ($\eta_{\text{trans}} \approx 0.04\text{–}0.08$) and high frictional heating ($U_{\text{fric}} > 0.85 E_{\text{in}}$), the effective specific energy settles at:

$$E_{s,\text{trad}} = 150.0\text{ MJ/m}^3 = 1.50 \times 10^8\text{ J/m}^3 \quad \left(41.67\text{ kWh/m}^3\right)$$

##### Regime B: Unconditioned Acoustic Cavitation ($E_{s,\text{cav}} = 35\text{ MJ/m}^3$)
High-intensity ultrasonic cavitation generates asymmetric bubble collapse near the basalt boundary. By the Rayleigh–Plesset and Plesset–Chapman micro-jet equations, the collapsing bubble projects a high-velocity liquid micro-jet ($v_{\text{jet}} \approx 2,167\text{ m/s}$ in high-acoustic-pressure fields) impacting the substrate with water-hammer pressure:

$$P_{\text{wh}} = \rho_l c_l v_{\text{jet}} \approx 3.25\text{ GPa} \gg \sigma_{t,0} = 15\text{ MPa}$$

Following the initial compressive spike, radial lateral outflow into surface micro-fissures induces pure **hydro-tensile wedging and lateral spallation**, bypassing compressive crushing and reducing the specific cutting energy by a factor of $30/7 \approx 4.29\times$:

$$E_{s,\text{cav}} = 35.0\text{ MJ/m}^3 = 3.50 \times 10^7\text{ J/m}^3 \quad \left(9.72\text{ kWh/m}^3\right)$$

##### Regime C: NME-Conditioned Acoustic Cavitation ($E_{s,\text{NME-cav}} = 16.8\text{ MJ/m}^3$)
From **Iteration I (Report `AS-NME-REP-01`)**, when the basalt matrix is simultaneously pre-conditioned by an ultrasonic strain field $\varepsilon_{\text{ac}} = 1.5 \times 10^{-4}$ ($\operatorname{Re}[G_{\text{eff}}]/G_0 = 0.230$, $\sigma_t^{\text{eff}} = 7.19\text{ MPa}$), the specific fracture energy scales with the degraded tensile strength ratio:

$$E_{s,\text{NME-cav}}(\varepsilon_{\text{ac}}) = E_{s,\text{cav}} \sqrt{\frac{\operatorname{Re}\left[G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)\right]}{G_0}} = 35.0\text{ MJ/m}^3 \times \sqrt{0.230} \approx 16.79\text{ MJ/m}^3$$

<div style="page-break-after: always;"></div>

---

### Page 2: Volumetric & Geometric Excavation Scaling Equations

#### 2.1 Full-Volume Comminution Energy Equations
When the entire target volume $V_{\text{exc}} = 140,350.88\text{ m}^3$ is comminuted directly into granular debris, total energy expenditure $E_{\text{tot}}$ is given by the linear volumetric integral:

$$E_{\text{tot}} = \int_{0}^{V_{\text{exc}}} E_s \, dV = V_{\text{exc}} \cdot E_s$$

1. **Traditional Mechanical Excavation Total Energy ($E_{\text{tot,trad}}$):**
   $$E_{\text{tot,trad}} = 140,350.88\text{ m}^3 \times 150\text{ MJ/m}^3 = 21,052,632.0\text{ MJ} = 21.053\text{ TJ} \quad \left(5,847.95\text{ MWh}\right)$$

2. **Acoustic Cavitation Excavation Total Energy ($E_{\text{tot,cav}}$):**
   $$E_{\text{tot,cav}} = 140,350.88\text{ m}^3 \times 35\text{ MJ/m}^3 = 4,912,280.8\text{ MJ} = 4.912\text{ TJ} \quad \left(1,364.52\text{ MWh}\right)$$

3. **NME-Conditioned Cavitation Total Energy ($E_{\text{tot,NME}}$):**
   $$E_{\text{tot,NME}} = 140,350.88\text{ m}^3 \times 16.79\text{ MJ/m}^3 = 2,356,491.3\text{ MJ} = 2.356\text{ TJ} \quad \left(654.58\text{ MWh}\right)$$

4. **Net Full-Volume Energy Savings ($\Delta E_{\text{saved}}$ & Gain Factor $\eta_{\text{gain}}$):**
   $$\Delta E_{\text{saved}} = E_{\text{tot,trad}} - E_{\text{tot,cav}} = 16.140\text{ TJ} \quad \left(4,483.43\text{ MWh}\right)$$
   $$\eta_{\text{gain,cav}} = \frac{E_{s,\text{trad}}}{E_{s,\text{cav}}} = \frac{150}{35} = 4.2857\times \quad \left(76.67\%\text{ reduction}\right)$$
   $$\eta_{\text{gain,NME}} = \frac{E_{s,\text{trad}}}{E_{s,\text{NME-cav}}} = \frac{150}{16.79} = 8.9339\times \quad \left(88.81\%\text{ reduction}\right)$$

---

#### 2.2 Kerf-Slot Acoustic Trenching & Basal Resonance Spalling (Hybrid Architecture)
In top-down monolithic architecture, pulverizing $100\%$ of the rock volume is thermodynamically unnecessary. By using focused acoustic cavitation blades/waveguides to cut narrow vertical perimeter kerf slots of width $w_k$ around prismatic blocks of side length $L_b$ and height $H_b$, and exciting the block's fundamental cantilever bending mode to spall the basal plane ($E_{s,\text{spall}} \approx 0.45\text{ MJ/m}^3$), the active cavitation volume fraction $f_{\text{kerf}}$ is:

$$f_{\text{kerf}} = \frac{V_{\text{kerf}}}{V_{\text{block}}} = 1 - \frac{(L_b - w_k)^2 (H_b - w_k)}{L_b^2 H_b} \approx \frac{2 w_k}{L_b} + \frac{w_k}{H_b}$$

The composite effective specific energy $E_{s,\text{hybrid}}$ across the monolithic volume becomes:

$$E_{s,\text{hybrid}} = f_{\text{kerf}} E_{s,\text{cav}} + \left(1 - f_{\text{kerf}}\right) E_{s,\text{spall}}$$

For a modular extraction grid with $L_b = 1.0\text{ m}$, $H_b = 1.0\text{ m}$, and acoustic kerf width $w_k = 0.025\text{ m}$ ($2.5\text{ cm}$), the kerf fraction is $f_{\text{kerf}} = 0.0731$, yielding:

$$E_{s,\text{hybrid}} = (0.0731)(35.0\text{ MJ/m}^3) + (0.9269)(0.45\text{ MJ/m}^3) = 2.559 + 0.417 = 2.976\text{ MJ/m}^3$$

$$E_{\text{tot,hybrid}} = 140,350.88\text{ m}^3 \times 2.976\text{ MJ/m}^3 = 417,684.2\text{ MJ} = 0.418\text{ TJ} \quad \left(116.02\text{ MWh}\right)$$

<div style="page-break-after: always;"></div>

---

### Page 3: Master Energy Scaling Matrix & Power-Timeline Logistics

#### 3.1 Temporal & Power Scaling Relations
Let the total active excavation window be $\Delta t_{\text{active}}$. Using a standard historical benchmark of $Y = 18\text{ years}$ at $D = 365\text{ days/yr}$ and $h_{\text{day}} = 12\text{ hours/day}$ of active operation:

$$\Delta t_{\text{active}} = 18 \times 365 \times 12 = 78,840\text{ hours} = 2.83824 \times 10^8\text{ seconds}$$

* **Required Continuous Mechanical/Acoustic Power ($P_{\text{req}}$):**
  $$P_{\text{req}} = \frac{E_{\text{tot}}}{\Delta t_{\text{active}}}$$
* **Volumetric Excavation Rate ($\dot{V}$) & Mass Excavation Rate ($\dot{M}$):**
  $$\dot{V} = \frac{V_{\text{exc}}}{\Delta t_{\text{active}}} = \frac{P_{\text{req}}}{E_s} = 1.7802\text{ m}^3/\text{hr} \quad \left(21.36\text{ m}^3/\text{day}\right)$$
  $$\dot{M} = \rho_b \dot{V} = 5.0736\text{ metric tons/hr} \quad \left(60.88\text{ metric tons/day}\right)$$

---

#### 3.2 Master Comparative Energy & Power Scaling Matrix ($V_{\text{exc}} = 140,350.88\text{ m}^3$)

| Metric / Parameter | Symbol | Unit | Regime 1: Traditional Percussion | Regime 2: Acoustic Cavitation | Regime 3: NME + Cavitation ($\varepsilon_{\text{ac}}=1.5\times 10^{-4}$) | Regime 4: Kerf-Slot Cavitation + Spall ($w_k=2.5\text{ cm}$) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Specific Cutting Energy** | $E_s$ | $\text{MJ/m}^3$ | $150.00$ | $35.00$ | $16.79$ | $2.98$ |
| **Specific Energy (Mass Basis)** | $e_m = E_s/\rho_b$ | $\text{kJ/kg}$ | $52.63$ | $12.28$ | $5.89$ | $1.04$ |
| **Specific Energy (Electrical Eq.)** | $E_{s,\text{kWh}}$ | $\text{kWh/m}^3$ | $41.67$ | $9.72$ | $4.66$ | $0.83$ |
| **Total Excavation Energy** | $E_{\text{tot}}$ | $\text{TJ}$ | $21.053$ | $4.912$ | $2.356$ | $0.418$ |
| **Total Energy (MWh Equivalent)** | $E_{\text{tot,MWh}}$ | $\text{MWh}$ | $5,847.95$ | $1,364.52$ | $654.58$ | $116.02$ |
| **Energy Reduction Factor** | $\eta_{\text{gain}}$ | $\text{ratio}$ | $1.00\times$ | $4.29\times$ | $8.93\times$ | $50.40\times$ |
| **Energy Saved vs. Traditional** | $\Delta E\%$ | $\%$ | $0.00\%$ | $76.67\%$ | $88.81\%$ | $98.02\%$ |
| **Continuous Power (18-yr / 12h/d)** | $P_{\text{req}}$ | $\text{kW}$ | $74.18\text{ kW}$ | $17.31\text{ kW}$ | $8.30\text{ kW}$ | $1.47\text{ kW}$ |
| **Power per Unit Removal Rate** | $P / \dot{V}$ | $\text{kW}/(\text{m}^3/\text{hr})$ | $41.67$ | $9.72$ | $4.66$ | $0.83$ |
| **Time at Fixed $25\text{ kW}$ Array Power** | $T_{25\text{kW}}$ | $\text{years (12h/d)}$ | $53.41\text{ yr}$ | $12.46\text{ yr}$ | $5.98\text{ yr}$ | $1.06\text{ yr}$ |

---

#### 3.3 Labor & Transducer Array Equivalence Analysis
1. **Human Manual Percussion Bottleneck (Regime 1):**
   A human laborer sustains $P_{\text{hum}} \approx 75\text{ W}$ of continuous mechanical output, but hammer-chisel impact transfer into hard basalt achieves $\eta_{\text{trans}} \approx 4\%$, delivering only $P_{\text{eff,hum}} \approx 3.0\text{ W}$ of effective rock-fracture work per worker.
   * **Workers Required for $P_{\text{req}} = 74.18\text{ kW}$ Effective Fracture Power:**
     $$N_{\text{workers}} = \frac{74,175\text{ W}}{3.0\text{ W/worker}} = 24,725\text{ simultaneous chiselers}$$
     *(Physically impossible due to spatial trench crowding constraints inside narrow perimeter galleries).*
2. **Acoustic Cavitation Waveguide Array (Regimes 2–4):**
   At $E_{s,\text{cav}} = 35\text{ MJ/m}^3$, only $17.31\text{ kW}$ of continuous acoustic cavitation power is required across the entire excavation site ($8.30\text{ kW}$ with NME softening, or $1.47\text{ kW}$ with kerf-and-spall geometry). This is achievable with $10\text{–}35$ localized acoustic horn/resonator stations operating at $500\text{ W}–1.7\text{ kW}$ each, eliminating trench-crowding constraints.
