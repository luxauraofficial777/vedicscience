# Technical Report — Iteration I
## Acoustic Softening & Effective Shear Modulus Reduction in Polymineralic Silicates
**Project:** Acoustic Sculpture, Nonlinear Mesoscopic Elasticity (NME) & Substrate Dynamics  
**Document ID:** `AS-NME-REP-01`  
**Subject:** Formal Coupling of Ultrasonic Strain Amplitude ($\varepsilon_{\text{ac}}$) and Effective Shear Modulus ($G_{\text{eff}}$)

---

### Page 1: Executive Scope & Nonlinear Mesoscopic Constitutive Law

#### 1.1 Physical Architecture of Polymineralic Silicate Matrices
Polymineralic igneous rocks—specifically tholeiitic basalt ($\rho_b \approx 2,850\text{ kg/m}^3$) and coarse-grained granite ($\rho_g \approx 2,650\text{ kg/m}^3$)—belong to the class of **Nonlinear Mesoscopic Elastic (NME)** solids. Structurally, these materials comprise a two-phase mechanical hierarchy:
1. **The Hard Elastic Skeleton:** High-modulus crystalline mineral grains (plagioclase feldspar, clinopyroxene, quartz, olivine) exhibiting linear elastic behavior up to strains of $\varepsilon \sim 10^{-3}$.
2. **The Soft Mesoscopic Bond Network:** A compliant, sub-micron percolation network of intergranular contacts, grain-boundary asperities, micro-fissures, and intracrystalline dislocation tangles occupying $<1\%$ of total rock volume but governing macroscopic nonlinear elasticity.

When excited by a high-intensity ultrasonic field of strain amplitude $\varepsilon_{\text{ac}}$ and angular frequency $\omega$, the effective dynamic shear modulus $G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)$ undergoes severe, reversible and semi-irreversible softening ("fast dynamics" and "slow dynamics").

---

#### 1.2 Preisach–Mayergoyz (PM) Space & 1D Shear Constitutive Formulation
Following the Guyer–Johnson–McCall formulation, each compliant intergranular contact is modeled as a **Hysteretic Mesoscopic Elastic Unit (HMEU)** characterized by an equilibrium closing stress $\sigma_c$ and opening stress $\sigma_o$. Under an applied shear strain $\gamma(t) = \gamma_0 + \varepsilon_{\text{ac}} \cos(\omega t)$, the macroscopic shear stress $\tau(\gamma, \dot{\gamma})$ expands as:

$$\tau(\gamma, \dot{\gamma}) = G_0 \left[ \gamma + \beta_G \gamma^2 + \delta_G \gamma^3 - \alpha_G \left( \varepsilon_{\text{ac}} \gamma + \frac{1}{2}\left(\gamma^2 - \varepsilon_{\text{ac}}^2\right)\operatorname{sgn}(\dot{\gamma}) \right) \right]$$

| Parameter | Symbol | Typical Range (Basalt/Granite) | Physical Meaning |
| :--- | :---: | :---: | :--- |
| Unperturbed Shear Modulus | $G_0$ | $25\text{–}35\text{ GPa}$ | Linear elastic shear stiffness of intact mineral skeleton |
| Quadratic Nonlinearity | $\beta_G$ | $10^2\text{–}10^3$ | Third-order Landau–Murnaghan anharmonic coefficient |
| Cubic Nonlinearity | $\delta_G$ | $-10^5\text{ to }-10^7$ | Fourth-order elastic coefficient ($\delta_G < 0$ drives cubic softening) |
| Hysteretic NME Parameter | $\alpha_G$ | $10^2\text{–}10^4$ | Density of HMEUs in Preisach–Mayergoyz $(\sigma_c, \sigma_o)$ space |
| Activation Threshold Strain | $\varepsilon_{\text{th}}$ | $10^{-7}\text{–}10^{-6}$ | Critical strain onset for intergranular micro-slip |

---

#### 1.3 Cycle-Averaged Fast-Dynamics Secant Modulus ($G_{\text{NME}}$)
Projecting $\tau(t)$ onto the fundamental Fourier component $\cos(\omega t)$ over one acoustic period $T_{\text{ac}} = 2\pi/\omega$ yields the strain-conditioned NME backbone modulus:

$$\frac{G_{\text{NME}}(\varepsilon_{\text{ac}})}{G_0} = 1 - \alpha_G \left(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}\right) H(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) + \frac{3}{4} \delta_G \varepsilon_{\text{ac}}^2$$

where $H(\cdot)$ is the Heaviside step function. Because $\delta_G < 0$ in microcracked silicates, both the non-analytic hysteretic term ($\propto \varepsilon_{\text{ac}}$) and the cubic anharmonic term ($\propto \varepsilon_{\text{ac}}^2$) act with the same negative sign to suppress shear rigidity across three distinct strain regimes:

```mermaid
flowchart LR
    R1["Regime I: Linear Elastic<br/>(ε_ac < ε_th ≈ 10⁻⁶)<br/>G_eff / G_0 ≈ 1.0"] --> R2["Regime II: HMEU Conditioning<br/>(10⁻⁶ < ε_ac < 10⁻⁴)<br/>ΔG / G_0 ∝ -α_G ε_ac"]
    R2 --> R3["Regime III: Cubic & Dislocation Collapse<br/>(ε_ac > 10⁻⁴)<br/>ΔG / G_0 ∝ -(3/4)|δ_G|ε_ac² - Φ_GL"]
```

<div style="page-break-after: always;"></div>

---

### Page 2: Dislocation Unpinning & Acoustoplastic Flow (Blaha Effect)

#### 2.1 Granato–Lücke Dislocation Breakaway Defect ($\Phi_{\text{GL}}$)
Within individual silicate mineral grains, dislocations are pinned by weak impurity point defects at average spacing $L_c$ and by strong network nodes at spacing $L_N \gg L_c$. Under oscillatory ultrasonic shear stress $\tau_{\text{ac}} = G_{\text{eff}}\varepsilon_{\text{ac}}$, bowed dislocation segments break away from weak pinning points once $\varepsilon_{\text{ac}}$ surpasses the critical breakaway strain:

$$\varepsilon_{\text{cr}} = \frac{F_m}{b G_0 L_c}$$

where $F_m$ is the maximum point-defect binding force and $b$ is the magnitude of the Burgers vector. Catastrophic loop expansion from $L_c$ to $L_N$ introduces an amplitude-dependent modulus defect $\Phi_{\text{GL}}(\varepsilon_{\text{ac}})$:

$$\Phi_{\text{GL}}(\varepsilon_{\text{ac}}) = -\frac{\Delta G_{\text{GL}}}{G_0} = \frac{\Omega \Lambda L_N^2}{\pi^2} \left(\frac{\varepsilon_{\text{cr}}}{\varepsilon_{\text{ac}}}\right) \exp\left(-\frac{\varepsilon_{\text{cr}}}{\varepsilon_{\text{ac}}}\right)$$

where $\Lambda$ is the mobile dislocation density ($\text{m}^{-2}$) and $\Omega$ is the Schmid crystallographic orientation factor.

---

#### 2.2 Thermally Activated Acoustoplasticity (Blaha–Langenecker Formulation)
When an ultrasonic shear stress $\tau_{\text{ac}} \cos(\omega t)$ is superimposed onto a quasi-static shear stress $\tau_0$, the rate of thermally activated dislocation glide and grain-boundary sliding across an energy barrier $U_0$ with activation volume $V^*$ follows the cycle-averaged Eyring–Arrhenius equation:

$$\langle \dot{\gamma}_p \rangle = \dot{\gamma}_0 \exp\left(-\frac{U_0 - V^* \tau_0}{k_B T}\right) \frac{1}{2\pi} \int_0^{2\pi} \exp\left(\frac{V^* G_{\text{eff}} \varepsilon_{\text{ac}} \cos\theta}{k_B T}\right) d\theta$$

Evaluating the integral yields the zeroth-order modified Bessel function of the first kind, $I_0(\cdot)$:

$$\langle \dot{\gamma}_p \rangle = \dot{\gamma}_0 \exp\left(-\frac{U_0 - V^* \tau_0}{k_B T}\right) I_0\left(\frac{V^* G_{\text{eff}} \varepsilon_{\text{ac}}}{k_B T}\right)$$

In the high-intensity ultrasonic limit where acoustic work per activation event exceeds thermal energy ($V^* G_{\text{eff}} \varepsilon_{\text{ac}} \gg k_B T$), substituting the asymptotic expansion $I_0(z) \simeq \frac{e^z}{\sqrt{2\pi z}}$ yields the effective reduction in macroscopic shear yield stress $\Delta \tau_y(\varepsilon_{\text{ac}})$:

$$\Delta \tau_y(\varepsilon_{\text{ac}}) = G_{\text{eff}}(\varepsilon_{\text{ac}}) \varepsilon_{\text{ac}} - \frac{k_B T}{2 V^*} \ln\left(\frac{2\pi V^* G_{\text{eff}}(\varepsilon_{\text{ac}}) \varepsilon_{\text{ac}}}{k_B T}\right)$$

> [!IMPORTANT]
> **Physical Implication:** The apparent activation energy barrier is reduced linearly by $V^* G_{\text{eff}}\varepsilon_{\text{ac}}$, enabling sub-yield intergranular slip and eliminating macroscopic tool-rock static friction via acoustic lubrication.

<div style="page-break-after: always;"></div>

---

### Page 3: Master Coupled Dispersion Equation & Fracture Threshold Degradation

#### 3.1 Master Equation for Complex Effective Shear Modulus $G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)$
Polymineralic silicates contain hetero-elastic mineral inclusions and fluid/vapor-filled micro-cavities acting as sub-wavelength local oscillators with natural frequency $\omega_0$. Coupling the strain-softened NME backbone $\mathcal{S}(\varepsilon_{\text{ac}})$ with Lorentzian metamaterial dispersion $\mathcal{D}(\varepsilon_{\text{ac}}, \omega)$ produces the master constitutive equation:

$$G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega) = G_0 \underbrace{\left[ 1 - \alpha_G (\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) H(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) - \frac{3}{4} |\delta_G| \varepsilon_{\text{ac}}^2 - \frac{\Omega \Lambda L_N^2}{\pi^2} \frac{\varepsilon_{\text{cr}}}{\varepsilon_{\text{ac}}} e^{-\varepsilon_{\text{cr}}/\varepsilon_{\text{ac}}} \right]}_{\text{Strain-Softened Backbone } \mathcal{S}(\varepsilon_{\text{ac}})} \times \underbrace{\left[ 1 - \frac{F \omega_0^2(\varepsilon_{\text{ac}})}{\omega^2 - \omega_0^2(\varepsilon_{\text{ac}}) + i \omega \Gamma(\varepsilon_{\text{ac}})} \right]}_{\text{Dynamic Metamaterial Dispersion } \mathcal{D}(\varepsilon_{\text{ac}}, \omega)}$$

where $F$ is the dipolar resonator filling fraction and the auxiliary nonlinear couplings are:
1. **Strain-Induced Resonance Downshift:**
   $$\omega_0(\varepsilon_{\text{ac}}) = \omega_{0,0} \sqrt{\mathcal{S}(\varepsilon_{\text{ac}})}$$
   Increasing $\varepsilon_{\text{ac}}$ softens the local contact stiffness, shifting $\omega_0(\varepsilon_{\text{ac}})$ downward into coincidence with the driving ultrasonic frequency $\omega$ and locking the matrix into the anomalous dispersion band ($\operatorname{Re}[G_{\text{eff}}] \to 0$, $\operatorname{Re}[K_{\text{eff}}] < 0$).
2. **Amplitude-Dependent Internal Friction ($Q^{-1}$):**
   $$\Gamma(\varepsilon_{\text{ac}}) = \omega Q^{-1}(\varepsilon_{\text{ac}}) = \omega \left[ Q_0^{-1} + \frac{4 \alpha_G}{3\pi} (\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) H(\varepsilon_{\text{ac}} - \varepsilon_{\text{th}}) \right]$$

---

#### 3.2 Griffith–Irwin Tensile Fracture Threshold Degradation ($\sigma_t^{\text{eff}}$)
For brittle intergranular microcracks of half-length $a$ and specific surface energy $\gamma_s$, the critical tensile stress required for unstable crack propagation scales directly with $\sqrt{\operatorname{Re}[G_{\text{eff}}]}$:

$$\sigma_t^{\text{eff}}(\varepsilon_{\text{ac}}, \omega) = \sqrt{\frac{4 \operatorname{Re}\left[G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)\right] \gamma_s}{\pi (1 - \nu_{\text{eff}}) a}} = \sigma_{t,0} \sqrt{\frac{\operatorname{Re}\left[G_{\text{eff}}(\varepsilon_{\text{ac}}, \omega)\right]}{G_0}}$$

#### 3.3 Parametric Benchmark Table (Tholeiitic Basalt Matrix)
Assuming baseline basalt parameters $G_0 = 30.0\text{ GPa}$, $\sigma_{t,0} = 15.0\text{ MPa}$, $\alpha_G = 2.5 \times 10^3$, $\delta_G = -4.0 \times 10^6$, and Rayleigh–Plesset micro-jet water-hammer pressure $P_{\text{wh}} = 3.25\text{ GPa}$:

| Ultrasonic Strain $\varepsilon_{\text{ac}}$ | Backbone Factor $\mathcal{S}(\varepsilon_{\text{ac}})$ | Dispersion Factor $\operatorname{Re}[\mathcal{D}]$ | Effective Shear Modulus $\operatorname{Re}[G_{\text{eff}}]$ ($\text{GPa}$) | Degraded Tensile Strength $\sigma_t^{\text{eff}}$ ($\text{MPa}$) | Overpressure Ratio $P_{\text{wh}} / \sigma_t^{\text{eff}}$ |
| :---: | :---: | :---: | :---: | :---: | :---: |
| $0$ (Unperturbed) | $1.000$ | $1.000$ | $30.00$ | $15.00$ | $216.7\times$ |
| $1.0 \times 10^{-5}$ | $0.975$ | $0.960$ | $28.08$ | $14.51$ | $224.0\times$ |
| $5.0 \times 10^{-5}$ | $0.865$ | $0.820$ | $21.28$ | $12.63$ | $257.3\times$ |
| $1.5 \times 10^{-4}$ | $0.510$ | $0.450$ | $6.89$ | $7.19$ | $452.0\times$ |
| $2.5 \times 10^{-4}$ | $0.145$ | $0.210$ | $0.91$ | $2.62$ | $1,240.5\times$ |
