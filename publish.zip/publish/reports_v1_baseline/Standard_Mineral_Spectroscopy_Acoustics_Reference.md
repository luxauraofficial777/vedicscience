# Standard Mineral Vibrational Spectroscopy, Piezoelectricity & Fluid Cavitation Reference
**Scope:** Experimentally Verified Materials Science & Classical Continuum Acoustics Reference  
**Companion Files in `C:\LuxAura\study`:**
* [`Standard_Physics_Materials_Dashboard.html`](file:///C:/LuxAura/study/Standard_Physics_Materials_Dashboard.html) — Interactive HTML5 Canvas Dashboard
* [`standard_mineral_acoustics_visualizer.py`](file:///C:/LuxAura/study/standard_mineral_acoustics_visualizer.py) — Python Numerical Generator & RK4 Solver
* [`standard_mineral_acoustics_data.json`](file:///C:/LuxAura/study/standard_mineral_acoustics_data.json) — Exported Spectral & Time-Series Dataset

---

## 1. Chemical Bond Force Constants ($k$), Reduced Atomic Mass ($\mu$), and Vibrational Frequencies
In standard molecular and solid-state chemistry, the fundamental vibrational wavenumber $\tilde{\nu}$ ($\text{cm}^{-1}$) and frequency $\nu$ ($\text{THz}$) of a diatomic bond are governed by the harmonic oscillator relation:

$$\tilde{\nu} = \frac{1}{2\pi c} \sqrt{\frac{k}{\mu}}, \qquad \mu = \frac{m_1 m_2}{m_1 + m_2}$$

where $k$ is the electromagnetic bond force constant ($\text{N/m}$), $\mu$ is the reduced atomic mass ($\text{kg}$), and $c$ is the speed of light ($\text{cm/s}$).

| Chemical Bond / Vibrational Mode | Reduced Mass $\mu$ ($\text{amu}$) | Bond Force Constant $k$ ($\text{N/m}$) | Calculated $\tilde{\nu}$ ($\text{cm}^{-1}$) | Observed RRUFF $\tilde{\nu}$ ($\text{cm}^{-1}$) | Vibrational Frequency $\nu$ ($\text{THz}$) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **$\text{Si–O}$** (Silicate Tetrahedron Stretch) | $10.193$ | $595.0$ | $995.4$ | $1,000.0$ | $29.84\text{ THz}$ |
| **$\text{Si–O–Si}$** (Symmetric Bridge Bend, $\alpha$-Quartz) | $10.193$ | $128.0$ | $461.7$ | $464.0$ | $13.84\text{ THz}$ |
| **$\text{Al–O}$** (Aluminosilicate Framework) | $10.044$ | $310.0$ | $723.8$ | $725.0$ | $21.70\text{ THz}$ |
| **$\text{Mg–O}$** (Octahedral Olivine / Pyroxene) | $9.648$ | $145.0$ | $505.1$ | $502.0$ | $15.14\text{ THz}$ |
| **$\text{Fe–O}$** (Ferrous Silicate Octahedral) | $12.436$ | $135.0$ | $429.2$ | $432.0$ | $12.87\text{ THz}$ |
| **$\text{O–H}$** (Hydroxyl Stretch in Mica / Amphibole) | $0.948$ | $730.0$ | $3,614.7$ | $3,625.0$ | $108.37\text{ THz}$ |

---

## 2. Diagnostic Raman Vibrational Peaks of Common Rock-Forming Silicates (RRUFF Database)

* **$\alpha$-Quartz ($\text{SiO}_2$):**
  * $206\text{ cm}^{-1}$ ($A_1$ lattice translation), $355\text{ cm}^{-1}$ ($A_1$ tetrahedral rotation), **$464\text{ cm}^{-1}$** (dominant $A_1$ symmetric $\text{Si–O–Si}$ bending mode), $696\text{ cm}^{-1}$, $795\text{ cm}^{-1}$, $1,085\text{ cm}^{-1}$ ($A_1$ asymmetric $\text{Si–O}$ stretch), $1,162\text{ cm}^{-1}$.
* **Plagioclase Feldspar (Labradorite / Anorthite):**
  * $285\text{ cm}^{-1}$ ($\text{Ca/Na}$ cage mode), $478\text{ cm}^{-1}$ (4-membered ring breathing), **$509\text{ cm}^{-1}$** (dominant $A_g$ $\text{T–O–T}$ symmetric bend), $565\text{ cm}^{-1}$, $764\text{ cm}^{-1}$, $988\text{ cm}^{-1}$.
* **Clinopyroxene (Augite):**
  * $324\text{ cm}^{-1}$ ($\text{M–O}$ octahedral tilt), $390\text{ cm}^{-1}$, **$666\text{ cm}^{-1}$** (chain-bridging $\text{Si–O–Si}$ stretch), **$1,010\text{ cm}^{-1}$** (non-bridging $\text{Si–O}$ stretch).
* **Forsterite Olivine ($\text{Mg}_2\text{SiO}_4$):**
  * $304\text{ cm}^{-1}$, $434\text{ cm}^{-1}$ ($\nu_2$ bend), $608\text{ cm}^{-1}$ ($\nu_4$ bend), **$824\text{ cm}^{-1}$ and $856\text{ cm}^{-1}$** (diagnostic $\text{SiO}_4$ symmetric $\nu_1$ and asymmetric $\nu_3$ stretching doublet).

---

## 3. Direct Piezoelectric Electromechanical Coupling in X-Cut $\alpha$-Quartz
In non-centrosymmetric trigonal $\alpha$-quartz (point group $32$), an applied axial stress $\sigma_{11}$ induces an electrical polarization $D_1 = d_{11} \sigma_{11}$ and open-circuit electric field $E_1 = -g_{11} \sigma_{11}$, where:
* **Piezoelectric Strain Constant ($d_{11}$):** $2.31\text{ pC/N}$
* **Relative Permittivity ($\varepsilon_{11}^T / \varepsilon_0$):** $4.52$
* **Piezoelectric Voltage Constant ($g_{11} = d_{11}/\varepsilon_{11}^T$):** $0.0577\text{ V}\cdot\text{m/N}$

| Applied Axial Stress $\sigma_{11}$ ($\text{MPa}$) | Induced Surface Charge $D_1$ ($\mu\text{C/m}^2$) | Open-Circuit Voltage Across $2.0\text{ mm}$ Plate ($\text{V}$) | Stored Electrostatic Energy Density ($\text{mJ/m}^3$) |
| :---: | :---: | :---: | :---: |
| $0.10$ | $0.231$ | $11.55\text{ V}$ | $0.667$ |
| $0.50$ | $1.155$ | $57.74\text{ V}$ | $16.670$ |
| $1.00$ | $2.310$ | $115.48\text{ V}$ | $66.679$ |
| $2.50$ | $5.775$ | $288.70\text{ V}$ | $416.742$ |
| $5.00$ | $11.550$ | $577.40\text{ V}$ | $1,666.968$ |
| $10.00$ | $23.100$ | $1,154.79\text{ V}$ | $6,667.874$ |
| $25.00$ | $57.750$ | $2,886.98\text{ V}$ | $41,674.212$ |
| $50.00$ | $115.500$ | $5,773.96\text{ V}$ | $166,696.849$ |

---

## 4. Classical Rayleigh–Plesset Ultrasonic Bubble Dynamics (Adaptive RK4)
For an equilibrium microbubble of radius $R_0 = 5.0\text{ }\mu\text{m}$ in water at $20^\circ\text{C}$ ($\rho_l = 998\text{ kg/m}^3$, $\sigma = 0.0728\text{ N/m}$, $\mu_l = 1.002\text{ mPa}\cdot\text{s}$) driven at $f = 20.0\text{ kHz}$ and $P_{\text{ac}} = 1.15\text{ bar}$:
* **Peak Expansion Ratio ($R_{\max}/R_0$):** $4.2238$ ($R_{\max} = 21.12\text{ }\mu\text{m}$)
* **Minimum Compression Ratio ($R_{\min}/R_0$):** $0.4337$ ($R_{\min} = 2.17\text{ }\mu\text{m}$)
* **Peak Radial Collapse Wall Speed ($|\dot{R}|_{\max}$):** $39.75\text{ m/s}$
