#!/usr/bin/env python3
"""
phase4_cern_iter_onion_crevice_metrics.py
Reproducible quantitative cross-reference between the Lux Aura Onion-Layer /
Breathing-Crevice Model and peer-reviewed CERN & ITER institutional project data.
"""
import json
import math
from pathlib import Path

OUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def compute_metrics():
    # 1. CERN LEP/LHC Crustal Tidal & Hydro-Crevice Geodesy
    # Sources: Arnaudon et al. (CERN-SL-94-07 / PAC 1993), Wenninger (CERN-SL-99-007-OP),
    # ETH Zurich Engineering Geology (Loew et al.), Univ. of Geneva Hydrogeology
    c_lhc_m = 26658.883  # m (exact LEP/LHC tunnel circumference)
    r_lhc_m = c_lhc_m / (2.0 * math.pi)
    alpha_c_lep = 1.86e-4  # momentum compaction factor in LEP

    # Solid-Earth tidal breathing (semi-diurnal M2/S2 peak-to-peak)
    delta_c_tidal_m = 1.0e-3  # ~1.0 mm circumference modulation
    eps_tidal_cern = delta_c_tidal_m / c_lhc_m
    delta_E_over_E_lep = -eps_tidal_cern / alpha_c_lep

    # Seasonal / Hydro-crevice pore-pressure breathing (Jura karst + Lake Geneva + Molasse aquifers)
    delta_c_hydro_m = 2.0e-3  # ~1.5 to 2.0 mm seasonal/hydrological drift
    eps_hydro_cern = delta_c_hydro_m / c_lhc_m

    # Corpus NME micro-slip threshold & E4 SG comparison
    eps_th_nme_low = 1.0e-7  # TenCate & Shankland (1996) / Task_01
    eps_th_nme_high = 1.0e-6
    e4_st026_mm_nm_s2 = 0.90  # Strasbourg Mm (27.55 d) amplitude
    e4_dj060_mm_nm_s2 = 2.41  # Djougou Mm (27.55 d) amplitude

    # 2. ITER vs. Corpus Power Density: Bulk vs. Boundary-Skin Channeling
    # Sources: ITER Organization (2018), Eich et al. (Nucl. Fusion 53, 093031, 2013 - IPP Garching/MIT),
    # Pitts et al. (Nucl. Mater. Energy 20, 100696, 2019)
    v_iter_plasma_m3 = 840.0
    p_iter_aux_mw = 73.0
    p_iter_fusion_mw = 500.0
    q_iter_bulk_aux_mw_m3 = p_iter_aux_mw / v_iter_plasma_m3
    q_iter_bulk_fus_mw_m3 = p_iter_fusion_mw / v_iter_plasma_m3

    # ITER Scrape-Off Layer (SOL) & Tungsten Divertor Strike-Point Skin
    # Power entering SOL: P_SOL ~ 100 MW channeled into lambda_q ~ 1-3 mm decay width
    q_perp_divertor_steady_mw_m2 = 10.0  # MW/m^2 steady-state design limit
    q_perp_divertor_slow_transient_mw_m2 = 20.0  # MW/m^2 slow transient (10 s)
    h_tungsten_active_skin_m = 0.005  # 5 mm active thermal gradient skin above CuCrZr cooling tube
    q_vol_divertor_steady_mw_m3 = q_perp_divertor_steady_mw_m2 / h_tungsten_active_skin_m
    q_vol_divertor_transient_mw_m3 = q_perp_divertor_slow_transient_mw_m2 / h_tungsten_active_skin_m
    iter_skin_to_bulk_concentration = q_vol_divertor_steady_mw_m3 / q_iter_bulk_fus_mw_m3

    # Corpus Ultrasonic Boundary-Skin / Kerf Conditioning
    p_array_mw = 0.025  # 25 kW
    q_hold_nme_mw_m3 = 7.2562  # at eps_ac = 1.5e-4, 21.5 kHz
    v_active_kerf_m3 = p_array_mw / q_hold_nme_mw_m3
    v_monolith_m3 = 66.10  # 188.4 t block at 2850 kg/m^3
    q_bulk_equivalent_mw_m3 = p_array_mw / v_monolith_m3
    corpus_skin_to_bulk_concentration = q_hold_nme_mw_m3 / q_bulk_equivalent_mw_m3

    # 3. ITER CICC (Cable-in-Conduit Conductor) & CERN HL-LHC Nb3Sn Interfacial Mechanics
    # Sources: Nijhuis et al. (Univ. Twente, Supercond. Sci. Technol. 2006/2013),
    # Devred et al. (ITER IO, 2014), Marchevsky et al. (LBNL / US-MDP, 2021)
    i_iter_tf_ka = 68.0
    b_iter_tf_t = 11.8
    f_lorentz_iter_kn_m = i_iter_tf_ka * b_iter_tf_t  # 802.4 kN/m
    phi_void_iter_cicc = 0.326  # 32.6% supercritical He void fraction in CS/TF CICC
    eps_irr_nb3sn = 2.8e-3  # 0.28% irreversible strain threshold for Nb3Sn filament cracking

    # CERN HL-LHC MQXF (11.4 T Nb3Sn quadrupole at T = 1.9 K He-II)
    t_hllhc_k = 1.90
    kb_eV_K = 8.617333262e-5
    thermal_energy_1p9K_meV = kb_eV_K * t_hllhc_k * 1e3  # 0.1637 meV
    # Acoustic emission burst during epoxy-conductor interfacial micro-slip (10-100 um crevice)
    e_slip_density_j_m3 = 5.0e3  # 5 mJ/cm^3 = 5,000 J/m^3 localized epoxy debond release
    tau_burst_s = 100.0e-6  # 100 us ultrasonic burst (f ~ 20-300 kHz)
    q_dot_epoxy_slip_mw_m3 = (e_slip_density_j_m3 / tau_burst_s) / 1e6  # 50 MW/m^3

    # 4. ITER H-Mode Edge Transport Barrier (ETB) vs. Corpus Stokes-Kirchhoff Boundary Layer
    a_iter_minor_m = 2.00
    delta_r_etb_m = 0.04  # 4 cm H-mode pedestal width
    etb_radius_fraction = delta_r_etb_m / a_iter_minor_m  # 2.0% of minor radius
    # Toroidal surface area of ITER plasma ~ 678 m^2 -> ETB shell volume:
    s_iter_plasma_m2 = 678.0
    v_iter_etb_shell_m3 = s_iter_plasma_m2 * delta_r_etb_m

    results = {
        "cern_geodesy_breathing_crevice": {
            "c_lhc_m": c_lhc_m,
            "r_lhc_m": round(r_lhc_m, 3),
            "delta_c_tidal_mm": 1.0,
            "eps_tidal_cern": round(eps_tidal_cern, 10),
            "delta_E_over_E_lep": round(delta_E_over_E_lep, 6),
            "delta_c_hydro_mm": 2.0,
            "eps_hydro_cern": round(eps_hydro_cern, 10),
            "eps_th_nme_range": [eps_th_nme_low, eps_th_nme_high],
            "ratio_hydro_strain_to_nme_threshold": round(eps_hydro_cern / eps_th_nme_low, 3),
            "e4_st026_mm_nm_s2": e4_st026_mm_nm_s2,
            "e4_dj060_mm_nm_s2": e4_dj060_mm_nm_s2,
        },
        "iter_vs_corpus_skin_power_channeling": {
            "q_iter_bulk_aux_mw_m3": round(q_iter_bulk_aux_mw_m3, 4),
            "q_iter_bulk_fus_mw_m3": round(q_iter_bulk_fus_mw_m3, 4),
            "q_vol_divertor_steady_mw_m3": round(q_vol_divertor_steady_mw_m3, 1),
            "q_vol_divertor_transient_mw_m3": round(q_vol_divertor_transient_mw_m3, 1),
            "iter_skin_to_bulk_concentration": round(iter_skin_to_bulk_concentration, 1),
            "q_hold_nme_mw_m3": q_hold_nme_mw_m3,
            "v_active_kerf_L": round(v_active_kerf_m3 * 1000.0, 3),
            "q_bulk_equivalent_mw_m3": round(q_bulk_equivalent_mw_m3, 6),
            "corpus_skin_to_bulk_concentration": round(corpus_skin_to_bulk_concentration, 1),
        },
        "iter_cicc_and_cern_hllhc_crevice_mechanics": {
            "f_lorentz_iter_kn_m": round(f_lorentz_iter_kn_m, 2),
            "phi_void_iter_cicc_pct": round(phi_void_iter_cicc * 100.0, 1),
            "eps_irr_nb3sn": eps_irr_nb3sn,
            "t_hllhc_k": t_hllhc_k,
            "thermal_energy_1p9K_meV": round(thermal_energy_1p9K_meV, 4),
            "q_dot_epoxy_slip_mw_m3": round(q_dot_epoxy_slip_mw_m3, 1),
        },
        "iter_etb_pedestal_vs_corpus_boundary_skin": {
            "a_iter_minor_m": a_iter_minor_m,
            "delta_r_etb_cm": delta_r_etb_m * 100.0,
            "etb_radius_fraction_pct": round(etb_radius_fraction * 100.0, 2),
            "v_iter_etb_shell_m3": round(v_iter_etb_shell_m3, 2),
            "v_iter_etb_volume_fraction_pct": round((v_iter_etb_shell_m3 / v_iter_plasma_m3) * 100.0, 2),
        },
    }

    out_path = OUT_DIR / "cern_iter_onion_crevice_metrics.json"
    out_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"Saved metrics to {out_path}")
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    compute_metrics()
