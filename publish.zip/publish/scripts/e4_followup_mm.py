import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

import e4_lunar_residual_search as e4

OUT = Path(__file__).resolve().parent / "e4_followup_mm_output.json"

PERIODS = {
    "lunar_anomalistic_Mm": 27.554549,
    "lunar_tropical_control": 27.212221,
    "lunar_synodic": 29.530588,
    "noise_control_21p3d": 21.3,
}

STATION_SPANS = {
    "st026": {
        "chunk_days": 365.25,
        "chunks": [
            ("2011-01", "2011-12"),
            ("2012-01", "2012-12"),
            ("2013-01", "2013-12"),
            ("2014-01", "2014-12"),
            ("2015-01", "2015-12"),
            ("2016-01", "2016-12"),
            ("2017-01", "2017-12"),
            ("2018-01", "2018-11"),
        ],
    },
    "dj060": {
        "chunk_days": 182.625,
        "chunks": [
            ("2016-01", "2016-06"),
            ("2016-07", "2016-12"),
            ("2017-01", "2017-06"),
            ("2017-07", "2017-12"),
            ("2018-01", "2018-06"),
            ("2018-07", "2018-12"),
        ],
    },
}


def load_station(sta):
    paths = sorted((e4.CACHE / sta).glob("*.ggp"))
    t_h, v, t0 = e4.parse_l3([str(p) for p in paths])
    t_d, vv = e4.hourly_mean(t_h, v)
    resid, _ = e4.detrend_hourly(t_d, vv)
    return t_d, resid, t0


def single_fit(t, r, per):
    n = len(t)
    f = 1.0 / per
    A = np.column_stack(
        [np.ones(n), t - t.mean(), np.sin(2 * np.pi * f * t), np.cos(2 * np.pi * f * t)]
    )
    beta, *_ = np.linalg.lstsq(A, r, rcond=None)
    resid = r - A @ beta
    dof = max(n - 4, 1)
    s2 = float(resid @ resid) / dof
    cov = s2 * np.linalg.pinv(A.T @ A)
    a, b = beta[2], beta[3]
    amp = math.hypot(a, b)
    var_amp = (a * a * cov[2, 2] + b * b * cov[3, 3] + 2 * a * b * cov[2, 3]) / max(
        amp * amp, 1e-30
    )
    sig = math.sqrt(max(var_amp, 0.0))
    phase = math.degrees(math.atan2(-b, a)) % 360.0
    return amp, sig, phase


def local_continuum(t, r, f0, halfwidth=0.004, oversample=12):
    span = t.max() - t.min()
    df = 1.0 / (oversample * span)
    fs = np.arange(f0 - halfwidth, f0 + halfwidth, df)
    powers = []
    resid_norm = r @ r
    n = len(t)
    for f in fs:
        w = 2 * np.pi * f
        wt = w * t
        tau = np.arctan2(np.sum(np.sin(2 * wt)), np.sum(np.cos(2 * wt))) / (2 * w)
        cw = np.cos(w * t - tau)
        sw = np.sin(w * t - tau)
        c2 = 2.0 * np.sum(cw * cw)
        powers.append(
            (((r @ cw) ** 2 + (r @ sw) ** 2) / c2) / max(resid_norm, 1e-30) * n
        )
    return float(np.median(powers)), int(len(fs))


def circ_stats(phases_deg, amps):
    z = np.array(
        [a * np.exp(1j * np.radians(p)) for a, p in zip(amps, phases_deg)],
        dtype=np.complex128,
    )
    mean_vec = z.mean()
    r_bar = abs(mean_vec) / max(np.mean(amps), 1e-30)
    return {
        "mean_amp_nms2": round(float(np.mean(amps)), 4),
        "mean_phase_deg": round(float(math.degrees(math.atan2(mean_vec.imag, mean_vec.real)) % 360.0), 2),
        "phase_concentration_R": round(float(r_bar), 4),
        "vector_mean_amp_nms2": round(float(abs(mean_vec)), 4),
    }


def main():
    results = {}
    for sta, cfg in STATION_SPANS.items():
        t, r, t0 = load_station(sta)
        station_out = {"span_d": round(float(t.max() - t.min()), 2), "n_hourly": int(len(t))}
        for name, per in PERIODS.items():
            amp_full, sig_full, ph_full = single_fit(t, r, per)
            f0 = 1.0 / per
            cont, nfreq = local_continuum(t, r, f0)
            red_snr = amp_full / max(sig_full * math.sqrt(cont), 1e-30)
            chunk_rows = []
            for (a_ym, b_ym) in cfg["chunks"]:
                a0 = e4.month_to_day(a_ym) - t0
                a1 = e4.month_to_day(b_ym) + 31 - t0
                m = (t >= a0) & (t < a1)
                if m.sum() < 500:
                    continue
                amp, sig, ph = single_fit(t[m], r[m], per)
                chunk_rows.append(
                    {
                        "window": a_ym + "_" + b_ym,
                        "n": int(m.sum()),
                        "amp_nms2": round(amp, 4),
                        "sigma_nms2": round(sig, 4),
                        "snr": round(amp / sig, 2) if sig > 0 else None,
                        "phase_deg": round(ph, 1),
                    }
                )
            phases = [c["phase_deg"] for c in chunk_rows]
            amps = [c["amp_nms2"] for c in chunk_rows]
            sigs = [c["sigma_nms2"] for c in chunk_rows]
            cs = circ_stats(phases, amps) if chunk_rows else None
            amp_chi2 = float(
                sum((a / s) ** 2 for a, s in zip(amps, sigs) if s > 0)
            ) if sigs else None
            station_out[name] = {
                "period_d": per,
                "full_record": {
                    "amp_nms2": round(amp_full, 4),
                    "sigma_white_nms2": round(sig_full, 4),
                    "snr_white": round(amp_full / sig_full, 2),
                    "phase_deg": round(ph_full, 1),
                    "local_continuum_power": round(cont, 4),
                    "n_continuum_freqs": nfreq,
                    "snr_red_noise_corrected": round(red_snr, 3),
                },
                "per_chunk": chunk_rows,
                "chunk_circ_stats": cs,
                "chunk_amp_chi2_vs_white": round(amp_chi2, 2) if amp_chi2 is not None else None,
                "chunk_amp_chi2_dof": len(chunk_rows),
            }
        results[sta] = station_out

    cross = {}
    for name, per in PERIODS.items():
        fa = results["st026"][name]["full_record"]
        fb = results["dj060"][name]["full_record"]
        dphi = abs(fa["phase_deg"] - fb["phase_deg"])
        dphi = min(dphi, 360.0 - dphi)
        cross[name] = {
            "st026_amp": fa["amp_nms2"],
            "st026_phase": fa["phase_deg"],
            "dj060_amp": fb["amp_nms2"],
            "dj060_phase": fb["phase_deg"],
            "dphase_deg": round(dphi, 1),
            "phase_coherent_60deg": bool(dphi <= 60.0),
        }

    payload = {
        "experiment": "E4b",
        "title": "Post-hoc characterisation of the Mm-period marginal detection (E4 follow-up)",
        "status": "POST_HOC",
        "motivation": (
            "E4 pre-registered analysis found a single marginal amplitude at the "
            "anomalistic month (Mm, 27.55 d) with white-noise SNR 5.0 at st026 that "
            "failed both pre-registered coherence tests. This follow-up tests phase "
            "stability per sub-window, cross-station single-frequency coherence, and "
            "re-estimates significance against the red (coloured) noise continuum."
        ),
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "method": {
            "fit": "single-frequency least squares (mean, linear drift, sin/cos at target)",
            "chunks": {k: v["chunk_days"] for k, v in STATION_SPANS.items()},
            "red_noise": "SNR recomputed with sigma scaled by sqrt of local LS continuum power (+/-0.004 c/d)",
            "circ_stats": "R = |mean(amp*exp(i*phase))| / mean(amp); R~1 stable phase, R~0 random",
        },
        "stations": results,
        "cross_station": cross,
    }
    OUT.write_text(json.dumps(payload, indent=1), encoding="utf-8")
    print("written:", OUT)
    for sta in results:
        mm = results[sta]["lunar_anomalistic_Mm"]
        fr = mm["full_record"]
        cs = mm["chunk_circ_stats"]
        print(
            "%s Mm: amp=%.3f snr_white=%.2f snr_red=%.2f phase=%.1f  chunks R=%s meanPhase=%s chi2=%s/%s"
            % (
                sta,
                fr["amp_nms2"],
                fr["snr_white"],
                fr["snr_red_noise_corrected"],
                fr["phase_deg"],
                cs["phase_concentration_R"] if cs else None,
                cs["mean_phase_deg"] if cs else None,
                mm["chunk_amp_chi2_vs_white"],
                mm["chunk_amp_chi2_dof"],
            )
        )
    for name, c in cross.items():
        print(
            "cross %-24s dphase=%6.1f coherent=%s (amps %.3f/%.3f)"
            % (name, c["dphase_deg"], c["phase_coherent_60deg"], c["st026_amp"], c["dj060_amp"])
        )


if __name__ == "__main__":
    main()
