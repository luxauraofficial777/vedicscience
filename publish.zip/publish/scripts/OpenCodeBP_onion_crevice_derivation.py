#!/usr/bin/env python3
"""
onion_crevice_derivation.py — Deterministic derivations for the Onion-Layer /
Breathing-Crevice reinterpretation pass (Big Pickle workspace, SPH-01 stream).

Seed 20261018. No network. All outputs %.6g, LF line endings.
Computes:
  1. Volumetric NME holding-power budget at the corpus operating point
     (re-derived from primitives, not copied).
  2. Active-volume -> interfacial-area leverage table across crevice scales.
  3. Stokes viscous skin depth at the anomalistic-month (Mm) tidal period,
     in air and in water-saturated fracture fluid, scaled from the corpus's
     verified 34.4 Hz benchmark.
  4. E4b Mm-vs-control discrimination statistics parsed from the archived
     e4_followup_mm_output.json (amplitude ratios, phase concentration,
     cross-station deltas).
  5. Order-of-magnitude tidal strain vs NME activation threshold window.
"""
import json
import math
import os

SEED = 20261018
G = 6.67430e-11  # CODATA, for order-of-magnitude checks only

# --- Corpus primitives (COMMAND-verified in HARDENING-01) -------------------
F0_HZ = 21_500.0          # Master operating frequency
G0_PA = 30.0e9            # basalt backbone shear modulus
ALPHA_G = 2.5e3           # hysteretic NME parameter (Task_01:109 benchmark)
EPS_AC = 1.5e-4           # operating strain
P_ARRAY_W = 25_000.0      # corpus-wide assumed array power
DELTA_BL_34HZ_M = 0.552e-3  # verified effective BL thickness at 34.4 Hz, air
DELTA_V_34HZ_M = 0.375e-3   # verified viscous BL thickness at 34.4 Hz, air
F_BENCH_HZ = 34.4
NU_AIR = 1.516e-5         # Task_03:38
NU_WATER_20C = 1.00e-6    # standard value at 20 degC (ASSUMPTION, stated)
MM_PERIOD_D = 27.554549
TROP_PERIOD_D = 27.212221
SYN_PERIOD_D = 29.530588
NOISE_CTRL_PERIOD_D = 21.3

# --- 1. Holding-power density (re-derivation) -------------------------------
omega = 2.0 * math.pi * F0_HZ
q_inv = 4.0 * ALPHA_G * EPS_AC / (3.0 * math.pi)          # Master:229 form
qdot = 0.5 * omega * G0_PA * EPS_AC**2 * q_inv            # W/m^3
v_active = P_ARRAY_W / qdot                                # m^3

# --- 2. Skin-area leverage --------------------------------------------------
skin_mm = [151.0, 10.0, 1.104, 0.1, 0.022, 0.001]
skin_labels = [
    "bulk_isotropic_cube",
    "macro_kerf_10mm",
    "stokes_bl_34Hz_2delta",
    "foliated_parting_seam_100um",
    "ultrasonic_skin_22um",
    "intergranular_bond_1um",
]
leverage = []
for h_mm, lab in zip(skin_mm, skin_labels):
    h = h_mm / 1000.0
    area = v_active / h
    side = math.sqrt(area)
    leverage.append({
        "label": lab, "h_skin_mm": h_mm, "A_skin_m2": area,
        "equiv_square_side_m": side,
    })

# --- 3. Tidal-period Stokes skin depth -------------------------------------
f_mm = 1.0 / (MM_PERIOD_D * 86400.0)                      # Hz
delta_v_air_mm = math.sqrt(2.0 * NU_AIR / (2.0 * math.pi * f_mm))
delta_v_water_m = math.sqrt(2.0 * NU_WATER_20C / (2.0 * math.pi * f_mm))
# consistency check vs corpus 34.4 Hz water value would need the fluid's
# own delta; instead verify air scaling reproduces delta_v_34Hz:
delta_v_air_check = math.sqrt(2.0 * NU_AIR / (2.0 * math.pi * F_BENCH_HZ))

# --- 4. E4b statistics ------------------------------------------------------
e4_path = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "..", "e4_followup_mm_output.json")
e4_path = os.path.normpath(e4_path)
with open(e4_path, "r", encoding="utf-8") as fh:
    e4 = json.load(fh)

def band(sta, key):
    b = e4["stations"][sta][key]["full_record"]
    circ = e4["stations"][sta][key]["chunk_circ_stats"]
    return {
        "amp_nms2": b["amp_nms2"],
        "snr_red": b["snr_red_noise_corrected"],
        "phase_deg": b["phase_deg"],
        "phase_concentration_R": circ["phase_concentration_R"],
    }

stats = {}
for sta in ("st026", "dj060"):
    mm = band(sta, "lunar_anomalistic_Mm")
    tr = band(sta, "lunar_tropical_control")
    sy = band(sta, "lunar_synodic")
    nc = band(sta, "noise_control_21p3d")
    stats[sta] = {
        "Mm": mm, "tropical": tr, "synodic": sy, "noise_control": nc,
        "ratio_Mm_over_tropical_amp": mm["amp_nms2"] / tr["amp_nms2"],
        "ratio_Mm_over_control_amp": mm["amp_nms2"] / nc["amp_nms2"],
        "ratio_R_Mm_over_tropical": (mm["phase_concentration_R"]
                                     / tr["phase_concentration_R"]),
        "Mm_amp_chi2_dof": e4["stations"][sta]["lunar_anomalistic_Mm"]
            ["chunk_amp_chi2_dof"],
        "Mm_amp_chi2": e4["stations"][sta]["lunar_anomalistic_Mm"]
            ["chunk_amp_chi2_vs_white"],
    }
xstation = e4["cross_station"]
amp_ratio_dj_st = (xstation["lunar_anomalistic_Mm"]["dj060_amp"]
                   / xstation["lunar_anomalistic_Mm"]["st026_amp"])

# --- 5. Tidal strain vs NME threshold --------------------------------------
# Order-of-magnitude: equilibrium body-tide vertical displacement u ~ 0.1-0.3 m
# (standard solid-Earth tide; ASSUMPTION stated, not re-fetched).
U_TIDE_M = 0.2
eps_tidal = 2.0 * U_TIDE_M / 6.371e6     # ~ u/R strain scale
eps_th_lo, eps_th_hi = 1e-7, 1e-6        # Task_01:31 activation window

out = {
    "seed": SEED,
    "derivation": "onion_crevice_derivation.py",
    "holding_power": {
        "omega_rad_s": omega, "Qinv": q_inv, "qdot_W_m3": qdot,
        "V_active_m3": v_active, "V_active_L": v_active * 1000.0,
        "docket_crosscheck_W_m3": 7.26e6,
        "rel_diff_vs_docket": (qdot - 7.26e6) / 7.26e6,
    },
    "skin_leverage": leverage,
    "mm_period_skin_depth": {
        "f_mm_Hz": f_mm,
        "delta_v_air_m": delta_v_air_mm,
        "delta_v_water_20C_m": delta_v_water_m,
        "air_scaling_check_34p4Hz_m": delta_v_air_check,
        "corpus_delta_v_34Hz_m": DELTA_V_34HZ_M,
    },
    "e4b_discrimination": {
        "stations": stats,
        "cross_station_Mm": xstation["lunar_anomalistic_Mm"],
        "amp_ratio_dj060_over_st026_Mm": amp_ratio_dj_st,
    },
    "tidal_strain_vs_threshold": {
        "u_tide_m_ASSUMED": U_TIDE_M,
        "eps_tidal_estimate": eps_tidal,
        "NME_eps_th_window": [eps_th_lo, eps_th_hi],
        "tidal_reaches_threshold": eps_tidal >= eps_th_lo,
        "note": ("Order-of-magnitude only. PM-model hysteresis is "
                 "rate-independent by construction, which would transfer the "
                 "ultrasonic eps_th to tidal rates; real creep/rate-"
                 "dependence is the open counter-argument (R5 both sides)."),
    },
}

out_path = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "outputs", "onion_crevice_derived.json")
out_path = os.path.normpath(out_path)
with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
    json.dump(out, fh, indent=1, sort_keys=True, ensure_ascii=False)
    fh.write("\n")

print(f"qdot = {qdot:.6g} W/m^3 (docket 7.26e6, rel {out['holding_power']['rel_diff_vs_docket']:.3%})")
print(f"V_active = {v_active*1e3:.6g} L")
print(f"delta_v(Mm) air = {delta_v_air_mm:.6g} m, water = {delta_v_water_m:.6g} m")
print(f"amp ratio dj060/st026 (Mm) = {amp_ratio_dj_st:.6g}")
for sta in ("st026", "dj060"):
    s = stats[sta]
    print(f"{sta}: Mm/trop amp = {s['ratio_Mm_over_tropical_amp']:.6g}, "
          f"R_Mm/R_trop = {s['ratio_R_Mm_over_tropical']:.6g}, "
          f"R_Mm = {s['Mm']['phase_concentration_R']:.6g}")
print(f"eps_tidal ~ {eps_tidal:.6g} vs eps_th [{eps_th_lo:g},{eps_th_hi:g}]")
print(f"wrote {out_path}")
