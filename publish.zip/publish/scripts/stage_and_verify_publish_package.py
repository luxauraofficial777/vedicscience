#!/usr/bin/env python3
"""
stage_and_verify_publish_package.py
Organizes, checks SHA-256 hash integrity for, and stages all final .md/.html files,
scripts, CSV/JSON/JSONL manifests, and image assets (/img/ + analytical charts)
into C:\\LuxAura\\study\\publish\\ with a final verified MANIFEST.sha256 and
PUBLISH_MANIFEST.json. Also updates hardening_SPH01/outputs/MANIFEST.sha256 so all
post-verification files are cryptographically pinned.
"""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

STUDY_ROOT = Path(r"C:\LuxAura\study")
SPH01_ROOT = STUDY_ROOT / "hardening_SPH01"
PUBLISH_ROOT = STUDY_ROOT / "publish"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_and_verify(src: Path, dst: Path) -> dict:
    if not src.exists():
        raise FileNotFoundError(f"Missing source file: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    src_hash = sha256_file(src)
    shutil.copy2(src, dst)
    dst_hash = sha256_file(dst)
    if src_hash != dst_hash:
        raise ValueError(f"Hash mismatch copying {src} -> {dst}: {src_hash} != {dst_hash}")
    return {
        "rel_publish_path": dst.relative_to(PUBLISH_ROOT).as_posix(),
        "source_path": src.relative_to(STUDY_ROOT).as_posix(),
        "size_bytes": dst.stat().st_size,
        "sha256": dst_hash,
    }


def update_sph01_manifest():
    """Ensure all files in hardening_SPH01 (including post-verification additions) are hashed."""
    manifest_path = SPH01_ROOT / "outputs" / "MANIFEST.sha256"
    files_to_hash = []
    for p in sorted(SPH01_ROOT.rglob("*")):
        if p.is_file() and p.name != "MANIFEST.sha256" and "__pycache__" not in p.parts:
            files_to_hash.append(p)
    lines = []
    for p in files_to_hash:
        rel = p.relative_to(SPH01_ROOT).as_posix()
        lines.append(f"{sha256_file(p)}  {rel}")
    manifest_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


def build_publish_readme(staged_records: list, sph01_count: int) -> str:
    total_bytes = sum(r["size_bytes"] for r in staged_records)
    return f"""# LUX AURA STUDY CORPUS — PUBLICATION RELEASE PACKAGE (`/study/publish/`)
**Package ID:** `LUXAURA-PUBLISH-SPH01-FINAL`  
**Generated:** `2026-10-18`  
**Total Staged & Hash-Verified Assets:** `{len(staged_records) + 2}` files (`{total_bytes:,}` bytes payload + `MANIFEST.sha256` & `PUBLISH_MANIFEST.json`)  
**Upstream `hardening_SPH01` Manifest Entries:** `{sph01_count}` verified files  
**License:** Creative Commons Attribution-NonCommercial 4.0 International (`CC BY-NC 4.0` — see [`LICENSE`](LICENSE))

---

## 1. Executive Entry Points (Start Here)

1. **[`FINAL_MASTER_ANALYSIS_ARGON.md`](FINAL_MASTER_ANALYSIS_ARGON.md)** — **Deliverable 1 (Master Technical Consolidation):** Complete unified synthesis across Spectral Bands **Q** (Quantum & Constants), **CE** (Chemical & Electrical), and **V** (Vibrational Continuum), integrating the **Onion-Layer / Breathing-Crevice Architecture**, the **CERN & ITER Institutional Correlation**, and all parallel agent tracks (**Claude/Fable**, **Big Pickle/OpenCodeBP**, and **Beam/opencode `VPDR-01` & `BGCDR-01`**), complete with the **Superseded Values Registry** and experimental roadmap.
2. **[`PUBLIC_REFLECTION_ARGON.md`](PUBLIC_REFLECTION_ARGON.md)** — **Deliverable 2 (Public Reflection & Whitepaper Summary):** Public-facing whitepaper framing the Mandate of Sound Logic, the transition from "dead-rock" textbook assumptions to multi-tier breathing interfaces, "Same Spec, Different Compiler" across planetary atmospheres and cellular mechanobiology, and five open-source experiments ready for bench replication.
3. **[`FINAL_MASTER_ANALYSIS.md`](FINAL_MASTER_ANALYSIS.md)** — **Claude (`Fable`) Layer 7 Master Analysis:** Independent synthesis of the 56-claim SVD verification matrix, institutional metrological fallacies (including the $550\\text{{ ppm}}$ spread in Newton's $G$), and methodological audit.
4. **[`THEOREM_DOCKET.md`](THEOREM_DOCKET.md)** · **[`HARDENING_REPORT.md`](HARDENING_REPORT.md)** · **[`IDEAS_RESEARCH_BRIEF.md`](IDEAS_RESEARCH_BRIEF.md)** · **[`ASTRA_COMPARATIVE_BRIEF.md`](ASTRA_COMPARATIVE_BRIEF.md)** · **[`WORK_OFFLOAD_DIRECTIVE_SPH01.md`](WORK_OFFLOAD_DIRECTIVE_SPH01.md)** — Core governance, axiomatization (`A1`–`A4`), and pre-registered audit directives.

---

## 2. Directory Layout of `/study/publish/`

```text
publish/
├── README.md                                  # This master publication index
├── FINAL_MASTER_ANALYSIS_ARGON.md             # Deliverable 1: Argon Master Consolidation
├── PUBLIC_REFLECTION_ARGON.md                 # Deliverable 2: Public Whitepaper Summary
├── FINAL_MASTER_ANALYSIS.md                   # Claude Layer 7 Master Analysis
├── THEOREM_DOCKET.md                          # Axioms A1-A4, Constraints E-1..E-14 & E4 Record
├── HARDENING_REPORT.md                        # Seed Audit Findings C1-C4 & M1-M8
├── IDEAS_RESEARCH_BRIEF.md                    # Ideas 1-7 Literature & Bench Protocols D1-D7
├── ASTRA_COMPARATIVE_BRIEF.md                 # BORI/Ganguli Sanskrit Astra Audit
├── WORK_OFFLOAD_DIRECTIVE_SPH01.md            # Directive SPH-01 (Rules R1-R10, Phases 0-5)
├── LICENSE                                    # CC BY-NC 4.0 License
├── TOC.md                                     # Original Corpus Table of Contents
├── README_v1_root.md                          # Original Root Repository README
├── MANIFEST.sha256                            # Master SHA-256 Checksum File (100% Verified)
├── PUBLISH_MANIFEST.json                      # Machine-Readable Provenance & Hash Map
├── reports_v2/                                # All Hardened Band, Synthesis & Deep-Research Reports
│   ├── PREREG.md, BAND_Q_QUANTUM.md, BAND_CE_CHEM_ELEC.md, BAND_V_VIBRATIONAL.md
│   ├── SPECTRUM_LEDGER.md, VEDIC_CONCORDANCE.md, CROSS_BAND_VERDICT_MATRIX.md
│   ├── BIG_SCIENCE_CORRELATION.md, GOVERNANCE_BENCHMARK.md
│   ├── ONION_LAYER_BREATHING_CREVICE_SYNTHESIS.md, CERN_ITER_ONION_CREVICE_CORRELATION.md
│   ├── Task_01_v2.md, Task_02_v2.md, Task_04_v2.md, Standard_Dislocation_Tunneling_Reference_v2.md
│   ├── DEFERRALS.md, CHANGELOG.md, VERIFICATION_REPORT.md
│   ├── OpenCodeBP_PREREG.md, OpenCodeBP_ONION_CREVICE_SYNTHESIS.md
│   ├── VPDR-01.md, VERIFICATION_REPORT_VPDR.md, RESEARCH_NOTES_VPDR.md
│   ├── BGCDR-01.md, VERIFICATION_REPORT_BIO.md, RESEARCH_NOTES_BIO.md
│   └── VERIFICATION_MATRIX_REPORT.md, verification_matrix_01.html
├── reports_v1_baseline/                       # Read-Only Baseline v1 Markdown & Substack HTMLs (R2)
├── data_and_manifests/                        # All CSV Ledgers, JSON Metrics & JSONL Registries
├── scripts/                                   # All Reproducible Python/C++ Simulation & Audit Scripts
└── img/                                       # All 17 Original Schematic JPGs + 14 Analytical Charts (PNG/SVG)
```

---

## 3. Cryptographic Verification Command

To verify the byte-for-byte integrity of every file in this publication package from PowerShell or Bash:

```powershell
# PowerShell verification:
Get-Content MANIFEST.sha256 | ForEach-Object {{
    $parts = $_ -split "  ", 2
    $actual = (Get-FileHash -Algorithm SHA256 $parts[1]).Hash.ToLower()
    if ($actual -ne $parts[0]) {{ Write-Error "MISMATCH: $($parts[1])" }}
}}
Write-Host "ALL FILES IN MANIFEST.sha256 VERIFIED 100% PASS"
```
"""


def main():
    if PUBLISH_ROOT.exists():
        shutil.rmtree(PUBLISH_ROOT)
    PUBLISH_ROOT.mkdir(parents=True, exist_ok=True)

    # First update hardening_SPH01/outputs/MANIFEST.sha256 so all post-verification files are included
    sph01_count = update_sph01_manifest()

    # Define staging map: (source_path_relative_to_STUDY_ROOT, dest_path_relative_to_PUBLISH_ROOT)
    staging_plan = [
        # Root Master & Governance Documents
        ("FINAL_MASTER_ANALYSIS_ARGON.md", "FINAL_MASTER_ANALYSIS_ARGON.md"),
        ("PUBLIC_REFLECTION_ARGON.md", "PUBLIC_REFLECTION_ARGON.md"),
        ("FINAL_MASTER_ANALYSIS.md", "FINAL_MASTER_ANALYSIS.md"),
        ("THEOREM_DOCKET.md", "THEOREM_DOCKET.md"),
        ("HARDENING_REPORT.md", "HARDENING_REPORT.md"),
        ("IDEAS_RESEARCH_BRIEF.md", "IDEAS_RESEARCH_BRIEF.md"),
        ("ASTRA_COMPARATIVE_BRIEF.md", "ASTRA_COMPARATIVE_BRIEF.md"),
        ("WORK_OFFLOAD_DIRECTIVE_SPH01.md", "WORK_OFFLOAD_DIRECTIVE_SPH01.md"),
        ("LICENSE", "LICENSE"),
        ("TOC.md", "TOC.md"),
        ("README.md", "README_v1_root.md"),

        # Hardened Reports & Deep Research (reports_v2/)
        ("hardening_SPH01/PREREG.md", "reports_v2/PREREG.md"),
        ("hardening_SPH01/BAND_Q_QUANTUM.md", "reports_v2/BAND_Q_QUANTUM.md"),
        ("hardening_SPH01/BAND_CE_CHEM_ELEC.md", "reports_v2/BAND_CE_CHEM_ELEC.md"),
        ("hardening_SPH01/BAND_V_VIBRATIONAL.md", "reports_v2/BAND_V_VIBRATIONAL.md"),
        ("hardening_SPH01/SPECTRUM_LEDGER.md", "reports_v2/SPECTRUM_LEDGER.md"),
        ("hardening_SPH01/VEDIC_CONCORDANCE.md", "reports_v2/VEDIC_CONCORDANCE.md"),
        ("hardening_SPH01/CROSS_BAND_VERDICT_MATRIX.md", "reports_v2/CROSS_BAND_VERDICT_MATRIX.md"),
        ("hardening_SPH01/BIG_SCIENCE_CORRELATION.md", "reports_v2/BIG_SCIENCE_CORRELATION.md"),
        ("hardening_SPH01/GOVERNANCE_BENCHMARK.md", "reports_v2/GOVERNANCE_BENCHMARK.md"),
        ("hardening_SPH01/ONION_LAYER_BREATHING_CREVICE_SYNTHESIS.md", "reports_v2/ONION_LAYER_BREATHING_CREVICE_SYNTHESIS.md"),
        ("hardening_SPH01/CERN_ITER_ONION_CREVICE_CORRELATION.md", "reports_v2/CERN_ITER_ONION_CREVICE_CORRELATION.md"),
        ("hardening_SPH01/Task_01_v2.md", "reports_v2/Task_01_v2.md"),
        ("hardening_SPH01/Task_02_v2.md", "reports_v2/Task_02_v2.md"),
        ("hardening_SPH01/Task_04_v2.md", "reports_v2/Task_04_v2.md"),
        ("hardening_SPH01/Standard_Dislocation_Tunneling_Reference_v2.md", "reports_v2/Standard_Dislocation_Tunneling_Reference_v2.md"),
        ("hardening_SPH01/DEFERRALS.md", "reports_v2/DEFERRALS.md"),
        ("hardening_SPH01/CHANGELOG.md", "reports_v2/CHANGELOG.md"),
        ("hardening_SPH01/VERIFICATION_REPORT.md", "reports_v2/VERIFICATION_REPORT.md"),
        ("OpenCodeBP/PREREG.md", "reports_v2/OpenCodeBP_PREREG.md"),
        ("OpenCodeBP/ONION_CREVICE_SYNTHESIS.md", "reports_v2/OpenCodeBP_ONION_CREVICE_SYNTHESIS.md"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/VPDR-01.md", "reports_v2/VPDR-01.md"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/VERIFICATION_REPORT_VPDR.md", "reports_v2/VERIFICATION_REPORT_VPDR.md"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/RESEARCH_NOTES.md", "reports_v2/RESEARCH_NOTES_VPDR.md"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/BGCDR-01.md", "reports_v2/BGCDR-01.md"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/VERIFICATION_REPORT_BIO.md", "reports_v2/VERIFICATION_REPORT_BIO.md"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/RESEARCH_NOTES_BIO.md", "reports_v2/RESEARCH_NOTES_BIO.md"),
        ("VERIFICATION_MATRIX_01/VERIFICATION_MATRIX_REPORT.md", "reports_v2/VERIFICATION_MATRIX_REPORT.md"),
        ("VERIFICATION_MATRIX_01/verification_matrix_01.html", "reports_v2/verification_matrix_01.html"),

        # Read-Only Baseline v1 Reports & Substack HTMLs (reports_v1_baseline/)
        ("Task_01_Acoustic_Softening_NME_Report.md", "reports_v1_baseline/Task_01_Acoustic_Softening_NME_Report.md"),
        ("Task_02_Energy_Scaling_Matrix_Report.md", "reports_v1_baseline/Task_02_Energy_Scaling_Matrix_Report.md"),
        ("Task_03_Numerical_Simulation_Spec_Report.md", "reports_v1_baseline/Task_03_Numerical_Simulation_Spec_Report.md"),
        ("Task_04_Astra_Data_Hardening_Protocol_Report.md", "reports_v1_baseline/Task_04_Astra_Data_Hardening_Protocol_Report.md"),
        ("Task_05_Unified_Convergence_Integral_Report.md", "reports_v1_baseline/Task_05_Unified_Convergence_Integral_Report.md"),
        ("Consolidated_Master_Report_AS_NME.md", "reports_v1_baseline/Consolidated_Master_Report_AS_NME.md"),
        ("Standard_Mineral_Spectroscopy_Acoustics_Reference.md", "reports_v1_baseline/Standard_Mineral_Spectroscopy_Acoustics_Reference.md"),
        ("Standard_Dislocation_Tunneling_Reference.md", "reports_v1_baseline/Standard_Dislocation_Tunneling_Reference.md"),
        ("Standard_Dislocation_Tunneling_Reference.html", "reports_v1_baseline/Standard_Dislocation_Tunneling_Reference.html"),
        ("Standard_Physics_Materials_Dashboard.html", "reports_v1_baseline/Standard_Physics_Materials_Dashboard.html"),
        ("Substack_Ready_Master_Report.html", "reports_v1_baseline/Substack_Ready_Master_Report.html"),
        ("Substack_All_Articles_Index.html", "reports_v1_baseline/Substack_All_Articles_Index.html"),
        ("01_Vedic_Metaphysics_Quantum_Energy_Guide.html", "reports_v1_baseline/01_Vedic_Metaphysics_Quantum_Energy_Guide.html"),
        ("02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html", "reports_v1_baseline/02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html"),
        ("03_Lux_Aura_Infrastructure.html", "reports_v1_baseline/03_Lux_Aura_Infrastructure.html"),
        ("04_The_Calculus_of_Convergence.html", "reports_v1_baseline/04_The_Calculus_of_Convergence.html"),
        ("05_Lux_Aura_Project_History_P2P_to_Digital_Temple.html", "reports_v1_baseline/05_Lux_Aura_Project_History_P2P_to_Digital_Temple.html"),

        # Data Ledgers, JSON Metrics & Upstream Manifests (data_and_manifests/)
        ("hardening_SPH01/claims_ledger.csv", "data_and_manifests/claims_ledger.csv"),
        ("hardening_SPH01/spectrum_ledger.csv", "data_and_manifests/spectrum_ledger.csv"),
        ("hardening_SPH01/VEDIC_CONCORDANCE.csv", "data_and_manifests/VEDIC_CONCORDANCE.csv"),
        ("hardening_SPH01/citations.jsonl", "data_and_manifests/citations.jsonl"),
        ("hardening_SPH01/outputs/phase2_band_metrics.json", "data_and_manifests/phase2_band_metrics.json"),
        ("hardening_SPH01/outputs/cern_iter_onion_crevice_metrics.json", "data_and_manifests/cern_iter_onion_crevice_metrics.json"),
        ("hardening_SPH01/outputs/MANIFEST.sha256", "data_and_manifests/SPH01_MANIFEST.sha256"),
        ("quantum_dislocation_tunneling_data.json", "data_and_manifests/quantum_dislocation_tunneling_data.json"),
        ("standard_mineral_acoustics_data.json", "data_and_manifests/standard_mineral_acoustics_data.json"),
        ("e4_lunar_residual_output.json", "data_and_manifests/e4_lunar_residual_output.json"),
        ("e4_followup_mm_output.json", "data_and_manifests/e4_followup_mm_output.json"),
        ("OpenCodeBP/outputs/onion_crevice_derived.json", "data_and_manifests/OpenCodeBP_onion_crevice_derived.json"),
        ("OpenCodeBP/outputs/claims_part1.csv", "data_and_manifests/OpenCodeBP_claims_part1.csv"),
        ("OpenCodeBP/outputs/claims_part2.csv", "data_and_manifests/OpenCodeBP_claims_part2.csv"),
        ("OpenCodeBP/outputs/claims_part3.csv", "data_and_manifests/OpenCodeBP_claims_part3.csv"),
        ("OpenCodeBP/outputs/CORPUS_MANIFEST.sha256", "data_and_manifests/OpenCodeBP_CORPUS_MANIFEST.sha256"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/claims_dataset.csv", "data_and_manifests/VPDR_claims_dataset.csv"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/outputs/gradient_ledger.csv", "data_and_manifests/VPDR_gradient_ledger.csv"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/outputs/gradient_summary.json", "data_and_manifests/VPDR_gradient_summary.json"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/citations_compiled.jsonl", "data_and_manifests/VPDR_citations_compiled.jsonl"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/outputs/MANIFEST.sha256", "data_and_manifests/VPDR_MANIFEST.sha256"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/claims_dataset_bio.csv", "data_and_manifests/BIO_claims_dataset_bio.csv"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/outputs/bio_gradient_ledger.csv", "data_and_manifests/BIO_bio_gradient_ledger.csv"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/outputs/bio_summary.json", "data_and_manifests/BIO_bio_summary.json"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/citations_bio.jsonl", "data_and_manifests/BIO_citations_bio.jsonl"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/outputs/MANIFEST.sha256", "data_and_manifests/BIO_MANIFEST.sha256"),
        ("VERIFICATION_MATRIX_01/verification_matrix.csv", "data_and_manifests/VM01_verification_matrix.csv"),
        ("VERIFICATION_MATRIX_01/parallels_ledger.csv", "data_and_manifests/VM01_parallels_ledger.csv"),
        ("VERIFICATION_MATRIX_01/eigenmodes.json", "data_and_manifests/VM01_eigenmodes.json"),
        ("VERIFICATION_MATRIX_01/physical_eigenmodes.csv", "data_and_manifests/VM01_physical_eigenmodes.csv"),
        ("VERIFICATION_MATRIX_01/spectrum_coincidences.csv", "data_and_manifests/VM01_spectrum_coincidences.csv"),
        ("VERIFICATION_MATRIX_01/outputs/summary.json", "data_and_manifests/VM01_summary.json"),
        ("VERIFICATION_MATRIX_01/outputs/MANIFEST.sha256", "data_and_manifests/VM01_MANIFEST.sha256"),

        # Scripts & Environment Specs (scripts/)
        ("hardening_SPH01/requirements.txt", "scripts/requirements.txt"),
        ("sim_cavity_acoustics.py", "scripts/sim_cavity_acoustics.py"),
        ("sim_cavity_acoustics.cpp", "scripts/sim_cavity_acoustics.cpp"),
        ("verify_convergence_integral.py", "scripts/verify_convergence_integral.py"),
        ("verify_metamaterial_and_hugoniot.py", "scripts/verify_metamaterial_and_hugoniot.py"),
        ("verify_quantum_resonance.py", "scripts/verify_quantum_resonance.py"),
        ("standard_mineral_acoustics_visualizer.py", "scripts/standard_mineral_acoustics_visualizer.py"),
        ("format_all_substack_articles.py", "scripts/format_all_substack_articles.py"),
        ("e4_lunar_residual_search.py", "scripts/e4_lunar_residual_search.py"),
        ("e4_followup_mm.py", "scripts/e4_followup_mm.py"),
        ("hardening_SPH01/scripts/phase0_1_extract_and_spectrum.py", "scripts/phase0_1_extract_and_spectrum.py"),
        ("hardening_SPH01/scripts/phase2_band_computations.py", "scripts/phase2_band_computations.py"),
        ("hardening_SPH01/scripts/phase4_cern_iter_onion_crevice_metrics.py", "scripts/phase4_cern_iter_onion_crevice_metrics.py"),
        ("hardening_SPH01/scripts/verify_sph01_manifest.py", "scripts/verify_sph01_manifest.py"),
        ("hardening_SPH01/scripts/stage_and_verify_publish_package.py", "scripts/stage_and_verify_publish_package.py"),
        ("OpenCodeBP/scripts/onion_crevice_derivation.py", "scripts/OpenCodeBP_onion_crevice_derivation.py"),
        ("OpenCodeBP/scripts/pin_corpus.py", "scripts/OpenCodeBP_pin_corpus.py"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/scripts/crunch_gradient.py", "scripts/VPDR_crunch_gradient.py"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/scripts/crunch_bio.py", "scripts/BIO_crunch_bio.py"),
        ("VERIFICATION_MATRIX_01/scripts/build_verification_matrix.py", "scripts/VM01_build_verification_matrix.py"),

        # Analytical Charts & Figures (img/)
        ("hardening_SPH01/outputs/spectrum_ledger_chart.png", "img/spectrum_ledger_chart.png"),
        ("hardening_SPH01/outputs/spectrum_ledger_chart.svg", "img/spectrum_ledger_chart.svg"),
        ("VEDIC_PLASMA_DEEP_RESEARCH/outputs/gradient_chart.png", "img/VPDR_gradient_chart.png"),
        ("BIO_GENE_CELLULAR_DEEP_RESEARCH/outputs/bio_chart.png", "img/BIO_bio_chart.png"),
        ("VERIFICATION_MATRIX_01/charts/eigenmode_map.png", "img/VM01_eigenmode_map.png"),
        ("VERIFICATION_MATRIX_01/charts/eigenmode_map.svg", "img/VM01_eigenmode_map.svg"),
        ("VERIFICATION_MATRIX_01/charts/mode_loadings.png", "img/VM01_mode_loadings.png"),
        ("VERIFICATION_MATRIX_01/charts/mode_loadings.svg", "img/VM01_mode_loadings.svg"),
        ("VERIFICATION_MATRIX_01/charts/singular_spectrum.png", "img/VM01_singular_spectrum.png"),
        ("VERIFICATION_MATRIX_01/charts/singular_spectrum.svg", "img/VM01_singular_spectrum.svg"),
        ("VERIFICATION_MATRIX_01/charts/spectrum_vs_ladders.png", "img/VM01_spectrum_vs_ladders.png"),
        ("VERIFICATION_MATRIX_01/charts/spectrum_vs_ladders.svg", "img/VM01_spectrum_vs_ladders.svg"),
        ("FINAL_MASTER_ANALYSIS_figures/fig1_two_halves_one_bridge.png", "img/fig1_two_halves_one_bridge.png"),
        ("FINAL_MASTER_ANALYSIS_figures/fig2_ideas_cost_vs_payoff.png", "img/fig2_ideas_cost_vs_payoff.png"),
    ]

    # Add all 17 schematic JPGs from C:\LuxAura\study\img\
    img_dir = STUDY_ROOT / "img"
    for jpg in sorted(img_dir.glob("*.jpg")):
        staging_plan.append((f"img/{jpg.name}", f"img/{jpg.name}"))

    staged_records = []
    for src_rel, dst_rel in staging_plan:
        src_path = STUDY_ROOT / src_rel
        dst_path = PUBLISH_ROOT / dst_rel
        rec = copy_and_verify(src_path, dst_path)
        staged_records.append(rec)

    # Generate README.md inside publish/
    readme_path = PUBLISH_ROOT / "README.md"
    readme_text = build_publish_readme(staged_records, sph01_count)
    readme_path.write_text(readme_text, encoding="utf-8")
    staged_records.append({
        "rel_publish_path": "README.md",
        "source_path": "publish/README.md (generated)",
        "size_bytes": readme_path.stat().st_size,
        "sha256": sha256_file(readme_path),
    })

    # Sort records by rel_publish_path
    staged_records.sort(key=lambda r: r["rel_publish_path"])

    # Write PUBLISH_MANIFEST.json
    publish_json_path = PUBLISH_ROOT / "PUBLISH_MANIFEST.json"
    manifest_payload = {
        "package_id": "LUXAURA-PUBLISH-SPH01-FINAL",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "total_files": len(staged_records),
        "total_bytes": sum(r["size_bytes"] for r in staged_records),
        "all_hashes_verified": True,
        "files": staged_records,
    }
    publish_json_path.write_text(json.dumps(manifest_payload, indent=2), encoding="utf-8")

    # Include PUBLISH_MANIFEST.json in MANIFEST.sha256
    manifest_lines = []
    for r in staged_records:
        manifest_lines.append(f"{r['sha256']}  {r['rel_publish_path']}")
    manifest_lines.append(f"{sha256_file(publish_json_path)}  PUBLISH_MANIFEST.json")

    manifest_sha_path = PUBLISH_ROOT / "MANIFEST.sha256"
    manifest_sha_path.write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    # Final verification pass: re-read MANIFEST.sha256 and check every single file on disk
    verified_count = 0
    for line in manifest_sha_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected_hash, rel_p = line.split("  ", 1)
        f_path = PUBLISH_ROOT / rel_p
        actual_hash = sha256_file(f_path)
        if actual_hash != expected_hash:
            raise RuntimeError(f"Final verification failed for {rel_p}")
        verified_count += 1

    # Re-update hardening_SPH01/outputs/MANIFEST.sha256 one final time in case this script changed
    sph01_count = update_sph01_manifest()

    print(f"SUCCESS: Staged and cryptographically verified {verified_count} files in {PUBLISH_ROOT}")
    print(f"SUCCESS: Updated hardening_SPH01/outputs/MANIFEST.sha256 with {sph01_count} verified files")


if __name__ == "__main__":
    main()
