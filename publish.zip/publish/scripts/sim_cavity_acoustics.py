"""
sim_cavity_acoustics.py
-----------------------
Numerical verification script for Task 3 (Document ID: AS-NME-REP-03):
Simulates 2D/3D Helmholtz eigenmodes, finite-difference acoustic pressure gradient
distributions (\\nabla P_ac), Stokes-Kirchhoff visco-thermal boundary-layer damping
(\\delta_bl), and NME strain-softened wall impedance in a 5.0 m rock-cut basalt/granite
chamber (f_100 = 34.4 Hz fundamental & ultrasonic cavitation harmonics).
"""

import math
import json

PI = math.pi


def compute_boundary_layer_and_eigenmodes(
    Lx=5.0, Ly=3.0, Lz=2.5,
    rho_f=1.204, c_f=344.0, nu_f=1.516e-5, Pr=0.713, gamma=1.40,
    rho_s=2850.0, G_0=30.0e9, K_0=50.0e9,
    alpha_G=2500.0, delta_G=-4.0e6, eps_th=1.0e-6,
    eps_ac=1.5e-4, P_antinode=2500.0
):
    V = Lx * Ly * Lz
    S = 2.0 * (Lx * Ly + Lx * Lz + Ly * Lz)
    r_h = 2.0 * V / S  # Hydraulic radius [m]

    # NME wall softening
    H = 1.0 if eps_ac > eps_th else 0.0
    S_backbone = max(0.05, 1.0 - alpha_G * (eps_ac - eps_th) * H + 0.75 * delta_G * (eps_ac ** 2))
    G_eff = G_0 * S_backbone
    K_eff = K_0 * S_backbone
    M_eff = K_eff + (4.0 / 3.0) * G_eff
    c_p_eff = math.sqrt(M_eff / rho_s)
    Z_wall = rho_s * c_p_eff
    Z_fluid = rho_f * c_f
    R_coeff = (Z_wall - Z_fluid) / (Z_wall + Z_fluid)

    modes = [
        (1, 0, 0, "Fundamental Longitudinal (Chevalier Stopping Mode)"),
        (2, 0, 0, "Second Longitudinal Harmonic"),
        (3, 0, 0, "Third Longitudinal Harmonic"),
        (1, 1, 0, "First Coupled Lateral-Longitudinal Mode"),
        (1, 1, 1, "First 3D Tri-Axial Volumetric Mode"),
    ]

    results = []
    for nx, ny, nz, label in modes:
        kx = nx * PI / Lx
        ky = ny * PI / Ly
        kz = nz * PI / Lz
        k_mag = math.sqrt(kx**2 + ky**2 + kz**2)
        f_n = (c_f / (2.0 * PI)) * k_mag
        omega = 2.0 * PI * f_n

        # Stokes-Kirchhoff boundary layer thicknesses
        delta_v = math.sqrt(2.0 * nu_f / omega)
        delta_t = delta_v / math.sqrt(Pr)
        delta_bl_eff = delta_v + (gamma - 1.0) * delta_t

        # Attenuation coefficient alpha_bl [Np/m] and cavity Q factor
        alpha_bl = (omega / (2.0 * c_f * r_h)) * delta_bl_eff
        Q_bl = k_mag / (2.0 * alpha_bl)

        # Peak Pressure Gradient |\nabla P_ac|_max = k_mag * P_antinode
        grad_P_max = k_mag * P_antinode

        # Acoustic radiation force density on suspended particles / micro-bubbles
        F_rad_density = (grad_P_max ** 2) / (2.0 * rho_f * (c_f ** 2))

        results.append({
            "mode": f"({nx},{ny},{nz})",
            "label": label,
            "freq_hz": round(f_n, 2),
            "k_rad_m": round(k_mag, 4),
            "delta_v_mm": round(delta_v * 1e3, 4),
            "delta_t_mm": round(delta_t * 1e3, 4),
            "delta_bl_eff_mm": round(delta_bl_eff * 1e3, 4),
            "alpha_bl_np_m": round(alpha_bl, 6),
            "Q_bl": round(Q_bl, 1),
            "grad_P_max_Pa_m": round(grad_P_max, 2),
            "F_rad_N_m3": round(F_rad_density, 3),
        })

    return {
        "cavity": {"Lx": Lx, "Ly": Ly, "Lz": Lz, "V_m3": V, "S_m2": S, "r_h_m": round(r_h, 4)},
        "nme_wall": {
            "eps_ac": eps_ac,
            "S_backbone": round(S_backbone, 4),
            "G_eff_GPa": round(G_eff / 1e9, 2),
            "c_p_eff_m_s": round(c_p_eff, 1),
            "Z_wall_MRayl": round(Z_wall / 1e6, 3),
            "R_coeff": round(R_coeff, 6),
        },
        "eigenmodes": results,
    }


if __name__ == "__main__":
    summary = compute_boundary_layer_and_eigenmodes()
    print(json.dumps(summary, indent=2))
