#!/usr/bin/env python3
"""
Phase 2 Band Computations (Bands Q, CE, V) for Directive SPH-01.
Produces deterministic JSON metrics in outputs/phase2_band_metrics.json.
"""
import json
import math
from pathlib import Path

OUT_DIR = Path(r"C:\LuxAura\study\hardening_SPH01\outputs")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Fundamental constants (CODATA 2018)
H_PLANCK = 6.62607015e-34       # J s
HBAR = H_PLANCK / (2.0 * math.pi)
K_BOLTZ = 1.380649e-23          # J / K
EV_J = 1.602176634e-19          # J / eV
C_LIGHT = 2.99792458e8          # m / s
AMU_KG = 1.66053906660e-27      # kg
N_AVOGADRO = 6.02214076e23      # mol^-1
MU_0 = 4.0e-7 * math.pi         # H / m
G_EARTH = 9.80665               # m / s^2
R_EARTH = 6.371e6               # m


def compute_band_q():
    # Q1: Thermal phonon occupation at 300 K and 10 K
    freqs = [
        ("Barabar fundamental", 34.4),
        ("Chamber harmonic", 110.0),
        ("NME double-negative band", 21500.0),
        ("Ultrasonic horn", 25000.0),
        ("Parametric carrier", 40000.0),
        ("AE micro-fracture band", 300000.0),
        ("Dislocation pinning mode", 1.0e10),
        ("Quartz Si-O-Si bend (464 cm^-1)", 1.391e13),
        ("Silicate Si-O stretch (1000 cm^-1)", 2.998e13),
    ]
    q1_table = []
    for label, f_hz in freqs:
        e_j = H_PLANCK * f_hz
        e_ev = e_j / EV_J
        x_300 = e_j / (K_BOLTZ * 300.0)
        x_10 = e_j / (K_BOLTZ * 10.0)
        n_300 = 1.0 / math.expm1(x_300) if x_300 < 500 else 0.0
        n_10 = 1.0 / math.expm1(x_10) if x_10 < 500 else 0.0
        regime_300 = "Quantum (n_th < 1)" if n_300 < 1.0 else "Classical wave (n_th >> 1)"
        q1_table.append({
            "mode": label,
            "f_Hz": f_hz,
            "E_eV": e_ev,
            "hf_over_kBT_300K": x_300,
            "n_th_300K": n_300,
            "n_th_10K": n_10,
            "regime_300K": regime_300,
        })

    # Q2: Dislocation tunneling reconciliation (Standard_Dislocation_Tunneling_Reference vs verify_quantum_resonance.py)
    b = 2.5e-10
    a_p = 2.5e-10
    rho = 2850.0
    G_shear = 30.0e9
    sigma_p = 5.0e7
    m_d = (rho * b**2) / (4.0 * math.pi)
    kappa_d = (G_shear * b**2) / (4.0 * math.pi)

    # Script prefactor C_PP = 18.96 vs prose prefactor (24 / (5*pi)) * (2*pi)**0.25 = 2.4197
    c_pp_script = 18.96
    c_pp_prose = (24.0 / (5.0 * math.pi)) * ((2.0 * math.pi) ** 0.25)
    dimless_factor = (a_p**2 * math.sqrt(m_d * kappa_d) / HBAR) * ((b * sigma_p * a_p / kappa_d) ** 0.25)
    s0_over_hbar_script = c_pp_script * dimless_factor
    s0_over_hbar_prose = c_pp_prose * dimless_factor

    tau0_script_ps = math.sqrt(m_d * a_p / (b * sigma_p)) * 1e12
    tau0_prose_ps = math.sqrt(m_d * a_p / (2.0 * math.pi * b * sigma_p)) * 1e12

    # Table 2 reconciliation across temperatures
    q0 = 2500.0
    f_ac = 25000.0
    omega_ac = 2.0 * math.pi * f_ac
    temps = [10, 50, 150, 300, 600]
    q2_table2 = []
    for T in temps:
        q_eff = q0 / (1.0 + 0.008 * T)
        tau_energy_ms = (q_eff / omega_ac) * 1e3
        tau_amp_ms = (2.0 * q_eff / omega_ac) * 1e3
        n_th = (K_BOLTZ * T) / (HBAR * omega_ac)
        q2_table2.append({
            "T_K": T,
            "Q_eff": round(q_eff, 2),
            "tau_energy_ms": round(tau_energy_ms, 3),
            "tau_amplitude_ms": round(tau_amp_ms, 3),
            "n_th": n_th,
        })

    # Q4: Standard Model nucleon mass decomposition
    m_proton_mev = 938.272088
    m_u_mev = 2.16
    m_d_mev = 4.67
    m_valence_higgs_mev = 2.0 * m_u_mev + m_d_mev  # 8.99 MeV
    higgs_frac_pct = 100.0 * m_valence_higgs_mev / m_proton_mev
    qcd_frac_pct = 100.0 - higgs_frac_pct

    return {
        "q1_thermal_occupation": q1_table,
        "q2_tunneling_reconciliation": {
            "m_d_kg_per_m": m_d,
            "kappa_d_N": kappa_d,
            "dimless_factor": dimless_factor,
            "C_PP_script": c_pp_script,
            "C_PP_prose_v1": c_pp_prose,
            "S0_over_hbar_script": s0_over_hbar_script,
            "S0_over_hbar_prose_v1": s0_over_hbar_prose,
            "tau0_script_ps": tau0_script_ps,
            "tau0_prose_v1_ps": tau0_prose_ps,
            "table2_reconciled": q2_table2,
        },
        "q4_nucleon_mass": {
            "m_proton_MeV": m_proton_mev,
            "m_valence_Higgs_MeV": m_valence_higgs_mev,
            "Higgs_fraction_pct": round(higgs_frac_pct, 2),
            "QCD_gluon_kinetic_fraction_pct": round(qcd_frac_pct, 2),
        },
    }


def compute_band_ce():
    # CE1: Harmonic oscillator wavenumber check
    bonds = [
        ("Si-O tetrahedral stretch", 10.193, 595.0, 1000.0, "Effective tetrahedral stretch constant"),
        ("Si-O-Si symmetric bridge bend (alpha-quartz)", 10.193, 128.0, 464.0, "Effective polyatomic bending constant fitted to A1 mode"),
        ("Al-O aluminosilicate stretch (plagioclase)", 10.041, 410.0, 825.0, "Effective tetrahedral Al-O stretch constant"),
        ("Si-O diatomic free-molecule stretch (reference)", 10.193, 924.0, 1241.0, "True gas-phase diatomic SiO bond constant (for contrast)"),
    ]
    ce1_table = []
    for name, mu_amu, k_nm, rruff_cm1, note in bonds:
        mu_kg = mu_amu * AMU_KG
        omega = math.sqrt(k_nm / mu_kg)
        f_thz = (omega / (2.0 * math.pi)) * 1e-12
        nu_cm1 = (f_thz * 1e12) / (C_LIGHT * 100.0)
        err_pct = 100.0 * abs(nu_cm1 - rruff_cm1) / rruff_cm1
        ce1_table.append({
            "bond": name,
            "mu_amu": mu_amu,
            "k_N_per_m": k_nm,
            "calc_cm1": round(nu_cm1, 2),
            "rruff_cm1": rruff_cm1,
            "f_THz": round(f_thz, 2),
            "discrepancy_pct": round(err_pct, 2),
            "note": note,
        })

    # CE2: Homosphere mixing vs electromagnetic / barometric sorting (Task CE2 / D4)
    # Compare gravitational force m*g vs magnetic Kelvin force on paramagnetic O2 and diamagnetic N2
    T_atm = 250.0  # K
    B_surf = 50.0e-6  # T
    grad_B = 3.0 * B_surf / R_EARTH  # ~2.35e-11 T/m
    species = [
        ("N2", 28.0134, -1.20e-5, 0.78084),
        ("O2", 31.9988, +3.449e-3, 0.20946),
        ("Ar", 39.9480, -1.96e-5, 0.00934),
        ("He", 4.0026, -1.88e-6, 5.24e-6),
    ]
    ce2_table = []
    for sp, mass_u, chi_cgs_mol, x_surf in species:
        m_kg = mass_u * AMU_KG
        f_grav = m_kg * G_EARTH
        # Convert cgs molar susceptibility (cm^3/mol) to SI per-molecule susceptibility (m^3):
        # chi_SI_mol = 4 * pi * 1e-6 * chi_cgs_mol; per molecule = chi_SI_mol / N_A
        chi_si_mol = 4.0 * math.pi * 1e-6 * chi_cgs_mol
        chi_molecule = chi_si_mol / N_AVOGADRO
        f_mag = abs(chi_molecule) * (B_surf / MU_0) * grad_B
        H_km = (K_BOLTZ * T_atm) / (m_kg * G_EARTH) / 1000.0
        # Unmixed diffusive barometric ratio at z = 80 km relative to N2 if eddy diffusion K_zz = 0:
        H_N2_km = (K_BOLTZ * T_atm) / (28.0134 * AMU_KG * G_EARTH) / 1000.0
        unmixed_ratio_80km = math.exp(-80.0 * (1.0 / H_km - 1.0 / H_N2_km))
        ce2_table.append({
            "species": sp,
            "mass_u": mass_u,
            "scale_height_H_km": round(H_km, 2),
            "F_grav_N": f_grav,
            "F_mag_Kelvin_N": f_mag,
            "ratio_Fmag_over_Fgrav": f_mag / f_grav,
            "unmixed_barometric_enrichment_80km_vs_N2": round(unmixed_ratio_80km, 4),
            "observed_homosphere_fraction_0_to_90km": x_surf,
        })

    # CE3: Planetary Paschen breakdown voltage at d = 0.01 m (1 cm) vs surface gravity g
    # Paschen law: V_B = B_p * (p * d) / (ln(A_p * p * d) - ln(ln(1 + 1/gamma_se)))
    # Standard Townsend coefficients (p in Torr, d in cm):
    # Air (N2/O2): A = 15 cm^-1 Torr^-1, B = 365 V cm^-1 Torr^-1, gamma_se = 0.01
    # CO2: A = 20 cm^-1 Torr^-1, B = 466 V cm^-1 Torr^-1, gamma_se = 0.01
    # N2: A = 12 cm^-1 Torr^-1, B = 342 V cm^-1 Torr^-1, gamma_se = 0.01
    planets = [
        ("Earth", 9.807, 1.01325, "Air (78% N2, 21% O2)", 15.0, 365.0, 0.01),
        ("Mars", 3.721, 0.0061, "CO2 (95%)", 20.0, 466.0, 0.01),
        ("Venus", 8.870, 92.0, "CO2 (96.5%)", 20.0, 466.0, 0.01),
        ("Titan", 1.352, 1.45, "N2 (98.4%)", 12.0, 342.0, 0.01),
    ]
    d_cm = 1.0
    ce3_table = []
    for pname, g_ms2, p_bar, gas, A_p, B_p, gamma_se in planets:
        p_torr = p_bar * 750.06168
        pd = p_torr * d_cm
        denom = math.log(A_p * pd) - math.log(math.log(1.0 + 1.0 / gamma_se))
        v_b_volts = (B_p * pd) / denom
        ce3_table.append({
            "body": pname,
            "g_m_s2": g_ms2,
            "p_surf_bar": p_bar,
            "p_surf_Torr": round(p_torr, 2),
            "dominant_gas": gas,
            "V_breakdown_1cm_V": round(v_b_volts, 1),
            "V_breakdown_1cm_kV": round(v_b_volts / 1000.0, 3),
        })

    return {
        "ce1_raman_bonds": ce1_table,
        "ce2_homosphere_sorting": ce2_table,
        "ce3_planetary_paschen": ce3_table,
    }


def compute_band_v():
    # V1: Unified G_eff and sigma_t^eff chain across strain amplitudes
    G0 = 30.0e9
    sigma_t0 = 15.0e6
    alpha_G = 2500.0
    eps_th = 1.0e-6
    delta_G = -4.0e6
    f_drive = 21500.0
    omega_drive = 2.0 * math.pi * f_drive

    strains = [1.0e-5, 5.0e-5, 1.5e-4, 2.5e-4, 1.0e-3]
    v1_table = []
    for eps in strains:
        s_backbone = 1.0 - alpha_G * max(0.0, eps - eps_th) - 0.75 * abs(delta_G) * (eps**2)
        g_backbone_gpa = (G0 * s_backbone) * 1e-9
        q_inv = (4.0 * alpha_G * eps) / (3.0 * math.pi)
        q_factor = 1.0 / q_inv
        # Volumetric holding dissipation: q_dot = 0.5 * omega * G0 * eps^2 * Q^-1
        # = (2 / (3*pi)) * omega * G0 * alpha_G * eps^3
        q_dot_w_m3 = 0.5 * omega_drive * G0 * (eps**2) * q_inv
        v_sustained_25kw_liters = (25000.0 / q_dot_w_m3) * 1000.0
        sigma_t_backbone_mpa = (sigma_t0 * math.sqrt(max(0.0, s_backbone))) * 1e-6
        v1_table.append({
            "eps_ac": eps,
            "S_backbone": round(s_backbone, 4),
            "G_backbone_GPa": round(g_backbone_gpa, 3),
            "sigma_t_backbone_MPa": round(sigma_t_backbone_mpa, 3),
            "Q_inv": round(q_inv, 4),
            "Q_factor": round(q_factor, 2),
            "q_dot_MW_m3": round(q_dot_w_m3 * 1e-6, 4),
            "V_sustained_at_25kW_L": round(v_sustained_25kw_liters, 4),
            "model_valid": bool(q_inv < 0.3 and s_backbone > 0.0),
        })

    # V2: Kailasa excavation energy & labor reconciliation
    m_total_kg = 4.0e8
    rho_b = 2850.0
    v_exc_m3 = m_total_kg / rho_b
    t_op_18yr_hr = 18 * 365.25 * 12.0  # 78,894 hrs (or 78,840 hrs for 365 d/yr)
    t_op_18yr_s = 78840.0 * 3600.0
    e_trad_j = v_exc_m3 * 150.0e6
    p_trad_w = e_trad_j / t_op_18yr_s
    # Since E_s,trad = 150 MJ/m^3 ALREADY includes the ~4% mechanical chisel efficiency,
    # the human mechanical input is P_trad / 75 W = 989 masons (NOT divided by 0.04 a second time!)
    masons_corrected = p_trad_w / 75.0
    masons_double_counted_v1 = p_trad_w / (75.0 * 0.04)

    # V3: FDTD ring-up fraction after N=20 cycles for Q = 1941.3
    q_cav = 1941.3
    n_cycles_v1 = 20
    amp_frac_20 = 1.0 - math.exp(-math.pi * n_cycles_v1 / q_cav)
    energy_frac_20 = amp_frac_20**2
    cycles_for_95pct_amp = -math.log(1.0 - 0.95) * q_cav / math.pi

    # V5a: Berktay far-field parametric demodulation roll-off (7 Hz vs 1000 Hz)
    f_ref = 1000.0
    f_beat = 7.0
    berktay_db_loss = 40.0 * math.log10(f_beat / f_ref)

    # V5b: Narayanastra Doppler sweep using script parameters
    # omega_d0 * sqrt(S(1.5e-4)) = 2*pi*20355 Hz, gamma_d = 0.035
    f_d_res = 20355.0
    gamma_d = 0.035
    q_d = 1.0 / gamma_d
    hwhm_hz = 0.5 * gamma_d * f_d_res
    c_air = 343.0
    speeds = [0.0, 1.0, 2.0, 5.0, 10.0, 15.0]
    # Assume carrier is parked 1.5 linewidths below resonance: f_0 = f_d_res - 1.5 * hwhm_hz
    f_carrier = f_d_res - 1.5 * hwhm_hz
    doppler_table = []
    for v_t in speeds:
        df_hz = f_carrier * (2.0 * v_t / c_air)  # monostatic backscatter Doppler shift 2*v/c
        f_eff = f_carrier + df_hz
        # Lorentzian response L(f) = f_d_res^2 / sqrt((f_d_res^2 - f_eff^2)^2 + (gamma_d * f_d_res * f_eff)^2)
        enh_amp = (f_d_res**2) / math.sqrt((f_d_res**2 - f_eff**2)**2 + (gamma_d * f_d_res * f_eff)**2)
        enh_power = enh_amp**2
        doppler_table.append({
            "v_target_m_s": v_t,
            "doppler_shift_2v_c_Hz": round(df_hz, 2),
            "f_eff_Hz": round(f_eff, 2),
            "detuning_from_res_Hz": round(f_eff - f_d_res, 2),
            "amplitude_enhancement": round(enh_amp, 2),
            "energy_enhancement": round(enh_power, 1),
        })

    # V6: Esposito et al. (2019) sound-carried gravitational mass
    # M_sound = -((gamma_ad - 1) / (2 * c_s^2)) * E_sound for ideal gas (gamma_ad = 1.4, c_s = 344 m/s)
    e_cav_j = 2.245e5
    c_s_air = 344.0
    m_sound_cav_kg = -((1.4 - 1.0) / (2.0 * c_s_air**2)) * e_cav_j

    return {
        "v1_softening_chain": v1_table,
        "v2_excavation_reconciliation": {
            "V_exc_m3": round(v_exc_m3, 2),
            "E_trad_TJ": round(e_trad_j * 1e-12, 3),
            "P_trad_kW": round(p_trad_w * 1e-3, 3),
            "masons_corrected_single_count": round(masons_corrected, 1),
            "masons_v1_double_counted": round(masons_double_counted_v1, 1),
        },
        "v3_fdtd_ringup": {
            "Q_cav": q_cav,
            "N_cycles_v1": n_cycles_v1,
            "amplitude_fraction_at_20_cycles_pct": round(100.0 * amp_frac_20, 3),
            "energy_fraction_at_20_cycles_pct": round(100.0 * energy_frac_20, 4),
            "cycles_required_for_95pct_amplitude": round(cycles_for_95pct_amp, 1),
        },
        "v5_berktay_and_doppler": {
            "berktay_7Hz_vs_1kHz_dB": round(berktay_db_loss, 2),
            "Q_d_script": round(q_d, 2),
            "Q_d_squared_script": round(q_d**2, 1),
            "HWHM_Hz": round(hwhm_hz, 2),
            "f_carrier_parked_Hz": round(f_carrier, 2),
            "doppler_sweep": doppler_table,
        },
        "v6_esposito_sound_mass": {
            "E_cavity_J": e_cav_j,
            "M_sound_cavity_kg": m_sound_cav_kg,
            "M_sound_cavity_mg": round(m_sound_cav_kg * 1e6, 4),
        },
    }


def main():
    metrics = {
        "band_q": compute_band_q(),
        "band_ce": compute_band_ce(),
        "band_v": compute_band_v(),
    }
    out_path = OUT_DIR / "phase2_band_metrics.json"
    out_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Wrote {out_path} ({out_path.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
