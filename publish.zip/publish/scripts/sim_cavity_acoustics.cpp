/**
 * @file sim_cavity_acoustics.cpp
 * @brief 2D/3D Finite-Difference Time-Domain (FDTD) & Helmholtz Solver for
 *        Acoustic Pressure Gradient (\nabla P_ac), Stokes-Kirchhoff Boundary-Layer
 *        Damping (\delta_bl), and NME Wall Impedance Softening in a Resonant
 *        Granite/Basalt Monolithic Cavity (f_100 = 34.4 Hz & Ultrasonic Harmonics).
 *
 * Document ID: AS-NME-REP-03
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <complex>
#include <iomanip>
#include <fstream>

namespace AcousticSim {

constexpr double PI = 3.14159265358979323846;

struct CavityParams {
    // Cavity dimensions (Barabar / Kailasa benchmark module: Lx = 5.0 m, Ly = 3.0 m, Lz = 2.5 m)
    double Lx = 5.0;          // Longitudinal length [m]
    double Ly = 3.0;          // Lateral width [m]
    double Lz = 2.5;          // Vault height [m]

    // Fluid medium properties (Air or Cavitation Water Slurry)
    double rho_f = 1.204;     // Air density at 20 C [kg/m^3]
    double c_f   = 344.0;     // Speed of sound in cavity air [m/s] -> f_100 = c_f / (2*Lx) = 34.4 Hz
    double nu_f  = 1.516e-5;  // Kinematic viscosity [m^2/s]
    double Pr    = 0.713;     // Prandtl number
    double gamma = 1.400;     // Adiabatic index

    // Basalt / Granite Substrate NME properties
    double rho_s = 2850.0;    // Basalt density [kg/m^3]
    double G_0   = 30.0e9;    // Unperturbed shear modulus [Pa]
    double K_0   = 50.0e9;    // Unperturbed bulk modulus [Pa]
    double alpha_G = 2500.0;  // NME hysteretic parameter
    double delta_G = -4.0e6;  // NME cubic anharmonic parameter
    double eps_th  = 1.0e-6;  // Threshold strain
};

struct BoundaryLayerResult {
    double freq_hz;
    double omega;
    double delta_visc;        // Viscous Stokes boundary layer thickness [m]
    double delta_therm;       // Thermal boundary layer thickness [m]
    double alpha_bl;          // Boundary-layer attenuation coefficient [Np/m]
    double Q_cavity;          // Cavity quality factor
};

/**
 * @brief Computes Stokes-Kirchhoff visco-thermal boundary layer thickness (\delta_bl)
 *        and wall damping loss factor for a rock-cut chamber.
 */
BoundaryLayerResult computeBoundaryLayer(const CavityParams& p, double freq_hz) {
    BoundaryLayerResult res{};
    res.freq_hz = freq_hz;
    res.omega   = 2.0 * PI * freq_hz;

    // Viscous & thermal boundary layer thicknesses: \delta_v = \sqrt{2 \nu / \omega}
    res.delta_visc  = std::sqrt(2.0 * p.nu_f / res.omega);
    res.delta_therm = res.delta_visc / std::sqrt(p.Pr);

    // Cavity volume V and total internal rock surface area S
    double V = p.Lx * p.Ly * p.Lz;
    double S = 2.0 * (p.Lx * p.Ly + p.Lx * p.Lz + p.Ly * p.Lz);
    double hydraulic_radius = 2.0 * V / S;

    // Kirchhoff visco-thermal boundary layer attenuation coefficient
    double loss_bl = (res.omega / (2.0 * p.c_f * hydraulic_radius)) *
                     (res.delta_visc + (p.gamma - 1.0) * res.delta_therm);
    res.alpha_bl = loss_bl;
    res.Q_cavity = (res.omega / (2.0 * p.c_f)) / loss_bl;
    return res;
}

/**
 * @brief Computes NME strain-softened acoustic impedance Z_s(eps_ac) of the basalt wall.
 */
double computeNMEWallImpedance(const CavityParams& p, double eps_ac) {
    double H = (eps_ac > p.eps_th) ? 1.0 : 0.0;
    double S_factor = 1.0 - p.alpha_G * (eps_ac - p.eps_th) * H
                          + 0.75 * p.delta_G * (eps_ac * eps_ac);
    if (S_factor < 0.05) S_factor = 0.05; // Residual granular floor
    double G_eff = p.G_0 * S_factor;
    double M_eff = p.K_0 * S_factor + (4.0 / 3.0) * G_eff;
    double c_p_eff = std::sqrt(M_eff / p.rho_s);
    return p.rho_s * c_p_eff;
}

/**
 * @brief 2D Staggered-Grid FDTD Solver for Acoustic Pressure P_ac(x,y,t) and
 *        Pressure Gradient |\nabla P_ac(x,y)| inside the resonant chamber.
 */
void runFDTD2D(const CavityParams& p, double drive_freq_hz, double P_source_Pa, double eps_ac) {
    const int Nx = 101;
    const int Ny = 61;
    const double dx = p.Lx / (Nx - 1);
    const double dy = p.Ly / (Ny - 1);

    // Courant-Friedrichs-Lewy (CFL) stability condition: dt <= 1 / (c_f * sqrt(1/dx^2 + 1/dy^2))
    const double cfl = 0.5;
    const double dt  = cfl / (p.c_f * std::sqrt(1.0 / (dx * dx) + 1.0 / (dy * dy)));
    const int n_steps = static_cast<int>((10.0 / drive_freq_hz) / dt); // 10 resonant cycles

    BoundaryLayerResult bl = computeBoundaryLayer(p, drive_freq_hz);
    double Z_wall = computeNMEWallImpedance(p, eps_ac);
    double Z_fluid = p.rho_f * p.c_f;
    double refl_coeff = (Z_wall - Z_fluid) / (Z_wall + Z_fluid);

    // Damping coefficient \sigma_bl from Stokes-Kirchhoff boundary layer
    double sigma_bl = 2.0 * p.c_f * bl.alpha_bl;

    std::vector<double> P(Nx * Ny, 0.0);
    std::vector<double> vx(Nx * Ny, 0.0);
    std::vector<double> vy(Nx * Ny, 0.0);
    std::vector<double> gradP_mag(Nx * Ny, 0.0);

    auto idx = [Ny](int i, int j) { return i * Ny + j; };

    for (int step = 0; step < n_steps; ++step) {
        double t = step * dt;

        // 1. Update particle velocities v_x, v_y from -\nabla P
        for (int i = 0; i < Nx - 1; ++i) {
            for (int j = 0; j < Ny - 1; ++j) {
                double dPdx = (P[idx(i + 1, j)] - P[idx(i, j)]) / dx;
                double dPdy = (P[idx(i, j + 1)] - P[idx(i, j)]) / dy;
                vx[idx(i, j)] = (1.0 - sigma_bl * dt) * vx[idx(i, j)] - (dt / p.rho_f) * dPdx;
                vy[idx(i, j)] = (1.0 - sigma_bl * dt) * vy[idx(i, j)] - (dt / p.rho_f) * dPdy;
            }
        }

        // 2. Update acoustic pressure P from -\rho_f c_f^2 (\nabla \cdot v)
        double bulk_f = p.rho_f * p.c_f * p.c_f;
        for (int i = 1; i < Nx - 1; ++i) {
            for (int j = 1; j < Ny - 1; ++j) {
                double dvxdx = (vx[idx(i, j)] - vx[idx(i - 1, j)]) / dx;
                double dvydy = (vy[idx(i, j)] - vy[idx(i, j - 1)]) / dy;
                P[idx(i, j)] -= bulk_f * dt * (dvxdx + dvydy);
            }
        }

        // 3. Soft-source injection at longitudinal antinode (x = 0.05 m, y = Ly/2)
        int src_i = 1;
        int src_j = Ny / 2;
        P[idx(src_i, src_j)] += P_source_Pa * std::sin(2.0 * PI * drive_freq_hz * t) * (dt * drive_freq_hz);

        // 4. Impedance-matched NME rock boundary condition at walls
        for (int j = 0; j < Ny; ++j) {
            P[idx(0, j)]      = refl_coeff * P[idx(1, j)];
            P[idx(Nx - 1, j)] = refl_coeff * P[idx(Nx - 2, j)];
        }
        for (int i = 0; i < Nx; ++i) {
            P[idx(i, 0)]      = refl_coeff * P[idx(i, 1)];
            P[idx(i, Ny - 1)] = refl_coeff * P[idx(i, Ny - 2)];
        }
    }

    // Compute peak spatial pressure gradient |\nabla P_ac|
    double max_gradP = 0.0;
    for (int i = 1; i < Nx - 1; ++i) {
        for (int j = 1; j < Ny - 1; ++j) {
            double gx = (P[idx(i + 1, j)] - P[idx(i - 1, j)]) / (2.0 * dx);
            double gy = (P[idx(i, j + 1)] - P[idx(i, j - 1)]) / (2.0 * dy);
            gradP_mag[idx(i, j)] = std::sqrt(gx * gx + gy * gy);
            if (gradP_mag[idx(i, j)] > max_gradP) max_gradP = gradP_mag[idx(i, j)];
        }
    }

    std::cout << "FDTD Simulation Complete | f = " << drive_freq_hz << " Hz\n"
              << "  Viscous BL thickness delta_v : " << bl.delta_visc * 1e3 << " mm\n"
              << "  Thermal BL thickness delta_t : " << bl.delta_therm * 1e3 << " mm\n"
              << "  Cavity Quality Factor Q_bl   : " << bl.Q_cavity << "\n"
              << "  Wall Reflection Coeff R_NME  : " << refl_coeff << "\n"
              << "  Max Pressure Gradient |gradP|: " << max_gradP << " Pa/m\n";
}

} // namespace AcousticSim

int main() {
    AcousticSim::CavityParams params{};
    AcousticSim::runFDTD2D(params, 34.4, 2000.0, 1.5e-4);
    return 0;
}
