import json
import math
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import requests

BASE = "http://igets.u-strasbg.fr"
CACHE = Path(__file__).resolve().parent / "e4_cache"
OUT_JSON = Path(__file__).resolve().parent / "e4_lunar_residual_output.json"

STATIONS = {
    "st026": {
        "dirn_path": "SG/st026/Level3",
        "file_tpl": "IGETS-SG-RESMIN-st026-{ym}r2.ggp",
        "months_main": [("2011-%02d" % m) for m in range(1, 13)] * 1
        + ["2012-%02d" % m for m in range(1, 13)]
        + ["2013-%02d" % m for m in range(1, 13)]
        + ["2014-%02d" % m for m in range(1, 13)]
        + ["2015-%02d" % m for m in range(1, 13)]
        + ["2016-%02d" % m for m in range(1, 13)]
        + ["2017-%02d" % m for m in range(1, 13)]
        + ["2018-%02d" % m for m in range(1, 12)],
        "overlap": [("2016-%02d" % m) for m in range(1, 13)]
        + ["2017-%02d" % m for m in range(1, 13)]
        + ["2018-%02d" % m for m in range(1, 12)],
        "split_half_cut": "2015-01",
    },
    "dj060": {
        "dirn_path": "SG/dj060/Level3",
        "file_tpl": "IGETS-SG-RESMIN-dj060-{ym}r2.ggp",
        "months_main": [("2016-%02d" % m) for m in range(1, 13)]
        + ["2017-%02d" % m for m in range(1, 13)]
        + ["2018-%02d" % m for m in range(1, 13)],
        "overlap": [("2016-%02d" % m) for m in range(1, 13)]
        + ["2017-%02d" % m for m in range(1, 13)]
        + ["2018-%02d" % m for m in range(1, 13)],
        "split_half_cut": "2017-07",
    },
}

TARGETS = [
    ("lunar_synodic", 29.530588),
    ("lunar_tropical", 27.212221),
    ("lunar_anomalistic_Mm", 27.554549),
    ("fortnightly_Mf", 13.660791),
    ("MSf", 14.765282),
    ("M2", 360.0 / 28.9841042 / 24.0),
    ("S2", 0.5),
    ("N2", 360.0 / 28.4397295 / 24.0),
    ("K2", 360.0 / 30.0821373 / 24.0),
    ("O1", 360.0 / 13.9430357 / 24.0),
    ("K1", 360.0 / 15.0410686 / 24.0),
    ("P1", 360.0 / 14.9589314 / 24.0),
    ("Q1", 360.0 / 13.3986609 / 24.0),
]

G_REF_NMS2 = 9.81e9
GAP_VAL = 99999.999
RETRY = 3


def fetch_months(sta, months):
    cfg = STATIONS[sta]
    cdir = CACHE / sta
    cdir.mkdir(parents=True, exist_ok=True)
    ok, missing, failed = [], [], []
    sess = requests.Session()
    for ym in months:
        fname = cfg["file_tpl"].format(ym=ym.replace("-", ""))
        dest = cdir / fname
        if dest.exists() and dest.stat().st_size > 1000:
            ok.append(str(dest))
            continue
        url = "%s/%s/%s" % (BASE, cfg["dirn_path"], fname)
        got = False
        for _ in range(RETRY):
            try:
                r = sess.get(url, timeout=120)
                if r.status_code == 200 and len(r.content) > 1000:
                    dest.write_bytes(r.content)
                    ok.append(str(dest))
                    got = True
                    break
                if r.status_code == 404:
                    missing.append(ym)
                    got = True
                    break
            except requests.RequestException:
                pass
        if not got:
            failed.append(ym)
    return ok, missing, failed


def parse_l3(paths):
    times_h, vals = [], []
    t0_ord = None
    for p in paths:
        with open(p, "r", encoding="ascii", errors="replace") as fh:
            for line in fh:
                if not line or not line[0].isdigit():
                    continue
                parts = line.split()
                if len(parts) < 3:
                    continue
                try:
                    date = int(parts[0])
                    hhmmss = int(parts[1])
                    res = float(parts[2])
                except ValueError:
                    continue
                y = date // 10000
                mo = (date // 100) % 100
                d = date % 100
                hours = hhmmss // 10000
                minutes = (hhmmss % 10000) // 100
                secs = hhmmss % 100
                minutes_f = minutes + secs / 60.0
                from datetime import date as _date

                ordn = _date(y, mo, d).toordinal()
                if t0_ord is None:
                    t0_ord = ordn
                if abs(res - GAP_VAL) < 0.05 or math.isnan(res):
                    continue
                times_h.append((ordn - t0_ord) * 24.0 + hours + minutes_f / 60.0)
                vals.append(res)
    return (
        np.asarray(times_h, dtype=np.float64),
        np.asarray(vals, dtype=np.float64),
        t0_ord,
    )


def hourly_mean(t_h, v):
    idx = np.floor(t_h).astype(np.int64)
    n = idx.max() + 1
    s = np.bincount(idx, weights=v, minlength=n)
    c = np.bincount(idx, minlength=n)
    good = c > 0
    t_day = np.full(n, np.nan)
    t_day[good] = (np.arange(n)[good] + 0.5) / 24.0
    vv = np.full(n, np.nan)
    vv[good] = s[good] / c[good]
    keep = ~np.isnan(vv)
    return t_day[keep], vv[keep]


def detrend_hourly(t_d, v):
    t0 = t_d.mean()
    x = t_d - t0
    cols = [
        np.ones_like(x),
        x,
        np.sin(2 * np.pi * t_d / 365.25),
        np.cos(2 * np.pi * t_d / 365.25),
        np.sin(2 * np.pi * t_d / 182.625),
        np.cos(2 * np.pi * t_d / 182.625),
    ]
    A = np.column_stack(cols)
    coef, *_ = np.linalg.lstsq(A, v, rcond=None)
    res = v - A @ coef
    return res, t0


def targeted_fit(t_d, resid, targets):
    n = len(t_d)
    cols = [np.ones(n), t_d - t_d.mean()]
    fr = []
    for name, per in targets:
        f = 1.0 / per
        fr.append(f)
        cols.append(np.sin(2 * np.pi * f * t_d))
        cols.append(np.cos(2 * np.pi * f * t_d))
    A = np.column_stack(cols)
    beta, residuals, rank, sv = np.linalg.lstsq(A, resid, rcond=None)
    fit = A @ beta
    r = resid - fit
    dof = max(n - A.shape[1], 1)
    s2 = float(r @ r) / dof
    try:
        cov = s2 * np.linalg.inv(A.T @ A)
    except np.linalg.LinAlgError:
        cov = s2 * np.linalg.pinv(A.T @ A)
    out = []
    k = 2
    for name, per in targets:
        a = beta[k]
        b = beta[k + 1]
        amp = math.hypot(a, b)
        phase = math.degrees(math.atan2(-b, a)) % 360.0
        va = cov[k, k]
        vb = cov[k + 1, k + 1]
        cab = cov[k, k + 1]
        var_amp = (a * a * va + b * b * vb + 2 * a * b * cab) / max(amp * amp, 1e-30)
        sig = math.sqrt(max(var_amp, 0.0))
        snr = amp / sig if sig > 0 else float("inf")
        ul95 = amp + 1.96 * sig
        out.append(
            {
                "name": name,
                "period_d": round(per, 6),
                "f_cpd": round(1.0 / per, 8),
                "amp_nms2": round(amp, 4),
                "sigma_nms2": round(sig, 4),
                "snr": round(snr, 3),
                "phase_deg": round(phase, 2),
                "ul95_nms2": round(ul95, 4),
                "ul95_dg_g": float("%.3e" % (ul95 / G_REF_NMS2)),
            }
        )
        k += 2
    return out, math.sqrt(s2)


def lomb_scan(t_d, resid, f_lo=0.03, f_hi=0.15, oversample=8):
    n = len(t_d)
    span = t_d.max() - t_d.min()
    df = 1.0 / (oversample * span)
    freqs = np.arange(f_lo, f_hi, df)
    p = np.zeros_like(freqs)
    for i, f in enumerate(freqs):
        w = 2 * np.pi * f
        w2w = w * t_d
        tau = np.arctan2(
            np.sum(np.sin(2 * w2w)), np.sum(np.cos(2 * w2w))
        ) / (2 * w)
        cw = np.cos(w * t_d - tau)
        sw = np.sin(w * t_d - tau)
        c2 = 2.0 * np.sum(cw * cw)
        p[i] = ((resid @ cw) ** 2 / c2 + (resid @ sw) ** 2 / c2) / max(
            resid @ resid, 1e-30
        ) * n
    z = p
    m_eff = int((f_hi - f_lo) * span) + 1
    fap = 1.0 - (1.0 - np.exp(-np.clip(z, 0, 700))) ** m_eff
    order = np.argsort(p)[::-1]
    peaks = []
    seen = []
    for i in order:
        f = freqs[i]
        if any(abs(f - fs) < 3 * df for fs in seen):
            continue
        lo = max(i - 40, 0)
        hi = min(i + 41, len(p))
        continuum = float(np.median(p[lo:hi]))
        peaks.append(
            {
                "period_d": round(1.0 / f, 5),
                "power": round(float(p[i]), 4),
                "continuum_ratio": round(float(p[i]) / continuum, 2) if continuum > 0 else None,
                "fap_white": float("%.3e" % fap[i]),
            }
        )
        seen.append(f)
        if len(peaks) >= 10:
            break
    return {"n_freqs": int(len(freqs)), "span_d": round(span, 2), "top_peaks": peaks}


def envelope_modulation(t_d, resid, carrier_per_d=360.0 / 28.9841042 / 24.0):
    w = 2.0 * np.pi / carrier_per_d
    zc = resid * np.exp(-1j * w * t_d)
    win = np.hanning(49)
    win /= win.sum()
    kernel = win.astype(np.complex128)
    pad = len(kernel) // 2
    zp = np.pad(zc, pad, mode="reflect")
    re = np.convolve(zp.real, win, mode="valid")
    im = np.convolve(zp.imag, win, mode="valid")
    env = np.hypot(re, im)
    env = env - env.mean()
    targets = [t for t in TARGETS[:5]]
    out, _ = targeted_fit(t_d, env, targets)
    for row in out:
        row["note"] = "amplitude of M2 complex envelope at this period (nm/s2 carrier units)"
    return out


def targeted_phase(t_d, resid, name, per):
    out, _ = targeted_fit(t_d, resid, [(name, per)])
    return out[0]


def month_to_day(ym):
    y, m = int(ym[:4]), int(ym[5:7])
    from datetime import date as _date

    return _date(y, m, 1).toordinal()


def analyze_station(sta, months, label):
    ok, missing, failed = fetch_months(sta, months)
    print(
        "[%s/%s] files ok=%d missing=%d failed=%d"
        % (sta, label, len(ok), len(missing), len(failed)),
        flush=True,
    )
    if not ok:
        return None
    t_h, v, t0_ord = parse_l3(ok)
    t_d, vv = hourly_mean(t_h, v)
    if len(t_d) < 1000:
        return None
    resid, t0 = detrend_hourly(t_d, vv)
    targets_out, resid_rms = targeted_fit(t_d, resid, TARGETS)
    blind = lomb_scan(t_d, resid)
    env = envelope_modulation(t_d, resid)
    return {
        "label": label,
        "months_requested": len(months),
        "files_ok": len(ok),
        "months_missing": missing,
        "months_failed": failed,
        "n_hourly": int(len(t_d)),
        "t_start_d": round(float(t_d.min()), 3),
        "t_end_d": round(float(t_d.max()), 3),
        "span_d": round(float(t_d.max() - t_d.min()), 2),
        "residual_rms_nms2": round(resid_rms, 3),
        "targets": targets_out,
        "blind_scan_month_band": blind,
        "m2_envelope_targets": env,
        "_t_d": t_d,
        "_resid": resid,
        "_t0_ord": t0_ord,
    }


def cross_compare(sta_a, sta_b):
    pairs = [
        ("lunar_synodic", 29.530588),
        ("M2", 360.0 / 28.9841042 / 24.0),
        ("O1", 360.0 / 13.9430357 / 24.0),
        ("K1", 360.0 / 15.0410686 / 24.0),
    ]
    rows = []
    for name, per in pairs:
        pa = targeted_phase(sta_a["_t_d"], sta_a["_resid"], name, per)
        pb = targeted_phase(sta_b["_t_d"], sta_b["_resid"], name, per)
        dphi = abs(pa["phase_deg"] - pb["phase_deg"])
        dphi = min(dphi, 360.0 - dphi)
        rows.append(
            {
                "target": name,
                "ampA": pa["amp_nms2"],
                "ampB": pb["amp_nms2"],
                "snrA": pa["snr"],
                "snrB": pb["snr"],
                "phaseA_deg": pa["phase_deg"],
                "phaseB_deg": pb["phase_deg"],
                "dphase_deg": round(dphi, 2),
                "coherent": bool(
                    pa["snr"] >= 3
                    and pb["snr"] >= 3
                    and dphi <= 60.0
                    and pa["amp_nms2"] > 0
                    and pb["amp_nms2"] > 0
                ),
            }
        )
    return rows


def split_half(res):
    t = res["_t_d"]
    r = res["_resid"]
    cut = month_to_day(STATIONS[res["sta"]]["split_half_cut"]) - res["_t0_ord"]
    m = t < cut
    rows = []
    for name, per in TARGETS[:5]:
        p1 = targeted_phase(t[m], r[m], name, per)
        p2 = targeted_phase(t[~m], r[~m], name, per)
        dphi = abs(p1["phase_deg"] - p2["phase_deg"])
        dphi = min(dphi, 360.0 - dphi)
        coh = complex(p1["amp_nms2"], 0) * np.exp(1j * np.radians(p1["phase_deg"]))
        coh2 = complex(p2["amp_nms2"], 0) * np.exp(1j * np.radians(p2["phase_deg"]))
        mean_vec = (coh + coh2) / 2.0
        rows.append(
            {
                "target": name,
                "amp_h1": p1["amp_nms2"],
                "amp_h2": p2["amp_nms2"],
                "phase_h1_deg": p1["phase_deg"],
                "phase_h2_deg": p2["phase_deg"],
                "dphase_deg": round(dphi, 2),
                "coherent_amp_nms2": round(float(abs(mean_vec)), 4),
            }
        )
    return rows


def strip_private(res):
    return {k: v for k, v in res.items() if not k.startswith("_")}


def main():
    import time

    CACHE.mkdir(parents=True, exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    t_start = time.time()

    res_main = analyze_station("st026", STATIONS["st026"]["months_main"], "main")
    if res_main is None:
        print("FATAL: no st026 data", file=sys.stderr)
        sys.exit(1)
    res_main["sta"] = "st026"

    res_ov_a = analyze_station("st026", STATIONS["st026"]["overlap"], "overlap")
    res_ov_a["sta"] = "st026"
    res_b = analyze_station("dj060", STATIONS["dj060"]["months_main"], "main")
    res_b["sta"] = "dj060"

    cross = cross_compare(res_ov_a, res_b)
    halves = split_half(res_main)

    candidates = []
    for row in res_main["targets"]:
        cmatch = next((c for c in cross if c["target"] == row["name"]), None)
        hmatch = next((h for h in halves if h["target"] == row["name"]), None)
        coherent_cross = bool(cmatch and cmatch["coherent"])
        coherent_time = bool(
            hmatch and hmatch["dphase_deg"] <= 60.0 and hmatch["amp_h1"] > 0
        )
        if row["snr"] >= 5 and (coherent_cross or coherent_time):
            candidates.append(
                {
                    "target": row["name"],
                    "amp_nms2": row["amp_nms2"],
                    "snr": row["snr"],
                    "coherent_cross_station": coherent_cross,
                    "coherent_split_half": coherent_time,
                }
            )

    verdict = {
        "status": "ANOMALY_CANDIDATE" if candidates else "NO_COHERENT_ANOMALY",
        "candidates": candidates,
        "upper_limits_95_nms2": {
            row["name"]: row["ul95_nms2"] for row in res_main["targets"]
        },
        "upper_limits_95_dg_g": {
            row["name"]: row["ul95_dg_g"] for row in res_main["targets"]
        },
        "interpretation": (
            "No coherent residual signal at hypothesised lunar periods above the "
            "95%% upper limits after IGETS Level-3 corrections (solid Earth tides, "
            "ocean tidal loading, polar motion, atmospheric loading and drift "
            "already removed). Limits expressed relative to g as dg/g."
            if not candidates
            else "Candidate(s) detected - see list; requires independent replication."
        ),
    }

    payload = {
        "experiment": "E4",
        "title": "Lunar-period residual search in superconducting-gravimeter data",
        "started_utc": started,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_s": round(time.time() - t_start, 1),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "data_source": {
            "service": "IGETS Level-3 via EOST Strasbourg (open access)",
            "base_url": BASE,
            "product": "IGETS-SG-RESMIN monthly residuals, 1-minute, res_fil in nm/s2",
            "citations": [
                "Boy, Rosat, Hinderer, Littel (2017): Superconducting Gravimeter Data "
                "from Strasbourg - Level 1. GFZ Data Services. doi:10.5880/igets.st.l1.001",
                "Boy, Rosat, Hinderer, Littel (2017): Superconducting Gravimeter Data "
                "from Djougou - Level 1. GFZ Data Services. doi:10.5880/igets.dj.l1.001",
                "EOST Level-2/3 processing: isdc.gfz.de/fileadmin/isdc/docs/EOSTproducts_v2.pdf",
            ],
            "level3_corrections_already_applied": [
                "solid Earth tides (DDW99 + HW95 / FES2014 ocean tides)",
                "ocean tidal loading",
                "polar motion + LOD rotation",
                "atmospheric loading (ERA5/IB + local pressure)",
                "instrumental drift (from absolute-gravimeter calibration)",
            ],
            "known_caveat": "C026 tilt-compensation malfunction late 2009-early 2010; analysis window starts 2011-01",
        },
        "method": {
            "sampling": "1-min files decimated to hourly means",
            "detrend": "mean, linear, annual and semiannual sinusoids removed",
            "targeted_fit": "joint least-squares sinusoid fit at %d known lunar/tidal frequencies; amplitudes in nm/s2; sigma from (A^T A)^-1 covariance" % len(TARGETS),
            "blind_scan": "Lomb-Scargle, periods 6.7-33 d (lunar month band), white-noise FAP approx + local continuum ratio (red-noise robust)",
            "envelope_test": "complex demodulation at M2 carrier; envelope scanned at lunar-month periods",
            "coherence_tests": [
                "split-half phase stability (st026 long span)",
                "cross-station phase comparison st026 vs dj060 on common epoch 2016-2018",
            ],
            "thresholds": {
                "candidate_snr": 5.0,
                "coherent_dphase_max_deg": 60.0,
                "coherent_snr_min": 3.0,
            },
        },
        "results": {
            "st026_main_2011_2018": strip_private(res_main),
            "st026_overlap_2016_2018": strip_private(res_ov_a),
            "dj060_main_2016_2018": strip_private(res_b),
            "cross_station_overlap": cross,
            "split_half_st026": halves,
        },
        "verdict": verdict,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=1), encoding="utf-8")
    print("verdict:", verdict["status"], flush=True)
    print("written:", OUT_JSON, flush=True)
    for row in res_main["targets"][:5]:
        print(
            "  %-22s amp=%8.3f  sigma=%7.3f  snr=%6.2f  ul95=%.3f"
            % (row["name"], row["amp_nms2"], row["sigma_nms2"], row["snr"], row["ul95_nms2"]),
            flush=True,
        )


if __name__ == "__main__":
    main()
