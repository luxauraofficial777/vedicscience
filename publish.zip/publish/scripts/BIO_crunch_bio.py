﻿import csv, json, hashlib, os, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(BASE, 'outputs')
os.makedirs(OUT, exist_ok=True)

# Biological energy/frequency anchors
anchors = {
    'ATP_hydrolysis_std_eV': 0.316,   # -30.5 kJ/mol
    'ATP_hydrolysis_cell_eV': 0.55,    # ~-53 kJ/mol cellular
    'GTP_hydrolysis_eV': 0.32,
    'phonon_20kHz_eV': 8.271e-11,
    'phonon_1kHz_eV': 4.136e-12,
    'phonon_440Hz_eV': 1.820e-12,
    'ultrasound_1.5MHz_eV': 6.204e-9,
    'visible_lower_Hz': 4e14,
}

rows = []
with open(os.path.join(BASE, 'claims_dataset_bio.csv'), encoding='utf-8') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

# compute
for row in rows:
    fhz = row.get('freq_Hz','').strip()
    eev = row.get('energy_eV','').strip()
    row['hf_eV'] = ''
    row['n_th_300K'] = ''
    row['regime'] = ''
    row['ratio_to_ATP'] = ''
    if fhz:
        f = float(fhz)
        hf = 6.62607015e-34 * f / 1.602176634e-19
        row['hf_eV'] = f'{hf:.6g}'
        kT = 8.617333262e-5 * 300
        n = 1.0/(math.exp(hf/kT)-1.0) if hf/kT > 0 else float('inf')
        row['n_th_300K'] = f'{n:.6g}'
        row['regime'] = 'quantum' if n < 1 else 'classical'
    if eev:
        e = float(eev)
        row['ratio_to_ATP'] = f'{e/anchors["ATP_hydrolysis_std_eV"]:.6g}'

# write ledger
ledger_path = os.path.join(OUT, 'bio_gradient_ledger.csv')
fields = list(rows[0].keys())
with open(ledger_path, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for row in rows:
        w.writerow(row)

# summary
summary = {
    'count_claims': len(rows),
    'count_with_freq': sum(1 for r in rows if r.get('freq_Hz','').strip()),
    'count_with_energy': sum(1 for r in rows if r.get('energy_eV','').strip()),
    'count_quantum': sum(1 for r in rows if r.get('regime')=='quantum'),
    'count_classical': sum(1 for r in rows if r.get('regime')=='classical'),
    'ATP_std_eV': anchors['ATP_hydrolysis_std_eV'],
    'phonon_20kHz_eV': anchors['phonon_20kHz_eV'],
    'ratio_phonon20k_to_ATP': anchors['phonon_20kHz_eV']/anchors['ATP_hydrolysis_std_eV'],
    'octaves_20kHz_to_ATPfreq': None,
}
# acoustic frequency whose quantum equals ATP energy: f = E/h
f_ATP = anchors['ATP_hydrolysis_std_eV'] * 1.602176634e-19 / 6.62607015e-34
summary['f_photon_equiv_ATP_Hz'] = f_ATP
summary['octaves_20kHz_to_ATP_equiv'] = math.log2(f_ATP/20000)

with open(os.path.join(OUT,'bio_summary.json'),'w',encoding='utf-8') as f:
    json.dump(summary, f, indent=2)

# chart
fig, ax = plt.subplots(figsize=(10,6))
cats = {}
for row in rows:
    c = row.get('category','other')
    cats.setdefault(c, []).append(row)
colors = {'biological anchor':'#1f77b4','genetic disease':'#d62728','cellular acoustics':'#2ca02c','Sound Logic cross-ref':'#9467bd'}
for c, rs in cats.items():
    fs = [float(r['freq_Hz']) for r in rs if r.get('freq_Hz','').strip()]
    ys = [0.5]*len(fs)
    ax.scatter(fs, ys, label=c, color=colors.get(c,'gray'), s=60, alpha=0.8)
ax.set_xscale('log')
ax.set_xlim(1e-2, 1e16)
ax.set_yticks([])
ax.set_xlabel('Frequency (Hz)')
ax.set_title('Biological/Cellular Acoustic Gradient')
for label, f in [('audible 20Hz',20),('20kHz',20000),('1.5MHz US',1.5e6),('ATP-equiv',f_ATP)]:
    ax.axvline(f, color='gray', linestyle='--', alpha=0.5)
    ax.text(f, 0.9, label, rotation=90, fontsize=8)
ax.legend(loc='lower right', fontsize=8)
fig.tight_layout()
fig.savefig(os.path.join(OUT,'bio_chart.png'), dpi=100)
plt.close(fig)

# manifest
manifest = []
for root,_,files in os.walk(BASE):
    for fn in files:
        if fn.endswith(('.csv','.json','.md','.png','.py')) and 'outputs' in root.replace('\\','/'):
            pass
# hash outputs + scripts
for d in ['outputs','scripts']:
    dd = os.path.join(BASE,d)
    for fn in sorted(os.listdir(dd)):
        fp = os.path.join(dd,fn)
        if os.path.isfile(fp) and fn != 'MANIFEST.sha256':
            h = hashlib.sha256(open(fp,'rb').read()).hexdigest()
            manifest.append(f"{h}  {d}/{fn}")
with open(os.path.join(OUT,'MANIFEST.sha256'),'w',encoding='utf-8') as f:
    f.write('\n'.join(manifest)+'\n')

print("exit 0; rows", len(rows))
