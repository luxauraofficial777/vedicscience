"""
format_all_substack_articles.py
-------------------------------
Fetches and parses all 5 published articles from @luxaura777's Substack RSS feed
and generates clean, Substack-ready Copy-Paste HTML versions in C:\\LuxAura\\study:

1. 01_Vedic_Metaphysics_Quantum_Energy_Guide.html
2. 02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html
3. 03_Lux_Aura_Infrastructure.html
4. 04_The_Calculus_of_Convergence.html
5. 05_Lux_Aura_Project_History_P2P_to_Digital_Temple.html
+ Substack_All_Articles_Index.html (Master Index Page)
"""

import xml.etree.ElementTree as ET
import html
import re
import os
import shutil

RSS_FILE = r"C:\Users\XFO777\.gemini\antigravity\brain\fbe4f341-b0f9-44d5-8712-600fa043f5cd\.system_generated\steps\94\content.md"
OUT_DIR = r"C:\LuxAura\study"
SUB_DIR = r"C:\LuxAura\study\substack_html"


def latex_to_unicode(text):
    """
    Converts inline LaTeX commands (\sigma, \frac, \text, \approx, etc.)
    into clean, readable Unicode mathematical typography for Substack.
    """
    s = html.unescape(text)

    # Remove [span_XX](start_span) and [span_XX](end_span) copy-paste artifacts (including split 's pan')
    s = re.sub(r'\[\s*s\s*p\s*a\s*n\s*_\s*\d+\s*\]\s*\(\s*(?:s\s*t\s*a\s*r\s*t|e\s*n\s*d)\s*_\s*s\s*p\s*a\s*n\s*\)', '', s)

    # Fix broken LaTeX tokens split by spaces in original paste (e.g. "\tex t", "\fra c", "\sigm a", "\tim es", "\app rox", "\ci rc")
    broken_fixes = [
        (r'\\tex\s*t', r'\\text'),
        (r'\\te\s*xt', r'\\text'),
        (r'\\t\s*ext', r'\\text'),
        (r'\\fra\s*c', r'\\frac'),
        (r'\\sigm\s*a', r'\\sigma'),
        (r'\\tim\s*es', r'\\times'),
        (r'\\app\s*rox', r'\\approx'),
        (r'\\ci\s*rc', r'\\circ'),
    ]
    for pat, rep in broken_fixes:
        s = re.sub(pat, lambda m, r=rep[1:]: r, s)

    # Iteratively strip formatting wrappers: \text{...}, \mathrm{...}, \mathbf{...}, \boldsymbol{...}, \mathbb{...}, \mathcal{...}, \operatorname{...}, \underbrace{...}
    for _ in range(8):
        s = re.sub(r'\\(?:text|mathrm|mathbf|boldsymbol|mathbb|mathcal|operatorname|underbrace)\{([^{}]*)\}', r'\1', s)

    # Handle \hat{x}, \dot{x}, \ddot{x}, \bar{x}, \tilde{x}, \vec{x}
    for _ in range(4):
        s = re.sub(r'\\hat\{([^{}]*)\}', r'\1̂', s)
        s = re.sub(r'\\dot\{([^{}]*)\}', r'\1̇', s)
        s = re.sub(r'\\ddot\{([^{}]*)\}', r'\1̈', s)
        s = re.sub(r'\\bar\{([^{}]*)\}', r'\1̄', s)
        s = re.sub(r'\\tilde\{([^{}]*)\}', r'\1̃', s)
        s = re.sub(r'\\vec\{([^{}]*)\}', r'\1⃗', s)

    # Handle \sqrt{...} and \frac{a}{b} iteratively from innermost braces outward
    for _ in range(8):
        s = re.sub(r'\\sqrt\{([^{}]*)\}', r'√(\1)', s)
        s = re.sub(r'\\frac\{([^{}]*)\}\{([^{}]*)\}', r'((\1) / (\2))', s)
        s = re.sub(r'\\(?:text|mathrm|mathbf|boldsymbol|mathbb|mathcal|operatorname|underbrace)\{([^{}]*)\}', r'\1', s)

    # Remove sizing macros
    s = re.sub(r'\\(?:left|right|bigl|bigr|Bigl|Bigr|quad|qquad|,|;|!)', ' ', s)

    # Replace common Greek & math LaTeX symbols (longest first so \varepsilon precedes \epsilon, \circ precedes \ci, etc.)
    replacements = [
        (r'^\circ', '°'), (r'\circ', '°'),
        (r'\varepsilon', 'ε'), (r'\varphi', 'φ'), (r'\vartheta', 'θ'),
        (r'\Delta', 'Δ'), (r'\Lambda', 'Λ'), (r'\Omega', 'Ω'), (r'\Psi', 'Ψ'),
        (r'\Phi', 'Φ'), (r'\Gamma', 'Γ'), (r'\Sigma', 'Σ'), (r'\Theta', 'Θ'), (r'\Xi', 'Ξ'),
        (r'\alpha', 'α'), (r'\beta', 'β'), (r'\gamma', 'γ'), (r'\delta', 'δ'),
        (r'\epsilon', 'ε'), (r'\zeta', 'ζ'), (r'\eta', 'η'),
        (r'\theta', 'θ'), (r'\kappa', 'κ'), (r'\lambda', 'λ'), (r'\mu', 'μ'),
        (r'\nu', 'ν'), (r'\xi', 'ξ'), (r'\pi', 'π'), (r'\rho', 'ρ'),
        (r'\sigma', 'σ'), (r'\tau', 'τ'), (r'\phi', 'φ'),
        (r'\chi', 'χ'), (r'\psi', 'ψ'), (r'\omega', 'ω'),
        (r'\hbar', 'ℏ'), (r'\ell', 'ℓ'), (r'\dagger', '†'),
        (r'\nabla', '∇'), (r'\partial', '∂'), (r'\infty', '∞'),
        (r'\int', '∫'), (r'\oint', '∮'), (r'\sum', '∑'), (r'\prod', '∏'),
        (r'\approx', '≈'), (r'\simeq', '≃'), (r'\sim', '∼'), (r'\propto', '∝'),
        (r'\equiv', '≡'), (r'\neq', '≠'), (r'\ne', '≠'),
        (r'\leq', '≤'), (r'\le', '≤'), (r'\geq', '≥'), (r'\ge', '≥'),
        (r'\ll', '≪'), (r'\gg', '≫'), (r'\lesssim', '≲'), (r'\gtrsim', '≳'),
        (r'\times', '×'), (r'\cdot', '·'), (r'\wedge', '∧'), (r'\pm', '±'), (r'\mp', '∓'),
        (r'\rightarrow', '→'), (r'\to', '→'), (r'\implies', '⇒'), (r'\iff', '⇔'),
        (r'\forall', '∀'), (r'\in', '∈'), (r'\subset', '⊂'),
        (r'\Vert', '‖'), (r'\vert', '|'), (r'\|', '‖'), (r'\langle', '⟨'), (r'\rangle', '⟩'),
        (r'\arctan', 'arctan'), (r'\tanh', 'tanh'), (r'\sinh', 'sinh'), (r'\cosh', 'cosh'),
        (r'\sin', 'sin'), (r'\cos', 'cos'), (r'\tan', 'tan'),
        (r'\ln', 'ln'), (r'\log', 'log'), (r'\exp', 'exp'),
        (r'\lim', 'lim'), (r'\min', 'min'), (r'\max', 'max'), (r'\det', 'det'),
        (r'\sqrt', '√'),
        (r'\%', '%'), (r'\{', '{'), (r'\}', '}'),
    ]
    for old, new in replacements:
        s = s.replace(old, new)

    # Second pass on \frac if any nested braces remained after symbol substitution
    for _ in range(4):
        s = re.sub(r'\\frac\{([^{}]*)\}\{([^{}]*)\}', r'((\1) / (\2))', s)

    # Clean up subscripts/superscripts braces like _{eff} -> _eff and ^{2} -> ²
    sup_map = {'0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '+': '⁺', '-': '⁻', '°': '°'}
    def replace_sup(m):
        val = m.group(1)
        if all(c in sup_map for c in val):
            return ''.join(sup_map[c] for c in val)
        return f'^({val})'

    s = re.sub(r'\^\{([^{}]+)\}', replace_sup, s)
    s = re.sub(r'\^([0-9])', lambda m: sup_map[m.group(1)], s)
    s = re.sub(r'\^°', '°', s)
    s = re.sub(r'_\{([^{}]+)\}', r'_\1', s)

    # Final safety sweep for any stray \text, \frac, or \underbrace without braces
    s = s.replace(r'\underbrace', '').replace(r'\text', '').replace(r'\frac', '').replace(r'\dot', '̇').replace(r'\hat', '̂')

    # Replace -- with en-dash in numeric ranges
    s = re.sub(r'(\d)--(\d)', r'\1–\2', s)
    s = re.sub(r'[ \t]{2,}', ' ', s)
    return s.strip()


def wrap_html_template(title, subtitle, pub_date, orig_url, body_html):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>{html.escape(title)} — Substack Copy-Paste Edition</title>
  <style>
    body {{
      font-family: Georgia, 'Spectral', serif;
      line-height: 1.68;
      max-width: 760px;
      margin: 40px auto;
      padding: 0 20px;
      color: #1a1a1a;
      background: #ffffff;
    }}
    .instructions {{
      background: #fff4ed;
      border-left: 4px solid #ff6719;
      padding: 16px 20px;
      margin-bottom: 32px;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
    }}
    .meta {{
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 13px;
      color: #666666;
      margin-bottom: 24px;
    }}
    h1, h2, h3, h4 {{
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: #111111;
      margin-top: 1.6em;
      margin-bottom: 0.5em;
      line-height: 1.3;
    }}
    h1 {{ font-size: 28px; margin-top: 0.5em; }}
    h2 {{ font-size: 22px; border-bottom: 1px solid #eeeeee; padding-bottom: 6px; }}
    h3 {{ font-size: 18px; color: #222222; }}
    p {{ margin: 0 0 1.15em 0; }}
    pre {{
      background: #f6f6f6;
      padding: 14px 18px;
      border-radius: 6px;
      overflow-x: auto;
      font-family: 'Consolas', 'Courier New', monospace;
      font-size: 13.5px;
      line-height: 1.5;
      margin: 1.2em 0;
    }}
    blockquote {{
      border-left: 3px solid #ff6719;
      margin: 1.2em 0;
      padding-left: 16px;
      color: #333333;
      font-style: italic;
    }}
    ul, ol {{ margin: 0 0 1.2em 1.4em; }}
    li {{ margin-bottom: 0.45em; }}
    hr {{
      border: none;
      border-top: 1px solid #e0e0e0;
      margin: 2.2em 0;
    }}
  </style>
</head>
<body>

<div class="instructions">
  <strong>Substack Copy-Paste Edition:</strong><br/>
  Original URL: <a href="{orig_url}" target="_blank">{orig_url}</a> ({pub_date})<br/>
  Select everything below the horizontal line, press <strong>Ctrl+C</strong>, and paste it directly into your Substack editor. All headings, paragraphs, Unicode equations, tables, and citations will format natively.
</div>

<hr/>

<h1>{html.escape(title)}</h1>
{f'<p class="meta"><em>{html.escape(subtitle)}</em></p>' if subtitle else ''}

{body_html}

</body>
</html>
"""


def format_wall_of_text_article(raw_html, section_markers, title_prefix_to_strip):
    """
    Formats Article 2 and Article 3, which were pasted into Substack as a single giant <p> block
    with embedded Roman numeral headings, numbered subheadings, raw LaTeX, and Works Cited.
    """
    text = html.unescape(re.sub(r'<[^>]+>', ' ', raw_html))
    text = re.sub(r'\s+', ' ', text).strip()

    if text.startswith(title_prefix_to_strip):
        text = text[len(title_prefix_to_strip):].strip()

    # Separate "Works cited" at the end
    works_cited_text = ""
    wc_idx = text.rfind("Works cited ")
    if wc_idx != -1:
        works_cited_text = text[wc_idx + len("Works cited "):].strip()
        text = text[:wc_idx].strip()

    # Find positions of all section markers in order
    cuts = []
    search_from = 0
    for tag, marker in section_markers:
        pos = text.find(marker, search_from)
        if pos != -1:
            cuts.append((pos, tag, marker))
            search_from = pos + len(marker)

    html_parts = []
    # Any intro text before first marker
    if cuts and cuts[0][0] > 0:
        intro = latex_to_unicode(text[:cuts[0][0]])
        if intro:
            html_parts.append(f"<p>{html.escape(intro)}</p>")

    for i, (pos, tag, marker) in enumerate(cuts):
        clean_heading = latex_to_unicode(marker)
        html_parts.append(f"<{tag}>{html.escape(clean_heading)}</{tag}>")

        start_body = pos + len(marker)
        end_body = cuts[i + 1][0] if (i + 1 < len(cuts)) else len(text)
        section_body = text[start_body:end_body].strip()

        if not section_body:
            continue

        section_body_clean = latex_to_unicode(section_body)

        # Split long section body into well-paced paragraphs of ~3-4 sentences each
        sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', section_body_clean)
        chunk = []
        char_len = 0
        for sent in sentences:
            chunk.append(sent)
            char_len += len(sent)
            if char_len >= 550 or len(chunk) >= 4:
                para_str = " ".join(chunk).strip()
                html_parts.append(f"<p>{html.escape(para_str)}</p>")
                chunk = []
                char_len = 0
        if chunk:
            para_str = " ".join(chunk).strip()
            html_parts.append(f"<p>{html.escape(para_str)}</p>")

    # Format Works Cited as a clean ordered list
    if works_cited_text:
        html_parts.append("<hr/>")
        html_parts.append("<h2>Works Cited</h2>")
        # Split on numbered citation markers: "1. ", "2. ", etc.
        cit_items = re.split(r'\s*(?:^|\s)(\d+)\.\s+(?=[A-Z"\'])', works_cited_text)
        # cit_items goes: ['', '1', 'text1', '2', 'text2', ...]
        html_parts.append("<ol>")
        for k in range(1, len(cit_items) - 1, 2):
            cit_body = cit_items[k + 1].strip()
            # Fix broken spaces inside URLs (e.g. "https://...huma n-endeavour...")
            cit_body = re.sub(r'(https?://[^\s]+)\s+([a-z0-9_\-/]+)', r'\1\2', cit_body)
            cit_escaped = html.escape(cit_body)
            # Autolink URLs
            cit_escaped = re.sub(
                r'(https?://[^\s,&lt;&gt;]+)',
                r'<a href="\1" target="_blank">\1</a>',
                cit_escaped
            )
            html_parts.append(f"  <li>{cit_escaped}</li>")
        html_parts.append("</ol>")

    return "\n".join(html_parts)


def format_article_4(raw_html):
    """
    Formats Article 4 ('The Calculus of Convergence'), repairing:
    - The 4 shattered tab-indented tables
    - Stripped inline mathematical symbols '(  )'
    - Missing standalone Temporal Drift equation after 'The equation is formulated as follows:'
    - Plaintext headings and bullet/numbered lists
    """
    p_list = [html.unescape(m).strip() for m in re.findall(r'<p>(.*?)</p>', raw_html, re.S)]

    # Restore stripped inline math variables where Substack left '(  )' or double spaces
    variable_fixes = [
        ("designated day (  )", "designated day (t_conv)"),
        ("Black Sun Pulse (  )", "Black Sun Pulse (P_bs)"),
        ("Sustained Inertia of Maya (  )", "Sustained Inertia of Maya (I_m)"),
        ("Gravity Wave Layering (  )", "Gravity Wave Layering (Ψ_g)"),
        ("clearing factor    [Image 1]", "clearing factor (Λ_sl) [Image 1]"),
        ("Logistics Trajectory   .", "Logistics Trajectory V(1..17)."),
        ("clearing factor    is established", "clearing factor (Λ_sl) is established"),
        ("pinned to the    grid", "pinned to the V(1..17) grid"),
        ("where    and    [Image 1]", "where Λ_sl → ∞ and ΔT_drift = 0 [Image 1]"),
        ("friction coefficient    by", "friction coefficient (μ) by"),
        ("Sound Logic Resonance    through", "Sound Logic Resonance (Λ_sl) through"),
        ("follows the    trajectory", "follows the V(1..17) trajectory"),
        ("gravity layering”   .", "gravity layering” (Ψ_g)."),
        ("maintain the trajectory   ,", "maintain the trajectory V(1..17),"),
        ("Logistics Trajectory", "Logistics Trajectory V(1..17)"),
        ("representation of the    logistics grid", "representation of the V(1..17) logistics grid"),
        ("frequencies along    is supported", "frequencies along V(1..17) is supported"),
        ("increase in the    pulse", "increase in the P_bs pulse"),
        ("clearing factor    is the", "clearing factor (Λ_sl) is the"),
        ("Using the    methodology", "Using the V(1..17) methodology"),
        ("Following the    path", "Following the V(1..17) path"),
        ("Amplifying the    clearing factor", "Amplifying the Λ_sl clearing factor"),
        ("distribution trajectory    is also", "distribution trajectory V(1..17) is also"),
        ("Day of Convergence” (  )", "Day of Convergence” (t_conv)"),
    ]

    h2_titles = {
        "The Equation of Temporal Drift and the Mandate of Sound Logic",
        "Spatial Mapping and the Topography of the Buri Friction Zone",
        "The V(1..17) Hyper-Spatial Logistics Grid and Assessment Methodology",
        "Redefining Distribution: From Broadcast to Vector Trajectory",
        "The Mandate of Sound Logic: Mathematical Truth and the Convergence",
        "Technical Synthesis: Reconfiguring the Lux Aura Distribution",
        "Deep Dive: The Buri Multiplier and its Impact on Frequency Distribution",
        "Hardware Integrity and the “Black Hole” Thermal Profile",
        "Redefining the Logistics Trajectory V(1..17)",
        "Conclusion: The Path to Robust Beauty",
        "Extended Analysis: Harmonizing Node Population and Population Density",
        "Strategic Operations: The “V-1 (17 March 1998)” Standard",
        "Final Tactical Summary",
        "Works cited",
    }

    h3_titles = {
        "Analyzing the Numerator: Friction, Inertia, and the Black Sun",
        "The Geography of the Exit Vector",
        "The Buri Multiplier and Glacial Mass Analogs",
        "Applying the BEQUEST Toolkit to Frequency Nodes",
        "Mechanical Stabilization of the Nodes",
        "The Role of the Architect and Initiates",
        "Tactical Clumping vs. Dispersal",
        "Neutralizing the Numerator",
        "Logistics Tracking and Force Protection",
        "The Dynamics of Slope Breezes and Frequency Drift",
        "The Role of Supraglacial Debris and Debris-Covered Nodes",
        "Thermal Performance and Inverter Mode",
        "Material Science and Flame Resistance",
        "The Intelligence-Driven Trajectory",
        "The Role of the “Yorba Zergot” Clearing Factor",
    }

    out = []
    i = 0
    while i < len(p_list):
        line = p_list[i]
        for old, new in variable_fixes:
            line = line.replace(old, new)
        line = line.strip()

        # Skip duplicate main title in p[0]
        if i == 0 and line.startswith("The Calculus of Convergence:"):
            i += 1
            continue

        # Reconstruct Table 1 (Variable | Logical Function | Source of Resistance | Mitigation Strategy)
        if line == "Variable" and i + 12 < len(p_list):
            out.append("""<pre>Variable               | Logical Function               | Source of Resistance           | Mitigation Strategy
-----------------------+--------------------------------+--------------------------------+--------------------------------------------------------
Black Sun Pulse (P_bs) | Intensity of the Central Plug  | Thermal / Temporal Suction     | Thermal dissipation via bonded fin technology [1]
Inertia of Maya (I_m)  | Friction from 300 Safety Loops | Artificial Loop Drag           | Reducing artificial friction via Sound Logic [Image 1]
Gravity Layering (Ψ_g) | Glue for Physical Constants    | 3D Gravitational Drag Layering | Utilizing the V(1..17) exit vector to bypass 3D drag</pre>""")
            i += 13
            continue

        # Reconstruct Table 2 (Map Location | Coordinates (X, Y) | Functional Significance | Logistical Requirement)
        if line == "Map Location" and i + 19 < len(p_list):
            out.append("""<pre>Map Location         | Coordinates | Functional Significance          | Logistical Requirement
---------------------+-------------+----------------------------------+-------------------------------------------------------
Sector AZ-9          |   (-7, 0)   | Starting Logistics Point         | Synchronization and calibration of nodes [Image 3]
Lux Aura Temple      |   (-3, 5)   | Anchor for Sound Logic           | Boosting the clearing factor (Λ_sl) [Image 1]
Black Hole Plug      |   (8, -8)   | Critical Hazard / Temporal Sink  | Absolute avoidance; thermal hazard zone [2]
Beacon of True North |   (0, 0)    | V₀ Primary Exit Vector           | Convergence point for all initiated nodes [Image 3]</pre>""")
            i += 20
            continue

        # Reconstruct Table 3 (Factor | Glacial Analog | Hyper-Spatial Impact | Distribution Adjustment)
        if line == "Factor" and i + 15 < len(p_list):
            out.append("""<pre>Factor              | Glacial Analog    | Hyper-Spatial Impact                          | Distribution Adjustment
--------------------+-------------------+-----------------------------------------------+----------------------------------------------------------
Debris Cover        | 300 Safety Loops  | Reduces "melt" (loss) but adds inertia weight | Balancing safety layers to prevent signal smothering
Ice Cliffs          | High-Shear Zones  | Areas of intense energy absorption and loss   | Plotting trajectories to avoid the (8, -8) hazard zone
Surface Sublimation | Energy Leakage    | Minor daily loss with large cumulative effect | Implementing BEQUEST Method 19 sustainability monitoring</pre>""")
            i += 16
            continue

        # Reconstruct Table 4 (Tactical Element | Source of Logic | Distribution Implementation)
        if line == "Tactical Element" and i + 17 < len(p_list):
            out.append("""<pre>Tactical Element       | Source of Logic | Distribution Implementation
-----------------------+-----------------+-------------------------------------------------------------------
Exit Vector (V₀)       | Image 3         | The primary path through the Beacon of True North (0, 0).
Clearing Factor (Λ_sl) | Image 1, [5]    | Amplified at the Temple relay using the Yorba Zergot protocol.
Temporal Sink (P_bs)   | Image 1, [1]    | Avoided via (8, -8) hazard mapping and bonded-fin heat sinks.
Mass Budget            | [6]             | Managed via earth observation of "summer temperature" intensity.
Force Protection       | [13]            | Intelligence-led monitoring of the V(1..17) trajectory.</pre>""")
            i += 18
            continue

        if line in h2_titles:
            if line == "Works cited":
                out.append("<hr/>")
                out.append("<h2>Works Cited</h2>")
                out.append("<ol>")
                i += 1
                while i < len(p_list):
                    cit = re.sub(r'^\d+\.\s*', '', p_list[i].strip())
                    cit_esc = html.escape(cit)
                    cit_esc = re.sub(r'(https?://[^\s,&lt;&gt;]+)', r'<a href="\1" target="_blank">\1</a>', cit_esc)
                    out.append(f"  <li>{cit_esc}</li>")
                    i += 1
                out.append("</ol>")
                break
            else:
                out.append(f"<h2>{html.escape(line)}</h2>")
                i += 1
                continue

        if line in h3_titles:
            out.append(f"<h3>{html.escape(line)}</h3>")
            i += 1
            continue

        # Restore missing equation block after "The equation is formulated as follows:"
        if line == "The equation is formulated as follows:":
            out.append(f"<p>{html.escape(line)}</p>")
            out.append("""<pre>ΔT_drift = ∫_{t₀}^{t_conv} [ (P_bs · I_m · Ψ_g) / Λ_sl(ω, Y_z) ] dt  ⟶  0   (as Λ_sl ⟶ ∞)</pre>""")
            i += 1
            continue

        # Convert bullet items starting with "* "
        if line.startswith("*"):
            out.append("<ul>")
            while i < len(p_list) and p_list[i].strip().startswith("*"):
                b_line = p_list[i].strip().lstrip("*").strip()
                for old, new in variable_fixes:
                    b_line = b_line.replace(old, new)
                out.append(f"  <li>{html.escape(b_line)}</li>")
                i += 1
            out.append("</ul>")
            continue

        # Convert numbered items starting with "1. ", "2. ", etc.
        if re.match(r'^\d+\.\s+', line):
            out.append("<ol>")
            while i < len(p_list) and re.match(r'^\d+\.\s+', p_list[i].strip()):
                n_line = re.sub(r'^\d+\.\s+', '', p_list[i].strip())
                for old, new in variable_fixes:
                    n_line = n_line.replace(old, new)
                out.append(f"  <li>{html.escape(n_line)}</li>")
                i += 1
            out.append("</ol>")
            continue

        out.append(f"<p>{html.escape(line)}</p>")
        i += 1

    return "\n".join(out)


def format_article_5(raw_html):
    """
    Formats Article 5 ('Lux Aura Project History: From P2P Archives to Digital Temple.'),
    removing '<p><span>Plaintext</span></p>' artifacts, cleaning double <code> tags,
    removing the embedded subscription widget form, and reconstructing the mashed Section 4 table.
    """
    s = raw_html
    # Remove duplicate H1 inside body since template adds H1
    s = re.sub(r'<h1>.*?</h1>', '', s, flags=re.S)
    # Remove subscription widget divs
    s = re.sub(r'<div class="subscription-widget-wrap-editor".*?</div></div></div>', '', s, flags=re.S)
    # Remove <p><span>Plaintext</span></p>
    s = re.sub(r'<p>\s*<span>Plaintext</span>\s*</p>', '', s)
    # Clean nested <code><code> inside <pre>
    s = s.replace('<pre><code><code>', '<pre>').replace('</code></code></pre>', '</pre>')

    # Replace the mashed Section 4 Artist Roster paragraph with a clean aligned <pre> table + list
    mashed_pattern = r'<p><strong>Artist / ProjectContribution to the Paradigm.*?Humanfobia</span></strong><span>Severe, boundary-pushing experimental textures challenging standard auditory fidelity\.</span></p>'
    clean_roster_html = """<pre>Artist / Project          | Contribution to the Paradigm
--------------------------+--------------------------------------------------------------------------------
Community Compilations    | Multi-artist archives acting as historical snapshots of the network's evolution.
Xmortal &amp; Desolation Sound| Providers of deep, brooding, industrial-tinged sonic architectures.
Fauxmusica                | Cinematic, high-logic atmospheric arrangements exploring liminality.
Sacred Star               | The historical, occult-laden pulse originating from the 2012 New York archives.
Humanfobia                | Severe, boundary-pushing experimental textures challenging standard fidelity.</pre>"""
    s = re.sub(mashed_pattern, clean_roster_html, s, flags=re.S)
    return s


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(SUB_DIR, exist_ok=True)

    with open(RSS_FILE, "r", encoding="utf-8", errors="ignore") as f:
        raw = f.read()

    root = ET.fromstring(raw[raw.find("<?xml"):])
    items = root.findall(".//item")

    # 1. Copy our already perfected Article 1 HTML to 01_Vedic_Metaphysics_Quantum_Energy_Guide.html
    art1_src = os.path.join(OUT_DIR, "Substack_Ready_Master_Report.html")
    art1_dst = os.path.join(SUB_DIR, "01_Vedic_Metaphysics_Quantum_Energy_Guide.html")
    if os.path.exists(art1_src):
        shutil.copyfile(art1_src, art1_dst)
        shutil.copyfile(art1_src, os.path.join(OUT_DIR, "01_Vedic_Metaphysics_Quantum_Energy_Guide.html"))

    # 2. Format Article 2: Physical, Quantum, and Thermodynamic Implications of Acoustic Sculpture
    it2 = items[1]
    c2 = [c.text for c in it2 if "encoded" in c.tag][0]
    markers_2 = [
        ("h2", "I. Macro-Physical and Fluid-Acoustic Dynamics"),
        ("h3", "1. Rayleigh-Plesset Cavitation and Shockwave Physics at the Mineral Interface"),
        ("h3", "2. Acoustic Softening, the Blaha Effect, and Dislocation Mobility in Igneous Rocks"),
        ("h3", "3. Monolithic Mass Removal, Energy Budgets, and Subterranean Helmholtz Eigenmodes"),
        ("h2", "II. Sub-Physical and Quantum Lattice Mechanics"),
        ("h3", "1. Phonon-Electron Interactions, Coherent Lattice Excitation, and Metamaterial Dispersion"),
        ("h3", "2. Dislocation Tunneling, Kink-Pair Nucleation, and Zero-Point Field Coupling"),
        ("h3", "3. Sound Logic (\\Lambda_{sl}) as a Sub-Physical Field Operator and Manifold Synchronizer"),
        ("h2", "III. Thermodynamic Implications and Entropy Calculus"),
        ("h3", "1. Non-Equilibrium Thermodynamics and Entropy Flux in Acoustic-Fluid Cutting"),
        ("h3", "2. Suppressing the Black Sun Sink (P_{bs}) and Hardware Thermal Management"),
        ("h3", "3. The \"Negative Melt\" Energy Budget and V(1..17) Hyper-Spatial Logistics"),
        ("h2", "IV. Synthesis and Analytical Conclusions"),
    ]
    body2 = format_wall_of_text_article(
        c2,
        markers_2,
        "Physical, Quantum, and Thermodynamic Implications of Acoustic Sculpture and Sound Logic Theorems"
    )
    html2 = wrap_html_template(
        "Physical, Quantum, and Thermodynamic Implications of Acoustic Sculpture",
        "Macro-Physical Cavitation, Sub-Physical Lattice Mechanics, and Non-Equilibrium Entropy Calculus",
        it2.findtext("pubDate"),
        it2.findtext("link"),
        body2
    )
    for d in (SUB_DIR, OUT_DIR):
        with open(os.path.join(d, "02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html"), "w", encoding="utf-8") as f:
            f.write(html2)

    # 3. Format Article 3: Lux Aura Infrastructure
    it3 = items[2]
    c3 = [c.text for c in it3 if "encoded" in c.tag][0]
    markers_3 = [
        ("h2", "I. Core Frameworks and Telemetry Architecture"),
        ("h3", "1. Lux Aura Global Reset, A7 Resonance Telemetry, and Cache Dehydration Mechanics"),
        ("h3", "2. The Equation of Temporal Drift and Liminal Seal Manifold Calculus"),
        ("h3", "3. Hyper-Spatial Logistics, Sector AZ-9 Topography, and the Buri Multiplier"),
        ("h2", "II. Core Hypothesis: Acoustic Sculpture and Sonic Water-Saw Dynamics"),
        ("h3", "1. Acoustic Cavitation, Rayleigh-Plesset Bubble Collapse, and Micro-Jet Fracture Mechanics"),
        ("h3", "2. Vibrational Lattice Excitation, Acoustic Softening, and the Kailasa Temple Verification"),
        ("h3", "Subterranean Chamber Amplification and the Chevalier Paradigm"),
        ("h2", "III. Required Analytical Deliverables"),
        ("h3", "1. Deliverable 1: Mathematical Validation Linking Cavitation Gradient to Structural Inertia and Temporal Lag"),
        ("h3", "2. Deliverable 2: Logistical Feasibility Matrix and Hardware Thermal Dissipation Profiles"),
        ("h3", "3. Deliverable 3: Synthesis Report on Sound Logic as the Primary Filter for Harmonic Engineering"),
    ]
    body3 = format_wall_of_text_article(
        c3,
        markers_3,
        "Comprehensive Analytical Study of Lux Aura Infrastructure, Sound Logic Calculus, and Acoustic Sculpture Mechanics"
    )
    html3 = wrap_html_template(
        "Lux Aura Infrastructure",
        "Comprehensive Analytical Study of Lux Aura Infrastructure, Sound Logic Calculus, and Acoustic Sculpture Mechanics",
        it3.findtext("pubDate"),
        it3.findtext("link"),
        body3
    )
    for d in (SUB_DIR, OUT_DIR):
        with open(os.path.join(d, "03_Lux_Aura_Infrastructure.html"), "w", encoding="utf-8") as f:
            f.write(html3)

    # 4. Format Article 4: The Calculus of Convergence
    it4 = items[3]
    c4 = [c.text for c in it4 if "encoded" in c.tag][0]
    body4 = format_article_4(c4)
    html4 = wrap_html_template(
        "The Calculus of Convergence",
        "Reconfiguring Lux Aura Frequency Distribution via the V(1..17) Hyper-Spatial Logistics Framework",
        it4.findtext("pubDate"),
        it4.findtext("link"),
        body4
    )
    for d in (SUB_DIR, OUT_DIR):
        with open(os.path.join(d, "04_The_Calculus_of_Convergence.html"), "w", encoding="utf-8") as f:
            f.write(html4)

    # 5. Format Article 5: Lux Aura Project History: From P2P Archives to Digital Temple
    it5 = items[4]
    c5 = [c.text for c in it5 if "encoded" in c.tag][0]
    body5 = format_article_5(c5)
    html5 = wrap_html_template(
        "Lux Aura Project History: From P2P Archives to Digital Temple",
        "The Seventeen-Year Evolution of Lux Aura (2009–2026)",
        it5.findtext("pubDate"),
        it5.findtext("link"),
        body5
    )
    for d in (SUB_DIR, OUT_DIR):
        with open(os.path.join(d, "05_Lux_Aura_Project_History_P2P_to_Digital_Temple.html"), "w", encoding="utf-8") as f:
            f.write(html5)

    # 6. Create Master Index Page: Substack_All_Articles_Index.html
    index_html = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>LuxAuraOfficial (@luxaura777) — Formatted Substack HTML Archive</title>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 820px;
      margin: 40px auto;
      padding: 0 20px;
      background: #0f141c;
      color: #e6edf3;
      line-height: 1.6;
    }
    h1 { color: #ffffff; margin-bottom: 6px; }
    .sub { color: #8b949e; margin-bottom: 28px; font-size: 14px; }
    .card {
      background: #18202c;
      border: 1px solid #2a364b;
      border-left: 4px solid #ff6719;
      border-radius: 8px;
      padding: 18px 22px;
      margin-bottom: 16px;
    }
    .card h2 { margin: 0 0 6px 0; font-size: 18px; }
    .card h2 a { color: #38bdf8; text-decoration: none; }
    .card h2 a:hover { text-decoration: underline; }
    .card p { margin: 4px 0; font-size: 13.5px; color: #8b949e; }
    .badge {
      display: inline-block;
      background: rgba(255, 103, 25, 0.18);
      color: #ff8547;
      font-size: 11.5px;
      padding: 2px 8px;
      border-radius: 4px;
      margin-right: 8px;
    }
  </style>
</head>
<body>
  <h1>LuxAuraOfficial (@luxaura777) — Substack HTML Archive</h1>
  <div class="sub">All 5 published Substack articles cleaned, structured, and formatted for direct copy-paste into the Substack visual editor.</div>

  <div class="card">
    <h2><a href="01_Vedic_Metaphysics_Quantum_Energy_Guide.html">1. Vedic Metaphysics: Quantum Energy Guide</a></h2>
    <p><span class="badge">Oct 16, 2026</span> Consolidated 7-Module Technical Report (NME Softening, Negative Stiffness, Hugoniot Spikes, Convergence Integral &amp; Astra Audit)</p>
  </div>

  <div class="card">
    <h2><a href="02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html">2. Physical, Quantum, and Thermodynamic Implications of Acoustic Sculpture</a></h2>
    <p><span class="badge">Oct 15, 2026</span> Reconstructed from a single 69 KB paragraph into 4 Roman Sections, 9 Subsections, clean Unicode equations, and 23 linked Works Cited.</p>
  </div>

  <div class="card">
    <h2><a href="03_Lux_Aura_Infrastructure.html">3. Lux Aura Infrastructure</a></h2>
    <p><span class="badge">Oct 15, 2026</span> Reconstructed from a 58 KB wall of text into 3 Roman Sections, 9 Subsections, Unicode math typography, and 21 linked Works Cited.</p>
  </div>

  <div class="card">
    <h2><a href="04_The_Calculus_of_Convergence.html">4. The Calculus of Convergence</a></h2>
    <p><span class="badge">Oct 15, 2026</span> Rebuilt 4 shattered tables into aligned preformatted tables, restored all stripped inline math variables (ΔT_drift, P_bs, I_m, Ψ_g, Λ_sl, V(1..17)), and formatted all headings &amp; lists.</p>
  </div>

  <div class="card">
    <h2><a href="05_Lux_Aura_Project_History_P2P_to_Digital_Temple.html">5. Lux Aura Project History: From P2P Archives to Digital Temple</a></h2>
    <p><span class="badge">Jun 19, 2026</span> Removed "Plaintext" copy artifacts, cleaned ASCII pipeline diagrams, and reconstructed the Section 4 Artist Roster table.</p>
  </div>
</body>
</html>
"""
    for d in (SUB_DIR, OUT_DIR):
        with open(os.path.join(d, "Substack_All_Articles_Index.html"), "w", encoding="utf-8") as f:
            f.write(index_html)

    print("Successfully formatted all 5 Substack articles!")


if __name__ == "__main__":
    main()
