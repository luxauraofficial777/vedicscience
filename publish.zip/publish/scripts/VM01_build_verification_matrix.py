#!/usr/bin/env python3
"""
build_verification_matrix.py  —  VERIFICATION_MATRIX_01
=========================================================
Reads (read-only):
  ../hardening_SPH01/claims_ledger.csv, spectrum_ledger.csv, citations.jsonl, VEDIC_CONCORDANCE.csv
  the study corpus (for recurring-quantity grep; mirrors, caches and OpenCodeBP excluded)
Writes (into this folder):
  verification_matrix.csv        claims x gates (independence score, class drift, remediation)
  parallels_ledger.csv           recurring quantities: where they appear, origin, convergent vs propagated
  eigenmodes.json                SVD of the claim x evidence incidence matrix; mode labels; axiom projections
  physical_eigenmodes.csv        cavity / Earth / tidal / Schumann / big-science ladders + corpus coincidences
  charts/*.svg, *.png            eigenmode map, singular spectrum, mode loadings, spectrum-vs-ladders
  outputs/MANIFEST.sha256
Determinism: no RNG anywhere; SVD sign fixed by largest-|component| convention; matplotlib hashsalt fixed.
Evidence classes used below:  COMMAND = this script computed it;  DERIVATION = a rule I applied to ledger text;
                               SOURCE = copied from a ledger/citation file;  everything interpretive is in the report, not here.
"""
import csv, json, math, re, hashlib, sys
from pathlib import Path
from collections import OrderedDict, Counter
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["svg.hashsalt"] = "VERIFICATION_MATRIX_01"
matplotlib.rcParams["font.family"] = "DejaVu Sans"
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent.parent          # VERIFICATION_MATRIX_01/
STUDY = HERE.parent                                     # C:\LuxAura\study
HARD = STUDY / "hardening_SPH01"
OUT = HERE
(OUT / "charts").mkdir(exist_ok=True)
(OUT / "outputs").mkdir(exist_ok=True)

# ----------------------------------------------------------------------------------------------
# 0. Load ledgers (SOURCE)
# ----------------------------------------------------------------------------------------------
claims = pd.read_csv(HARD / "claims_ledger.csv")
spectrum = pd.read_csv(HARD / "spectrum_ledger.csv")
vedic = pd.read_csv(HARD / "VEDIC_CONCORDANCE.csv")
cites = [json.loads(l) for l in open(HARD / "citations.jsonl", encoding="utf-8")]
cite_status = {c["cite_id"]: c["verified_status"] for c in cites}

# ----------------------------------------------------------------------------------------------
# 1. Verification matrix  (DERIVATION: keyword rules applied to the ledger's evidence text)
# ----------------------------------------------------------------------------------------------
# External anchors named in evidence text -> registry id (or None if named but not registered)
EXT_ANCHORS = OrderedDict([
    ("MICROSCOPE",            ("Touboul2022_MICROSCOPE", r"MICROSCOPE")),
    ("Hofmann&Muller",        ("HofmannMuller2018_LLR", r"Hofmann")),
    ("IGETS",                 ("Boy2017_IGETS_Strasbourg", r"IGETS")),
    ("Collinson2024",         ("Collinson2024_AmbipolarField", r"Collinson")),
    ("Altmann2001",           ("Altmann2001_AcousticWeapons", r"Altmann")),
    ("Dales1964",             ("Dales1964_MohenjoDaro", r"Dales")),
    ("Pauwels&Bergier/Adamski", ("Colavito_FalseQuotes", r"Pauwels|Adamski")),
    ("Guyer&Johnson1999",     ("GuyerJohnson1999_NME", r"Guyer")),
    ("Plesset&Chapman1971",   ("PlessetChapman1971_Microjet", r"Plesset")),
    ("Petukhov&Pokrovskii",   ("PetukhovPokrovskii1973_Tunneling", r"Petukhov|C_PP")),
    ("Durr2008_QCD",          (None, r"D[üu]rr")),
    ("TenCate&Shankland1996", (None, r"TenCate")),
    ("Berktay1965",           (None, r"Berktay")),
    ("RRUFF",                 (None, r"RRUFF")),
    ("Granato-Lucke",         (None, r"Granato")),
    ("Blaha-Langenecker",     (None, r"Blaha")),
    ("IEEE/CRC",              (None, r"IEEE|CRC")),
    ("PREM/IceCube",          (None, r"PREM|IceCube")),
    ("Davenport&Vincenti",    (None, r"Davenport")),
    ("Rigveda-primary-text",  (None, r"Rigveda|\bRV \d")),
    ("archaeometry-lit",      (None, r"archaeometry|literature")),
    ("standard-value-unnamed",(None, r"^Standard |Order-of-magnitude|Historical chronicle")),
])
SCRIPT_RE = re.compile(r"([A-Za-z0-9_]+\.py)|Exact match")
RECALC_RE = re.compile(r"Formula gives|Exact arithmetic|Exact longitudinal|Exact backbone|Exact Rankine|gives [0-9STQ]|= *-?[0-9]|\d\s*[*/]\s*\d|log10")
HARDEN_RE = re.compile(r"\b(C[1-4]|M[1-8])\b")
STRENGTH = {"SOURCE": 3, "COMMAND": 3, "DERIVATION": 2, "HYPOTHESIS": 1, "ALLEGORY": 0}
V2_EXISTS = {"Task_01_Acoustic_Softening_NME_Report.md": "Task_01_v2.md",
             "Task_02_Energy_Scaling_Matrix_Report.md": "Task_02_v2.md",
             "Task_04_Astra_Data_Hardening_Protocol_Report.md": "Task_04_v2.md",
             "Standard_Dislocation_Tunneling_Reference.md": "Standard_Dislocation_Tunneling_Reference_v2.md"}
vedic_linked = set()
for s in vedic["linked_claims"].fillna(""):
    for tok in re.split(r"[,\s]+", s):
        if tok: vedic_linked.add(tok)

rows = []
for _, r in claims.iterrows():
    ev = str(r.evidence)
    ext = [k for k,(cid,pat) in EXT_ANCHORS.items() if re.search(pat, ev)]
    ext_fetched = [k for k in ext if EXT_ANCHORS[k][0] and cite_status.get(EXT_ANCHORS[k][0]) == "FETCHED_VERIFIED"]
    ext_named_unreg = [k for k in ext if EXT_ANCHORS[k][0] is None and k != "standard-value-unnamed"]
    scripts = sorted(set(m.group(1) for m in SCRIPT_RE.finditer(ev) if m.group(1)))
    r_script = bool(scripts) or ("Exact match" in ev)
    r_recalc = bool(RECALC_RE.search(ev))
    r_ext = bool(ext_fetched) or bool(ext_named_unreg) or any(EXT_ANCHORS[k][0] for k in ext)
    indep = int(r_ext) + int(r_script) + int(r_recalc)
    hard_ids = sorted(set(HARDEN_RE.findall(ev)))
    claimed = str(r.claimed_class); actual = str(r.actual_class)
    drift = STRENGTH.get(actual, 0) - STRENGTH.get(claimed, 0)
    v2 = V2_EXISTS.get(r.file)
    remediated = bool(v2) and r.verdict == "INCONSISTENT"
    rows.append(OrderedDict([
        ("claim_id", r.claim_id), ("file", r.file), ("line", r.line), ("band", r.band),
        ("quantity", r.quantity), ("value", r.value), ("unit", r.unit), ("freq_Hz", r.freq_Hz),
        ("verdict", r.verdict), ("claimed_class", claimed), ("actual_class", actual), ("class_drift", drift),
        ("G1_external_anchor", "|".join(ext) if ext else ""),
        ("G1a_fetched_registry", "|".join(ext_fetched)),
        ("G1b_named_not_registered", "|".join(ext_named_unreg)),
        ("G2_script_anchor", "|".join(scripts) if scripts else ("Exact match" if r_script else "")),
        ("G3_recomputed_by_hardening", int(r_recalc)),
        ("independence_score_0to3", indep),
        ("hardening_finding_ids", "|".join(hard_ids)),
        ("vedic_linked", int(bool(str(r.vedic_link) != "nan") or r.claim_id in vedic_linked)),
        ("v2_correction_file", v2 or ""),
        ("remediated_in_v2", int(remediated)),
        ("open_defect_no_v2", int(r.verdict in ("INCONSISTENT","PARTIAL","UNTESTABLE-AS-WRITTEN") and not v2)),
    ]))
vm = pd.DataFrame(rows)
vm.to_csv(OUT / "verification_matrix.csv", index=False)

# ----------------------------------------------------------------------------------------------
# 2. Parallels: recurring quantities across the corpus  (COMMAND for counts; origin labels are DERIVATION)
# ----------------------------------------------------------------------------------------------
# (label, regex, origin_class, origin_note)
SIG = [
 ("34.4 Hz chamber f_100",          r"34\.4\s*(Hz|\\text\{ ?Hz)",                     "COMMAND(sim_cavity_acoustics.py; f=c/2L_x, L_x=5.0 m assumed)", "designed-in, not measured; Barabar attribution unsourced (M3)"),
 ("57.1 Hz Karan Chaupar (ALBA)",   r"57\.1\s*(Hz|\\text\{ ?Hz)",                     "FRINGE/UNSOURCED (docket §5)",                                  "see physical_eigenmodes: box (0,1,0)=57.33 Hz, 0.4% apart — coincidence of two unverified numbers"),
 ("21.5 kHz NME drive",             r"21[.,]5\s*(kHz|\\text\{ ?kHz)|21,?500\s*Hz",     "INTERNAL design parameter",                                      "transducer choice; no natural ladder"),
 ("eps_ac = 1.5e-4",                r"1\.5\s*(\\times|×|x)\s*10\^?\{?-4\}?|1\.5e-4|1\.5×10⁻⁴", "INTERNAL design parameter",                               "operating strain; Q^-1=0.159 inside model"),
 ("S = 0.5600 backbone factor",     r"\b0\.5600?\b",                                   "COMMAND(sim)+DERIVATION(T01-006 recomputed by hand)",           "CONVERGENT: two routes agree"),
 ("G_eff = 16.80 GPa",              r"16\.80?\s*(GPa|\\text\{ ?GPa)",                  "COMMAND(sim)+DERIVATION(hardening)",                            "CONVERGENT"),
 ("G_eff = 6.89 GPa (v1)",          r"6\.89\s*(GPa|\\text\{ ?GPa)",                    "INTERNAL-UNSOURCED (Task_01 v1 via Re[D]=0.450)",                "PROPAGATED then SUPERSEDED by v2"),
 ("Re[D] = 0.450 dispersion",       r"\b0\.450\b",                                     "INTERNAL-UNSOURCED",                                            "no drive frequency stated; removed in v2 (C2)"),
 ("q_hold = 7.256 MW/m^3",          r"7\.25(6|62)?\s*(MW|\\text\{ ?MW)|7\.26\s*(MW|\\text\{ ?MW)", "DERIVATION(hardening: ½ωG₀ε²Q⁻¹)",                    "CONVERGENT across v2 / BAND_V / ONION; single formula though"),
 ("V_active = 3.445 L",             r"3\.44(5)?\s*(L\b|\\text\{ ?L)|3\.45\s*(L\b|\\text\{ ?L)", "DERIVATION(hardening: 25 kW / q_hold)",                 "depends entirely on q_hold"),
 ("24,725 masons (v1)",             r"24,?725",                                        "INTERNAL-ARITHMETIC-ERROR (double-counted η)",                  "SUPERSEDED by 989"),
 ("989 masons",                     r"\b989\b",                                        "DERIVATION(hardening)",                                         "replacement value"),
 ("1,570.80 Pa/m analytic gradient", r"1,?570\.80?",                                   "DERIVATION(analytic k·P_antinode)",                             "FDTD code gives 1.74 Pa/m — V3 unreconciled"),
 ("1.74 Pa/m FDTD gradient",        r"1\.74\s*(Pa|\\text\{ ?Pa)",                      "COMMAND(sim_cavity_acoustics.cpp, not run to steady state)",    "V3 open"),
 ("2.15 GW/m^3 vitrification",      r"2\.15\s*(GW|\\text\{ ?GW)|2,?150\s*(MW|\\text\{ ?MW)|2\.15\s*(\\times|×|x)\s*10\^?\{?9", "DERIVATION outside model domain (Q⁻¹=1.06>1, C1)", "flagged C1 in v2; REUSED in CERN_ITER doc"),
 ("8.21 GPa Hugoniot stagnation",   r"8\.21(3)?\s*(GPa|\\text\{ ?GPa)",                "COMMAND(verify_metamaterial_and_hugoniot.py) on FITTED ξ_jet",   "math exact, input fitted (M1), ÷15 MPa category error (M2)"),
 ("xi_jet = 25.085 (fitted)",       r"25\.085",                                        "INTERNAL-FITTED to 3.25 GPa target",                            "reverse-fit; implies v_jet≈2.2 km/s vs measured 80–200 m/s"),
 ("Q = 1941 chamber",               r"1,?941",                                         "COMMAND(sim: Stokes–Kirchhoff)",                                "exact for idealized box"),
 ("delta_bl = 0.552 mm",            r"0\.552\s*(mm|\\text\{ ?mm)|0\.000552",           "COMMAND(sim)",                                                  ""),
 ("Mm 27.55 d anomalistic",         r"27\.55",                                         "SOURCE(IGETS)+COMMAND(e4 scripts)",                             "pre-registered verdict: known-geophysical; ONION §4 re-grades post hoc"),
 ("Synodic 29.53 d",                r"29\.53",                                         "SOURCE(IGETS)+COMMAND(e4)",                                     "NULL, UL 0.459 nm/s²"),
 ("I/MR^2 = 0.3307",                r"0\.3307",                                        "SOURCE(geodesy; not re-fetched)",                               ""),
 ("eta_MICROSCOPE 1.5e-15",         r"1\.5\s*(\\times|×|x)\s*10\^?\{?-15\}?|1\.5e-15|1\.5×10⁻¹⁵|1\.5 parts in 10\^15", "SOURCE(fetched: Touboul 2022)", "docket writes +1.5; paper −1.5 (seed #14)"),
 ("dg/g < 5e-14 (docket §7b)",      r"5\s*(\\times|×|x)\s*10\^?\{?-14\}?|5×10⁻¹⁴|10⁻¹³ g",  "INTERNAL-ARITHMETIC-ERROR",                                "0.459 nm/s² ÷ 9.81 m/s² = 4.7×10⁻¹¹, not 5×10⁻¹⁴ (3 orders)"),
 ("dg/g < 4.7e-11 (ledger)",        r"4\.7e-11|4\.68e-11|4\.7\s*(\\times|×|x)\s*10\^?\{?-11", "DERIVATION(hardening)",                                  "correct value"),
 ("Berktay −86.2 dB",               r"86\.20?\b",                                      "DERIVATION 40·log10(1000/7)",                                   "CONVERGENT (ACB, Task_04_v2, BAND_V)"),
 ("Q_d^2 = 816 Narayanastra",       r"\b816(\.3)?\b",                                  "COMMAND(script damping γ_d=0.035)",                             "replaces 10³–10⁴"),
 ("T2 = 2,046.5 K Mach 5.5",        r"2,?046\.5",                                      "DERIVATION(hardening Rankine–Hugoniot)",                        "v1 printed 2,038"),
 ("T2 = 2,038 K (v1)",              r"2,?038\s*(K|\\text\{ ?K)",                       "INTERNAL-ARITHMETIC-ERROR",                                     "SUPERSEDED"),
 ("ΔP = 3.41 MPa (v1)",             r"3\.41\s*(MPa|\\text\{ ?MPa)",                    "INTERNAL (confused 34.17 atm with 3.41 MPa)",                   "SUPERSEDED by 3.462"),
 ("R_a 0.1–0.5 mm (unit error)",    r"0\.1\s*[–-]\s*0\.5\s*(mm|\\text\{ ?mm)",         "INTERNAL-UNIT-ERROR (mm vs µm)",                                "no Task_03 v2 exists"),
 ("0S0 = 0.8147 mHz",               r"0\.8147",                                        "SOURCE(seismology; not re-fetched)",                            ""),
 ("Schumann 7.83 Hz",               r"7\.83",                                          "SOURCE(not re-fetched)",                                        ""),
 ("7 Hz parametric beat",           r"\b7(\.0)?\s*(Hz|\\text\{ ?Hz)",                  "INTERNAL design target",                                        "10.6% below Schumann f₁ — not a match"),
 ("ITER 170 GHz ECRH",              r"170\s*(GHz|\\text\{ ?GHz)",                      "SOURCE(fetched: iter.org)",                                     ""),
 ("ITER 0.595 MW/m^3 bulk",         r"0\.595",                                         "COMMAND(phase4: 500 MW / 840 m³)",                              "arithmetic OK; comparison to rock is ANALOGY"),
 ("3,360× ITER skin/bulk",          r"3,?360",                                         "COMMAND(phase4)",                                               "ratio of two engineering numbers"),
 ("19,185× corpus skin/bulk",       r"19,?185",                                        "COMMAND(phase4: 7.256 / 0.000378)",                             "holding-loss ÷ diluted-average — not a measured concentration; tagged COMMAND in CERN_ITER doc"),
]
SCAN_EXCLUDE = {"e4_cache", "OpenCodeBP", "img", "__pycache__", "reports", "src", "substack_html", "VERIFICATION_MATRIX_01"}
SCAN_EXT = {".md", ".html", ".py", ".json", ".jsonl", ".csv", ".txt"}
files = []
for p in sorted(STUDY.rglob("*")):
    if p.is_file() and p.suffix.lower() in SCAN_EXT and not (set(p.relative_to(STUDY).parts[:-1]) & SCAN_EXCLUDE):
        files.append(p)
texts = {}
for p in files:
    try: texts[p] = p.read_text(encoding="utf-8", errors="ignore")
    except Exception: texts[p] = ""
prow = []
for label, pat, origin, note in SIG:
    rx = re.compile(pat)
    hits = {str(p.relative_to(STUDY)).replace("\\","/"): len(rx.findall(t)) for p,t in texts.items()}
    hits = {k:v for k,v in hits.items() if v}
    n_files = len(hits); n_hits = sum(hits.values())
    orig_up = origin.upper()
    if "ERROR" in orig_up or "SUPERSEDED" in note.upper():
        cls = "PROPAGATED-SUPERSEDED" if n_files else "RETIRED"
    elif "ANALOGY" in note.upper(): cls = "ANALOGY-RATIO"
    elif "UNSOURCED" in orig_up or "FRINGE" in orig_up or "FITTED" in orig_up: cls = "PROPAGATED-UNSOURCED"
    elif "CONVERGENT" in note.upper() or ("+" in origin): cls = "CONVERGENT-MULTI-ROUTE"
    elif orig_up.startswith("INTERNAL"): cls = "DESIGN-PARAMETER"
    else: cls = "SINGLE-ROUTE"
    top = sorted(hits.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
    prow.append(OrderedDict([("quantity", label), ("n_files", n_files), ("n_hits", n_hits),
                             ("classification", cls), ("origin_class", origin), ("note", note),
                             ("top_files", "; ".join(f"{k}({v})" for k,v in top))]))
pl = pd.DataFrame(prow)
pl.to_csv(OUT / "parallels_ledger.csv", index=False)

# ----------------------------------------------------------------------------------------------
# 3. Eigenmodes of the claim × evidence structure  (COMMAND: SVD; feature construction is DERIVATION)
# ----------------------------------------------------------------------------------------------
def doc_group(f):
    f = str(f)
    if f.startswith("Task_"): return "doc:"+f[:7]
    if f.startswith("Consolidated"): return "doc:Master"
    if f[:2].isdigit() and f.endswith(".html"): return "doc:Article"+f[:2]
    if f.startswith("Standard_Mineral"): return "doc:StdMineral"
    if f.startswith("Standard_Dislocation"): return "doc:StdTunnel"
    if f.startswith("THEOREM"): return "doc:Docket"
    if f.startswith("IDEAS"): return "doc:IdeasBrief"
    if f.startswith("ASTRA"): return "doc:AstraBrief"
    if f.startswith("HARDENING"): return "doc:HardeningRpt"
    return "doc:"+f
FAMILY = [
 ("fam:softening-chain",  r"G_eff|S_backbone|alpha_G|eps_th|eps_linear|Delta_tau|sigma_t|Re_K_eff|K_eff|Q_inv"),
 ("fam:excavation-budget", r"E_s_|V_exc|N_workers|Delta_t_active"),
 ("fam:cavitation-shock",  r"P_wh|P_Hugoniot|T2_and_dP|q_dot_vitr|Mohenjo|Fe3"),
 ("fam:cavity-acoustics",  r"f_100|Q_bl|R_a_|G_cross|K_exact|P_rad_cavity"),
 ("fam:infrasound-doppler",r"f_infrasound|Berktay|Q_d_squared"),
 ("fam:vedic-text",        r"Vajra_Rigveda|Mbh_fake|project_history"),
 ("fam:quantum-regime",    r"n_th|S_0_over|Q_eff_and|Xi_23D|P_bs|Psi_g|eta_MICROSCOPE"),
 ("fam:geophysics",        r"I_over_MR2|dg_over_g|V_ambipolar"),
 ("fam:spectroscopy",      r"nu_SiO|d_11"),
 ("fam:boundary-layer",    r"Buri"),
]
def fbin(f):
    try:
        f = float(f)
        if not np.isfinite(f) or f <= 0: return None
        return "f:1e%d" % int(math.floor(math.log10(f)))
    except Exception: return None

feat_rows = []
for _, r in vm.iterrows():
    fs = set()
    fs.add(doc_group(r.file))
    for b in str(r.band).split(","):
        b = b.strip()
        if b: fs.add("band:"+b)
    for k in str(r.G1_external_anchor).split("|"):
        if k: fs.add("ext:"+k)
    for k in str(r.G2_script_anchor).split("|"):
        if k: fs.add("script:"+k)
    for k in str(r.hardening_finding_ids).split("|"):
        if k: fs.add("harden:"+k)
    if r.vedic_linked: fs.add("vedic:linked")
    fb = fbin(r.freq_Hz)
    if fb: fs.add(fb)
    for fam, pat in FAMILY:
        if re.search(pat, str(r.quantity)): fs.add(fam)
    fs.add("verdict:"+str(r.verdict))      # included so modes can be read against verdicts; also reported without it
    feat_rows.append(fs)
feats = sorted(set().union(*feat_rows))
# Two matrices: with and without verdict features (the latter is the "blind" structure)
def build(exclude_prefix=None):
    cols = [f for f in feats if not (exclude_prefix and f.startswith(exclude_prefix))]
    B = np.zeros((len(feat_rows), len(cols)))
    for i, fs in enumerate(feat_rows):
        for j, c in enumerate(cols):
            if c in fs: B[i, j] = 1.0
    df_ = B.sum(0); df_[df_ == 0] = 1
    W = B / np.sqrt(df_)                       # idf-like: ubiquitous features down-weighted
    norms = np.linalg.norm(W, axis=1, keepdims=True); norms[norms == 0] = 1
    W = W / norms                              # unit-length claims
    return cols, B, W
cols_blind, B_blind, W_blind = build(exclude_prefix="verdict:")
U, s, Vt = np.linalg.svd(W_blind, full_matrices=False)
# sign convention: largest |feature loading| positive
for k in range(Vt.shape[0]):
    j = np.argmax(np.abs(Vt[k]));
    if Vt[k, j] < 0: Vt[k] *= -1; U[:, k] *= -1
ids = vm.claim_id.tolist()
verd = vm.verdict.tolist()
health = np.array([{"CONSISTENT":1.0,"INCONSISTENT":-1.0}.get(v,0.0) for v in verd])
K = 6
modes = []
for k in range(K):
    u = U[:, k]; v = Vt[k]
    top_f_pos = [(cols_blind[j], round(float(v[j]),3)) for j in np.argsort(-v)[:6] if v[j] > 0.05]
    top_f_neg = [(cols_blind[j], round(float(v[j]),3)) for j in np.argsort(v)[:6] if v[j] < -0.05]
    order = np.argsort(-np.abs(u))
    top_c = [(ids[i], round(float(u[i]),3), verd[i]) for i in order[:10]]
    w = np.abs(u) / np.abs(u).sum()
    comp = Counter()
    for i in order[:12]: comp[verd[i]] += 1
    modes.append(OrderedDict([
        ("mode", k+1), ("singular_value", round(float(s[k]),4)),
        ("variance_fraction", round(float(s[k]**2 / (s**2).sum()),4)),
        ("features_positive", top_f_pos), ("features_negative", top_f_neg),
        ("claims_top12_verdicts", dict(comp)),
        ("health_weighted_(-1..1)", round(float((w*health).sum()),3)),
        ("claims_top10", top_c),
    ]))
# Axiom projections (DERIVATION: membership sets from THEOREM_DOCKET §1/§6 and band reports)
AXIOMS = OrderedDict([
 ("A1_frequency_fundamental", ["TD01-001","A02-001","SDT-001","SDT-002","A02-002"]),
 ("A2_resonance_cancellation", ["TD01-002","A04-001","T01-011","M01-004","T05-002"]),
 ("A3_inner_earth_engine",     ["TD01-003","A03-001","IRB01-001"]),
 ("A4_engineered_constants",   ["TD01-004","TD01-001"]),
 ("CORE_NME_engineering (credible core per docket §6)", ["T01-001","T01-003","T01-004","T01-005","T01-006","T01-007","T03-001","T03-002","T03-003","T05-001","M01-001","A01-001","SMR-001","SMR-002","SMR-003","HR01-001"]),
])
idx = {c:i for i,c in enumerate(ids)}
A = W_blind @ W_blind.T                       # claim-claim affinity (cosine on evidence features)
axproj = OrderedDict()
for name, members in AXIOMS.items():
    m = [idx[c] for c in members if c in idx]
    centroid = U[m, :K].mean(0)
    # nearest non-member claims by affinity
    aff = A[m].mean(0);
    for i in m: aff[i] = -9
    nn = [(ids[i], round(float(aff[i]),3), verd[i]) for i in np.argsort(-aff)[:6]]
    hv = health[m]
    axproj[name] = OrderedDict([("members", members), ("centroid_modes_1to6", [round(float(x),3) for x in centroid]),
                                ("member_health_mean", round(float(hv.mean()),3)),
                                ("nearest_non_member_claims", nn)])
# Spectral clustering (deterministic): normalized Laplacian of affinity graph, signs of eigenvectors 2–3
Aff = A.copy(); np.fill_diagonal(Aff, 0); Aff[Aff < 0] = 0
d = Aff.sum(1); d[d == 0] = 1e-12
Dm = np.diag(1/np.sqrt(d)); L = np.eye(len(ids)) - Dm @ Aff @ Dm
ew, ev = np.linalg.eigh(L)
fied = ev[:, 1]; third = ev[:, 2]
for vec in (fied, third):
    j = np.argmax(np.abs(vec));
    if vec[j] < 0: vec *= -1
clusters = {}
for i, c in enumerate(ids):
    key = ("+" if fied[i] >= 0 else "-") + ("+" if third[i] >= 0 else "-")
    clusters.setdefault(key, []).append((c, verd[i]))
cluster_summary = OrderedDict()
for key in sorted(clusters):
    mem = clusters[key]; cnt = Counter(v for _, v in mem)
    cluster_summary[key] = OrderedDict([("n", len(mem)), ("verdicts", dict(cnt)), ("claims", [c for c,_ in mem])])
eig_out = OrderedDict([
    ("method", "SVD of claim×evidence incidence (idf-weighted, row-normalized, verdict features EXCLUDED so structure is blind to outcome); "
               "spectral clustering = sign pattern of normalized-Laplacian eigenvectors 2,3 on cosine affinity. Deterministic."),
    ("n_claims", len(ids)), ("n_features_blind", len(cols_blind)), ("features", cols_blind),
    ("singular_values", [round(float(x),4) for x in s[:12]]),
    ("laplacian_eigenvalues_first8", [round(float(x),4) for x in ew[:8]]),
    ("modes", modes), ("axiom_projections", axproj), ("spectral_clusters_sign_e2e3", cluster_summary),
    ("claim_coordinates", {ids[i]: {"m1": round(float(U[i,0]),4), "m2": round(float(U[i,1]),4), "m3": round(float(U[i,2]),4),
                                    "fiedler": round(float(fied[i]),4), "e3": round(float(third[i]),4), "verdict": verd[i]} for i in range(len(ids))}),
])
(OUT / "eigenmodes.json").write_text(json.dumps(eig_out, indent=1, ensure_ascii=False), encoding="utf-8")

# ----------------------------------------------------------------------------------------------
# 4. Physical eigenmodes  (COMMAND for cavity ladder; SOURCE-not-refetched for Earth/tidal/Schumann)
# ----------------------------------------------------------------------------------------------
Lx, Ly, Lz, c = 5.0, 3.0, 2.5, 344.0              # from sim_cavity_acoustics.py defaults (SOURCE)
cav = []
for nx in range(0, 6):
    for ny in range(0, 5):
        for nz in range(0, 4):
            if nx == ny == nz == 0: continue
            f = (c/2) * math.sqrt((nx/Lx)**2 + (ny/Ly)**2 + (nz/Lz)**2)
            if f <= 160: cav.append((f, f"({nx},{ny},{nz})"))
cav.sort()
ladders = []
for f, lab in cav: ladders.append(("cavity 5.0×3.0×2.5 m (COMMAND)", lab, f))
EARTH = [("0S2", 0.30945e-3), ("0T2", 0.3794e-3), ("0S3", 0.46856e-3), ("0S4", 0.64707e-3), ("0S0", 0.81466e-3), ("1S2", 0.6798e-3)]
for lab, f in EARTH: ladders.append(("Earth normal modes (SOURCE, standard values not re-fetched)", lab, f))
TIDAL = [("Mm 27.5546 d", 1/(27.5546*86400)), ("Mf 13.6608 d", 1/(13.6608*86400)), ("synodic 29.5306 d", 1/(29.5306*86400)),
         ("O1", 1.0758e-5), ("K1", 1.1606e-5), ("M2", 2.2364e-5), ("S2", 2.3148e-5)]
for lab, f in TIDAL: ladders.append(("lunar/tidal (SOURCE, IGETS/standard)", lab, f))
for n, f in [(1,7.83),(2,14.3),(3,20.8),(4,27.3),(5,33.8)]: ladders.append(("Schumann (SOURCE, not re-fetched)", f"SR{n}", f))
for lab, f in [("ITER ICRH 40–55 MHz", 47.5e6), ("LHC RF 400.8 MHz", 400.8e6), ("ITER ECRH 170 GHz", 170e9)]: ladders.append(("big science (SOURCE, fetched)", lab, f))
for lab, f in [("Fe–O 432 cm⁻¹", 1.287e13), ("Si–O–Si 464 cm⁻¹", 1.384e13), ("Si–O 1000 cm⁻¹", 2.984e13), ("O–H 3625 cm⁻¹", 1.0837e14)]: ladders.append(("chemistry (SOURCE, RRUFF/NIST)", lab, f))
lad = pd.DataFrame(ladders, columns=["ladder","mode","f_Hz"])
# coincidence search: corpus frequencies vs every ladder line
corpus_f = spectrum[spectrum.category == "Corpus"][["spectrum_id","label","f_Hz"]].copy()
extra = [("SP-09b","Chamber 3rd harmonic 103.2 Hz",103.2)]
corpus_f = pd.concat([corpus_f, pd.DataFrame(extra, columns=corpus_f.columns)], ignore_index=True)
coinc = []
for _, r in corpus_f.iterrows():
    lad["rel"] = np.abs(np.log10(lad.f_Hz) - np.log10(r.f_Hz))
    j = lad.rel.idxmin(); row = lad.loc[j]
    pct = 100*(r.f_Hz/row.f_Hz - 1)
    status = "BY-CONSTRUCTION" if row.ladder.startswith("cavity") and abs(pct) < 0.5 else ("NEAR (<5%)" if abs(pct) < 5 else "NO MATCH")
    coinc.append(OrderedDict([("spectrum_id", r.spectrum_id), ("corpus_label", r.label), ("f_corpus_Hz", r.f_Hz),
                              ("nearest_ladder", row.ladder), ("nearest_mode", row["mode"]), ("f_ladder_Hz", round(float(row.f_Hz),6)),
                              ("offset_pct", round(float(pct),2)), ("status", status)]))
lad.drop(columns=["rel"]).to_csv(OUT / "physical_eigenmodes.csv", index=False)
pd.DataFrame(coinc).to_csv(OUT / "spectrum_coincidences.csv", index=False)
# degeneracies in the box
deg = {}
for f, lab in cav: deg.setdefault(round(f, 2), []).append(lab)
degen = {k: v for k, v in deg.items() if len(v) > 1}

# ----------------------------------------------------------------------------------------------
# 5. Charts (light surface; status palette for verdicts + marker shape as second channel)
# ----------------------------------------------------------------------------------------------
SURF, INK, INK2, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9"
VCOL = {"CONSISTENT":"#0ca30c", "INCONSISTENT":"#d03b3b", "PARTIAL":"#fab219", "UNTESTABLE-AS-WRITTEN":"#898781"}
VMK  = {"CONSISTENT":"o", "INCONSISTENT":"X", "PARTIAL":"^", "UNTESTABLE-AS-WRITTEN":"s"}
def style(ax):
    ax.set_facecolor(SURF)
    for sp in ("top","right"): ax.spines[sp].set_visible(False)
    for sp in ("left","bottom"): ax.spines[sp].set_color("#c3c2b7")
    ax.tick_params(colors=MUTED, labelsize=8); ax.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
def save(fig, name):
    fig.patch.set_facecolor(SURF)
    fig.savefig(OUT/"charts"/f"{name}.svg", metadata={"Date": None, "Creator": None}, bbox_inches="tight")
    fig.savefig(OUT/"charts"/f"{name}.png", dpi=160, metadata={"Software": None}, bbox_inches="tight")
    plt.close(fig)

# 5a eigenmode map: left = SVD modes 1–2 (engineering spread); right = Laplacian e2–e3 (cluster separation)
AXSHORT = {"A1_frequency_fundamental":"A1", "A2_resonance_cancellation":"A2", "A3_inner_earth_engine":"A3",
           "A4_engineered_constants":"A4", "CORE_NME_engineering (credible core per docket §6)":"CORE"}
def ax_centroid(members, X, Y):
    m = [idx[c] for c in members if c in idx]; return float(np.mean(X[m])), float(np.mean(Y[m]))
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(17, 7.6))
for ax, X, Y, xl, yl, ttl in (
    (ax1, U[:,0], U[:,1], f"Mode 1 loading (σ₁={s[0]:.2f}, {100*s[0]**2/(s**2).sum():.1f}% of structure)",
     f"Mode 2 loading (σ₂={s[1]:.2f}, {100*s[1]**2/(s**2).sum():.1f}%)", "A. SVD modes 1–2: the engineering chain spreads; every axiom sits at the origin"),
    (ax2, fied, third, "Laplacian eigenvector 2 (Fiedler)", "Laplacian eigenvector 3",
     "B. Spectral-cluster coordinates: four evidence communities")):
    style(ax)
    for v in VCOL:
        m = [i for i in range(len(ids)) if verd[i] == v]
        ax.scatter(X[m], Y[m], s=64, c=VCOL[v], marker=VMK[v], edgecolors=SURF, linewidths=1.0, label=f"{v} (n={len(m)})", zorder=3)
    # direct labels: alternate offsets to reduce collisions; skip labels in the dense origin blob of panel A
    for i in range(len(ids)):
        if ax is ax1 and abs(X[i]) < 0.06 and abs(Y[i]) < 0.03: continue
        dx, dy = (3, 3) if i % 2 == 0 else (3, -8)
        ax.annotate(ids[i], (X[i], Y[i]), fontsize=6.0, color=INK2, xytext=(dx, dy), textcoords="offset points")
    for name, d_ in axproj.items():
        cx, cy = ax_centroid(d_["members"], X, Y)
        ax.scatter([cx],[cy], s=240, marker="*", c="#2a78d6", edgecolors=INK, linewidths=0.8, zorder=4)
        ax.annotate(AXSHORT[name], (cx,cy), fontsize=8.5, color="#2a78d6", weight="bold", xytext=(7,-3), textcoords="offset points")
    ax.axhline(0, color="#c3c2b7", lw=0.8); ax.axvline(0, color="#c3c2b7", lw=0.8)
    ax.set_xlabel(xl, color=INK2); ax.set_ylabel(yl, color=INK2); ax.set_title(ttl, color=INK, fontsize=10, loc="left")
ax1.annotate("A1–A4 + allegory rows\n(unlabeled blob)", (0.02, 0.0), fontsize=7.5, color=INK2, xytext=(-5, 40), textcoords="offset points",
             arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
ax1.legend(loc="lower left", fontsize=7.5, frameon=False)
fig.suptitle("Claim–evidence eigenmode map (verdict-blind; ★ = centroid of A1–A4 and of the credible NME core)", color=INK, fontsize=11, x=0.01, ha="left")
fig.tight_layout(); save(fig, "eigenmode_map")

# 5b singular spectrum
fig, ax = plt.subplots(figsize=(7, 3.6)); style(ax)
frac = s**2/(s**2).sum()
ax.bar(np.arange(1, 13), frac[:12], color="#2a78d6", width=0.7)
ax.plot(np.arange(1, 13), np.cumsum(frac)[:12], color=INK2, lw=2, marker="o", ms=4)
ax.set_xlabel("mode k", color=INK2); ax.set_ylabel("fraction of structure (σₖ²/Σσ²)", color=INK2)
ax.set_title("Singular spectrum of the claim×evidence matrix (bars) and cumulative (line)", color=INK, fontsize=10, loc="left")
save(fig, "singular_spectrum")

# 5c mode loadings (features) for modes 1–4
fig, axes = plt.subplots(1, 4, figsize=(16, 5.2))
for k, ax in enumerate(axes):
    style(ax); v = Vt[k]
    order = np.argsort(-np.abs(v))[:12][::-1]
    colors = ["#2a78d6" if v[j] >= 0 else "#e34948" for j in order]
    ax.barh([cols_blind[j] for j in order], [v[j] for j in order], color=colors, height=0.6)
    ax.axvline(0, color="#c3c2b7", lw=0.8); ax.set_title(f"Mode {k+1}  (σ={s[k]:.2f})", color=INK, fontsize=10, loc="left")
    ax.tick_params(axis="y", labelsize=7.5)
fig.suptitle("What each eigenmode is made of — top feature loadings (blue +, red −)", color=INK, fontsize=11, x=0.01, ha="left")
fig.tight_layout(); save(fig, "mode_loadings")

# 5d spectrum vs physical ladders (position carries identity; one ink)
fig, ax = plt.subplots(figsize=(14, 6)); style(ax); ax.grid(False)
ladder_names = list(OrderedDict.fromkeys(lad.ladder))
rows_y = {n: i for i, n in enumerate(ladder_names)}
for _, r in lad.iterrows():
    y = rows_y[r.ladder]; ax.vlines(math.log10(r.f_Hz), y-0.32, y+0.32, color=INK2, lw=1.2)
    if r.ladder.startswith(("Earth","lunar","Schumann","big","chem")):
        ax.text(math.log10(r.f_Hz), y+0.36, r["mode"], fontsize=6, color=MUTED, rotation=60, ha="left", va="bottom")
yc = len(ladder_names)
SHORT = {"SP-06":"7 Hz beat", "SP-08":"34.4 Hz f₁₀₀", "SP-09":"68.8 Hz", "SP-09b":"103.2 Hz", "SP-12":"20 kHz cavitation",
         "SP-13":"20.95 kHz metamaterial", "SP-14":"21.5 kHz NME drive", "SP-15":"25 kHz Glauber ref", "SP-16":"40 kHz carriers", "SP-19":"10 GHz phonon"}
corpus_sorted = corpus_f.sort_values("f_Hz").reset_index(drop=True)
for n, (_, r) in enumerate(corpus_sorted.iterrows()):
    x = math.log10(r.f_Hz)
    ax.scatter([x], [yc], s=60, c="#eb6834", marker="D", edgecolors=SURF, zorder=4)
    lift = 0.35 + 0.45 * (n % 3)                         # stagger stacked labels in the 20–40 kHz cluster
    ax.plot([x, x], [yc + 0.12, yc + lift - 0.05], color=MUTED, lw=0.5)
    ax.text(x, yc + lift, SHORT.get(r.spectrum_id, r.label[:22]), fontsize=7, color=INK2, ha="center", va="bottom")
for c_ in coinc:
    if c_["status"] != "NO MATCH":
        x = math.log10(c_["f_corpus_Hz"]); ax.plot([x, x], [yc, rows_y[c_["nearest_ladder"]]], color="#eb6834", lw=0.8, ls="--", alpha=0.7)
ax.set_yticks(list(rows_y.values()) + [yc]); ax.set_yticklabels(ladder_names + ["CORPUS claims"], fontsize=8, color=INK2)
ax.set_xlabel("log₁₀ frequency (Hz)", color=INK2); ax.set_xlim(-7, 15.5); ax.set_ylim(-0.6, yc+1.9)
ax.set_title("Corpus frequencies against physical eigenmode ladders (dashed = within 5 % of a ladder line)", color=INK, fontsize=11, loc="left", pad=14)
save(fig, "spectrum_vs_ladders")

# ----------------------------------------------------------------------------------------------
# 6. Summary JSON + manifest
# ----------------------------------------------------------------------------------------------
summary = OrderedDict([
    ("claims", len(vm)),
    ("verdicts", dict(Counter(vm.verdict))),
    ("independence_score_hist", {int(k): int(v) for k, v in Counter(vm.independence_score_0to3).items()}),
    ("claims_with_zero_independent_routes", vm[vm.independence_score_0to3 == 0].claim_id.tolist()),
    ("class_drift_hist", {int(k): int(v) for k, v in Counter(vm.class_drift).items()}),
    ("downgraded_claims", vm[vm.class_drift < 0].claim_id.tolist()),
    ("remediated_in_v2", int(vm.remediated_in_v2.sum())),
    ("open_defects_without_v2", vm[vm.open_defect_no_v2 == 1].claim_id.tolist()),
    ("fetched_registry_anchored_claims", int((vm.G1a_fetched_registry != "").sum())),
    ("named_but_unregistered_anchor_claims", vm[vm.G1b_named_not_registered != ""].claim_id.tolist()),
    ("parallels_classification", dict(Counter(pl.classification))),
    ("cavity_degeneracies_Hz", {str(k): v for k, v in degen.items()}),
    ("spectrum_coincidences", coinc),
    ("singular_values_first6", [round(float(x),4) for x in s[:6]]),
])
(OUT / "outputs" / "summary.json").write_text(json.dumps(summary, indent=1, ensure_ascii=False), encoding="utf-8")
man = []
for p in sorted(OUT.rglob("*")):
    if p.is_file() and p.name != "MANIFEST.sha256" and p.suffix.lower() != ".md":
        man.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(OUT).as_posix()}")
(OUT / "outputs" / "MANIFEST.sha256").write_text("\n".join(man) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=1, ensure_ascii=False))
print("\nMODES:")
for m in modes:
    print(f" mode {m['mode']}: σ={m['singular_value']} var={m['variance_fraction']} health={m['health_weighted_(-1..1)']}")
    print("   +", m["features_positive"]); print("   -", m["features_negative"]); print("   claims:", [c[0] for c in m["claims_top10"]])
print("\nAXIOMS:")
for k, v in axproj.items(): print(f" {k}: centroid={v['centroid_modes_1to6'][:3]} health={v['member_health_mean']} nn={[x[0] for x in v['nearest_non_member_claims'][:4]]}")
print("\nCLUSTERS:", json.dumps(cluster_summary, ensure_ascii=False))
print("\nDEGENERACIES:", degen)
