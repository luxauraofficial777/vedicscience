import hashlib
import os
from datetime import datetime, timezone
from pathlib import Path

STUDY = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1] / "outputs" / "CORPUS_MANIFEST.sha256"

PATTERNS = {
    "Task_01_Acoustic_Softening_NME_Report.md",
    "Task_02_Energy_Scaling_Matrix_Report.md",
    "Task_03_Numerical_Simulation_Spec_Report.md",
    "Task_04_Astra_Data_Hardening_Protocol_Report.md",
    "Task_05_Unified_Convergence_Integral_Report.md",
    "Consolidated_Master_Report_AS_NME.md",
    "02_Physical_Quantum_Thermodynamic_Acoustic_Sculpture.html",
    "03_Lux_Aura_Infrastructure.html",
    "04_The_Calculus_of_Convergence.html",
    "THEOREM_DOCKET.md",
    "IDEAS_RESEARCH_BRIEF.md",
    "ASTRA_COMPARATIVE_BRIEF.md",
    "Standard_Dislocation_Tunneling_Reference.md",
    "Standard_Dislocation_Tunneling_Reference.html",
    "Standard_Mineral_Spectroscopy_Acoustics_Reference.md",
    "quantum_dislocation_tunneling_data.json",
    "standard_mineral_acoustics_data.json",
    "verify_convergence_integral.py",
    "verify_metamaterial_and_hugoniot.py",
    "verify_quantum_resonance.py",
    "sim_cavity_acoustics.py",
    "sim_cavity_acoustics.cpp",
    "standard_mineral_acoustics_visualizer.py",
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    lines = []
    for name in sorted(PATTERNS):
        p = STUDY / name
        if p.exists():
            lines.append("%s  %s" % (sha256(p), name))
    img = STUDY / "img"
    if img.is_dir():
        for p in sorted(img.iterdir()):
            if p.is_file():
                lines.append("%s  img/%s" % (sha256(p), p.name))
    header = "# SHA-256 corpus manifest, generated %s UTC by scripts/pin_corpus.py\n" % (
        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    )
    OUT.write_text(header + "\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("pinned %d files ->" % len(lines), OUT)


if __name__ == "__main__":
    main()
