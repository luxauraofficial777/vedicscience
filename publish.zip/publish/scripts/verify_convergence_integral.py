"""
verify_convergence_integral.py
------------------------------
Numerical verification of Task 1 (Iteration V, Document ID: AS-NME-REP-05):
Evaluates the Unified Acoustic-Temporal Convergence Integral \\Delta T_drift(\\nabla P_ac),
compares exact numerical quadrature against the derived exponential-over-quadratic
asymptotic expansion, and quantifies the crossover gradient G_cross = \\tau_crit / \\delta_bl.
"""

import math
import json


def integrand_exact(xi, beta_lambda):
    """Normalized integrand: (1 - tanh(xi)) / (1 + beta_lambda * xi^2)"""
    # Use stable exponential form for 1 - tanh(xi) = 2*exp(-2*xi) / (1 + exp(-2*xi))
    if xi > 250.0:
        num = 0.0
    else:
        e2 = math.exp(-2.0 * xi)
        num = (2.0 * e2) / (1.0 + e2)
    den = 1.0 + beta_lambda * (xi ** 2)
    return num / den


def integrand_asymptotic_leading(xi, beta_lambda):
    """Leading high-gradient asymptotic term: 2 * exp(-2*xi) / (beta_lambda * xi^2)"""
    if xi <= 0.0 or xi > 250.0:
        return 0.0
    return (2.0 * math.exp(-2.0 * xi)) / (beta_lambda * (xi ** 2))


def integrand_asymptotic_second_order(xi, beta_lambda):
    """Second-order asymptotic expansion including O(xi^-4) and O(exp(-4*xi)) corrections."""
    if xi <= 0.0 or xi > 250.0:
        return 0.0
    e2 = math.exp(-2.0 * xi)
    lead = (2.0 * e2) / (beta_lambda * (xi ** 2))
    corr = (1.0 - e2) * (1.0 - 1.0 / (beta_lambda * (xi ** 2)))
    return lead * corr


def run_benchmark():
    # Physical parameters from Barabar / Basalt NME benchmark
    delta_bl = 5.52e-4      # Effective Stokes-Kirchhoff BL thickness at 34.4 Hz [m]
    tau_crit = 1.50e3       # Critical mesoscopic boundary-layer shear unpinning threshold [Pa]
    G_cross = tau_crit / delta_bl  # Crossover pressure gradient ||grad P_ac|| [Pa/m]
    beta_lambda = 12.5      # Dimensionless Sound Logic quadratic coupling parameter

    xi_grid = [0.05, 0.25, 0.5, 1.0, 2.0, 3.5, 5.0, 7.5, 10.0]
    rows = []
    for xi in xi_grid:
        grad_P = xi * G_cross
        val_exact = integrand_exact(xi, beta_lambda)
        val_lead = integrand_asymptotic_leading(xi, beta_lambda)
        val_sec = integrand_asymptotic_second_order(xi, beta_lambda)

        rel_err_lead = abs(val_lead - val_exact) / val_exact * 100.0 if val_exact > 0 else 0.0
        rel_err_sec = abs(val_sec - val_exact) / val_exact * 100.0 if val_exact > 0 else 0.0

        # Decay rate contributions: d(-ln I)/d(xi) = 2*tanh_factor + 2*beta*xi/(1+beta*xi^2)
        rate_exp = 2.0 / (1.0 + math.exp(-2.0 * xi))
        rate_alg = (2.0 * beta_lambda * xi) / (1.0 + beta_lambda * (xi ** 2))

        rows.append({
            "xi": xi,
            "grad_P_MPa_m": round(grad_P / 1e6, 4),
            "I_exact": f"{val_exact:.6e}",
            "I_asymp_lead": f"{val_lead:.6e}",
            "I_asymp_2nd": f"{val_sec:.6e}",
            "err_lead_pct": round(rel_err_lead, 4),
            "err_2nd_pct": round(rel_err_sec, 6),
            "rate_exp_num": round(rate_exp, 4),
            "rate_alg_den": round(rate_alg, 4),
        })

    return {
        "parameters": {
            "delta_bl_mm": round(delta_bl * 1e3, 4),
            "tau_crit_Pa": tau_crit,
            "G_cross_MPa_m": round(G_cross / 1e6, 4),
            "beta_lambda": beta_lambda,
        },
        "benchmark_table": rows,
    }


if __name__ == "__main__":
    print(json.dumps(run_benchmark(), indent=2))
