import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = Path(__file__).resolve().parent.parent
CSV_IN = BASE / "claims_dataset.csv"
OUT_DIR = BASE / "outputs"
SCRIPTS_DIR = BASE / "scripts"

H = 6.62607015e-34
E_CHARGE = 1.602176634e-19
KB_EV = 8.617333262e-5
T0 = 300.0
E_QGP_EV = 2.19e8
H_EV_S = 4.135667696e-15
VISIBLE_HZ = 4e14
AUDIBLE_HZ = 20000.0


def parse_float(s):
    s = (s or "").strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def fmt(x):
    if x is None:
        return ""
    return f"{x:.6g}"


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)

    with open(CSV_IN, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        original_cols = reader.fieldnames
        rows = list(reader)

    computed_cols = ["hf_eV", "n_th_300K", "regime", "octaves_from_20kHz",
                     "decades_from_20kHz", "T_equiv_K", "ratio_to_QGP", "ratio_to_bond"]

    processed = []
    for r in rows:
        freq = parse_float(r.get("freq_Hz", ""))
        energy = parse_float(r.get("energy_eV", ""))

        hf_eV = None
        n_th = None
        regime = ""
        octaves = None
        decades = None
        if freq is not None:
            hf_eV = H * freq / E_CHARGE
            arg = hf_eV / (KB_EV * T0)
            try:
                denom = math.expm1(arg)
                if denom == 0:
                    n_th = float("inf")
                else:
                    n_th = 1.0 / denom
            except OverflowError:
                n_th = 0.0
            if energy is not None and energy > 1e6:
                regime = "QGP"
            elif n_th < 1:
                regime = "quantum"
            else:
                regime = "classical"
            if freq > 0:
                octaves = math.log2(freq / 20000.0)
                decades = math.log10(freq / 20000.0)

        T_equiv = None
        ratio_qgp = None
        ratio_bond = None
        if energy is not None:
            T_equiv = energy / KB_EV
            ratio_qgp = energy / E_QGP_EV
            ratio_bond = energy / 4.0

        out = dict(r)
        out["hf_eV"] = fmt(hf_eV)
        out["n_th_300K"] = fmt(n_th)
        out["regime"] = regime
        out["octaves_from_20kHz"] = fmt(octaves)
        out["decades_from_20kHz"] = fmt(decades)
        out["T_equiv_K"] = fmt(T_equiv)
        out["ratio_to_QGP"] = fmt(ratio_qgp)
        out["ratio_to_bond"] = fmt(ratio_bond)
        out["_freq_num"] = freq
        out["_energy_num"] = energy
        processed.append(out)

    processed.sort(key=lambda r: (
        r["_freq_num"] is None,
        r["_freq_num"] if r["_freq_num"] is not None else 0.0,
        r["_energy_num"] is None,
        r["_energy_num"] if r["_energy_num"] is not None else 0.0,
    ))

    out_cols = list(original_cols) + computed_cols
    ledger_path = OUT_DIR / "gradient_ledger.csv"
    with open(ledger_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=out_cols, lineterminator="\n",
                                extrasaction="ignore")
        writer.writeheader()
        for r in processed:
            writer.writerow({c: r.get(c, "") for c in out_cols})

    # summary
    freqs = [parse_float(r.get("freq_Hz", "")) for r in rows]
    freqs = [x for x in freqs if x is not None]
    energies = [parse_float(r.get("energy_eV", "")) for r in rows]
    energies = [x for x in energies if x is not None]

    quantum = sum(1 for r in processed if r["regime"] == "quantum")
    classical = sum(1 for r in processed if r["regime"] == "classical")
    qgp_regime = sum(1 for r in processed if r["regime"] == "QGP")

    f_qgp = E_QGP_EV / H_EV_S
    oct_visible = math.log2(VISIBLE_HZ / AUDIBLE_HZ)
    oct_qgp = math.log2(f_qgp / AUDIBLE_HZ)
    forty_check = AUDIBLE_HZ * (2 ** 40)

    summary = {
        "count_claims": len(rows),
        "count_with_freq": len(freqs),
        "count_with_energy": len(energies),
        "count_quantum": quantum,
        "count_classical": classical,
        "count_QGP_regime": qgp_regime,
        "min_freq_Hz": min(freqs) if freqs else None,
        "max_freq_Hz": max(freqs) if freqs else None,
        "min_energy_eV": min(energies) if energies else None,
        "max_energy_eV": max(energies) if energies else None,
        "octaves_20kHz_to_visible_4e14Hz": oct_visible,
        "octaves_20kHz_to_QGP_equiv": oct_qgp,
        "f_QGP_Hz": f_qgp,
        "forty_octave_check_Hz": forty_check,
    }
    with open(OUT_DIR / "gradient_summary.json", "w", encoding="utf-8", newline="\n") as f:
        json.dump(summary, f, indent=2)
        f.write("\n")

    # chart
    cat_colors = {
        "Vedic theory": "#7f7f7f",
        "CERN/ITER measurement": "#1f77b4",
        "plasma anchor": "#d62728",
        "local corpus number": "#2ca02c",
    }
    fig, ax = plt.subplots(figsize=(12, 6))
    for cat in sorted(set(r["category"] for r in rows)):
        xs = [parse_float(r["freq_Hz"]) for r in rows if r["category"] == cat]
        xs = [x for x in xs if x is not None]
        if not xs:
            continue
        ys = [1.0] * len(xs)
        ax.scatter(xs, ys, label=cat, color=cat_colors.get(cat, "#9467bd"), s=40, alpha=0.8)

    for v in (40e6, 55e6):
        ax.axvline(v, color="#ff7f0e", linestyle="--", linewidth=1, label="ITER ICRH" if v == 40e6 else None)
    ax.axvline(170e9, color="#9467bd", linestyle="--", linewidth=1, label="ITER ECRH 170 GHz")
    ax.axvline(f_qgp, color="#8c564b", linestyle="-", linewidth=1.5, label="CERN QGP equiv freq")
    ax.axvline(AUDIBLE_HZ, color="#17becf", linestyle=":", linewidth=1, label="Audible 20 kHz")
    ax.axvline(VISIBLE_HZ, color="#e377c2", linestyle=":", linewidth=1, label="Visible 4e14 Hz")

    ax.set_xscale("log")
    ax.set_xlim(1e-6, 1e26)
    ax.set_ylim(0.5, 1.5)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_yticks([])
    ax.set_title("Vedic-Plasma Gradient Ledger")
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT_DIR / "gradient_chart.png", dpi=100)
    plt.close(fig)

    # manifest
    write_manifest()


def write_manifest():
    files = []
    for d in (OUT_DIR, SCRIPTS_DIR):
        for p in d.rglob("*"):
            if p.is_file() and p.name != "MANIFEST.sha256":
                rel = p.relative_to(BASE).as_posix()
                files.append((rel, p))
    files.sort(key=lambda x: x[0])
    lines = []
    for rel, p in files:
        h = hashlib.sha256()
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        lines.append(f"{h.hexdigest()}  {rel}")
    with open(OUT_DIR / "MANIFEST.sha256", "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()